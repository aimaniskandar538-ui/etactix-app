#!/usr/bin/env bash
# Git-free state persistence for CI runs.
#
#   ci/state.sh load    # once at the start of a job
#   ci/state.sh save    # once at the end (always(), so a failed publish still saves the queue)
#
# MODE (env, default: cache)
#   cache     GitHub Actions cache  - no git, no repo writes, no branch to create. Recommended.
#   artifact  workflow artifact     - no git; survives cache eviction; visible in the run UI.
#   git       the `state` branch    - opt-in only; delegates to ci/git_state.sh.
#   none      explicitly disabled   - every run starts with an empty queue.
#   <any dir> a directory path      - for a shared filesystem / air-gapped runner / local tests.
#
# State = work/pipeline.db (+ a bounded footage cache). Losing it is not fatal: you only lose
# the dedupe table, the cost ledger and the per-platform counters, which is why nothing in here
# is allowed to fail a run that produced a video.
set -uo pipefail

ACTION="${1:-}"; ROOT="${2:-$PWD}"
MODE="${MODE:-${ACP_STATE:-cache}}"
STATE_MAX_MB="${STATE_MAX_MB:-15}"        # per-file cap; render outputs never belong in state
KEEP_CLIPS="${KEEP_CLIPS:-25}"            # footage cache entries carried across runs
TARBALL="${RUNNER_TEMP:-/tmp}/acp-state.tgz"   # canonical; every mode reads/writes this

log() { printf '[state] %s\n' "$*"; }
skip() { log "$*"; exit 0; }             # state problems are logs, never red X marks

case "$ACTION" in load|save) ;; *) echo "usage: ci/state.sh {load|save} [repo_root]" >&2; exit 2;; esac
cd "$ROOT" || skip "cannot enter $ROOT"

# A tar list of what state actually means here. Small text files + the SQLite queue + clips.
collect() {
  {
    [ -f work/pipeline.db ] && echo work/pipeline.db
    [ -f work/pipeline.db-wal ] && echo work/pipeline.db-wal
    [ -f work/pipeline.db-shm ] && echo work/pipeline.db-shm
    find work -maxdepth 2 -type f \( -name '*.json' -o -name '*.vtt' -o -name '*.ass' \) \
         -size -2M 2>/dev/null | head -300
    find assets/cache -maxdepth 1 -type f -size -"$STATE_MAX_MB"M 2>/dev/null \
      | head -"$KEEP_CLIPS"
  } | sort -u
}

# SQLite from a half-written cache upload must never crash the next run.
validate_db() {
  [ -f work/pipeline.db ] || return 0
  if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 work/pipeline.db "PRAGMA integrity_check;" >/dev/null 2>&1 && return 0
  else
    python3 -c "import sqlite3,sys;c=sqlite3.connect(sys.argv[1]);c.execute('select count(*) from jobs').fetchone();c.close()" \
      work/pipeline.db >/dev/null 2>&1 && return 0
  fi
  log "pipeline.db failed integrity_check - quarantining it and starting fresh"
  mv work/pipeline.db "work/pipeline.db.corrupt.$(date -u +%s)" 2>/dev/null || rm -f work/pipeline.db
  return 0
}

if [ "$ACTION" = load ]; then
  mkdir -p work assets/cache
  case "$MODE" in
    none) skip "state disabled (MODE=none) - starting with an empty queue";;
    cache)
      # actions/cache@v4 restores the path with its ABSOLUTE prefix intact, so the tarball
      # may land at $RUNNER_TEMP/acp-state.tgz OR at $RUNNER_TEMP/acp-state-src/<tmpdir>/
      # $RUNNER_TEMP/acp-state-src/acp-state.tgz depending on version. Search, don't guess.
      found="$(find "${RUNNER_TEMP:-/tmp}" -name 'acp-state.tgz' -type f 2>/dev/null | head -1)"
      [ -n "$found" ] || found="$(find "$ROOT" -maxdepth 2 -name 'acp-state.tgz' -type f 2>/dev/null | head -1)"
      [ -n "$found" ] || skip "no cache hit yet (first run on this key) - starting cold"
      TARBALL="$found"
      ;;
    artifact)
      found=""
      for d in "${STATE_TARGET:-}" "$ROOT/acp-state" "${RUNNER_TEMP:-/tmp}"; do
        [ -n "$d" ] && [ -d "$d" ] || continue
        found="$(find "$d" -maxdepth 3 -name 'acp-state.tgz' -type f 2>/dev/null | head -1)"
        [ -n "$found" ] && break
      done
      [ -n "$found" ] || skip "no acp-state artifact found - starting cold"
      TARBALL="$found"
      ;;
    git) bash ci/git_state.sh restore "$ROOT" 2>&1 | sed 's/^/[state] /'; exit 0;;
    *)
      [ -d "$MODE" ] || skip "state dir $MODE does not exist - starting cold"
      TARBALL="$MODE/acp-state.tgz"; [ -f "$TARBALL" ] || skip "no state in $MODE yet - starting cold"
      ;;
  esac
  tar -xzf "$TARBALL" -C . 2>/dev/null || skip "tar unpack failed (empty or truncated archive) - starting cold"
  n="$(find work -type f 2>/dev/null | wc -l | tr -d ' ')"
  c="$(find assets/cache -type f 2>/dev/null | wc -l | tr -d ' ')"
  validate_db
  log "loaded $n work file(s) + $c cached clip(s) from $MODE state"
  if [ -f work/pipeline.db ]; then
    python3 - "$PWD/work/pipeline.db" <<'PY' 2>/dev/null || true
import sqlite3, sys
try:
    c = sqlite3.connect(sys.argv[1]); rows = c.execute(
        "select state, count(*) from jobs group by state").fetchall()
    print("[state] queue carried over:", ", ".join(f"{s}={n}" for s, n in rows) or "empty")
    d = c.execute("select count(*) from seen").fetchone()[0]
    print(f"[state] dedupe table holds {d} idea(s)")
except Exception as e:
    print("[state] could not read queue:", type(e).__name__)
PY
  fi
  exit 0
fi

# ------------------------------------------------------------------- save
case "$MODE" in
  none) skip "state disabled - nothing to save";;
  git) bash ci/git_state.sh save "$ROOT" 2>&1 | sed 's/^/[state] /'; exit 0;;
esac
[ -d work ] || skip "no work/ directory - nothing to save"
collect > "$TARBALL.list" 2>/dev/null
[ -s "$TARBALL.list" ] || skip "no state files present (no job ran?) - nothing to save"
tar -czf "$TARBALL" -T "$TARBALL.list" 2>/dev/null || skip "tar failed - skipping state save"
sz=$(wc -c < "$TARBALL" | tr -d ' ')
mb=$(( (sz + 1048575) / 1048576 ))
if [ "$mb" -gt 150 ]; then
  # Clips are the only thing that can balloon it; retry without them rather than push a
  # 2 GB archive into the cache backend and slow every future restore.
  log "state is ${mb}MB (too big) - retrying with an empty footage cache"
  grep -v '^assets/cache/' "$TARBALL.list" > "$TARBALL.list2" && mv "$TARBALL.list2" "$TARBALL.list"
  tar -czf "$TARBALL" -T "$TARBALL.list" 2>/dev/null || true
  mb=$(( ($(wc -c < "$TARBALL" | tr -d ' ') + 1048575) / 1048576 ))
fi
case "$MODE" in
  cache)
    # actions/cache@v4 saves whatever sits in its path; we put the tarball there.
    dst="${RUNNER_TEMP}/acp-state-src"; mkdir -p "$dst" 2>/dev/null || true
    cp "$TARBALL" "$dst/acp-state.tgz" 2>/dev/null || true
    log "saved ${mb}MB for actions/cache to store";;
  artifact)
    # upload-artifact reads the CANONICAL path ($RUNNER_TEMP/acp-state.tgz), so state must be
    # written there - not into the restore dir, which is only ever an input. That mismatch is
    # exactly the kind of bug a fake-state test catches and a "looks fine locally" review does not.
    [ "$TARBALL" = "${RUNNER_TEMP:-/tmp}/acp-state.tgz" ] || cp "$TARBALL" "${RUNNER_TEMP:-/tmp}/acp-state.tgz"
    log "saved ${mb}MB for actions/upload-artifact";;
  *)
    mkdir -p "$MODE" 2>/dev/null && cp "$TARBALL" "$MODE/acp-state.tgz" \
      && log "saved ${mb}MB into $MODE" || log "cannot write to $MODE - state not saved";;
esac
exit 0
