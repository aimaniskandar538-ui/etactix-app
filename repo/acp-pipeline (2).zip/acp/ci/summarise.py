#!/usr/bin/env python3
"""GitHub Actions step summary for the scheduled pipeline run.

Deliberately tolerant: a summary is diagnostics, so a missing DB, a fresh repo or a
failed render must still print something useful instead of failing the job.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main() -> int:
    lines = [f"## ACP run — {os.environ.get('GITHUB_SHA', 'local')[:7]} @ "
             f"{os.environ.get('GITHUB_REF_NAME', '?')}", ""]
    try:
        from acp.orchestrate import Pipeline

        s = Pipeline().status()
        lines += ["| metric | value |", "|---|---|",
                  f"| videos produced | `{s.get('today_jobs', 0)}` today |",
                  f"| queue | `{json.dumps(s.get('states', {}), sort_keys=True)}` |",
                  f"| spend today | `${s.get('today_cost_usd', 0):.3f} of ${s.get('budget_usd', 0):.2f} |",
                  f"| ready to publish | `{s.get('queued_publish', 0)}` |",
                  f"| posts used | `{json.dumps(s.get('used_today', {}), sort_keys=True)}` |"]
        for row in Pipeline().db.list_jobs("published", 5):
            pay = Pipeline().db.payload(row["id"])
            url = ""
            for v in json.loads((Pipeline().db.get(row["id"]) or {}).get("publish") or "{}").values():
                if isinstance(v, dict) and v.get("url"):
                    url = v["url"]
                    break
            lines.append(f"- 🚀 **{row['id']}** {(row['idea'] or '')[:60]} → {url or 'queued'} "
                         f"({(pay.get('render') or {}).get('duration', '?')}s)")
        held = [r for r in Pipeline().db.list_jobs(None, 30) if "held" in (r.get("error") or "")]
        if held:
            lines.append(f"- ⚠️ parked by platform caps: {len(held)} job(s) — check PUBLISH_WINDOWS / caps")
    except Exception as e:  # noqa: BLE001
        lines.append(f"_(status unavailable: {type(e).__name__}: {str(e)[:160]})_")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
