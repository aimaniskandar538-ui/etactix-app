#!/usr/bin/env bash
# State persistence for the GitHub Actions pipeline, with zero opportunities for
# `exit 128` (git's "fatal" code) to surface as a red run.
#
#   ci/git_state.sh restore   -> pull work/pipeline.db + a capped footage cache off the
#                                `state` branch (no-op on the first ever run)
#   ci/git_state.sh save      -> push the new state back to that branch (no-op if unchanged)
#
# Why a script and not inline YAML: the previous inline version failed in three ways that
# are all invisible locally and fatal on a runner - fetching a branch that does not exist,
# `git archive` on a path that does not exist, and `git add` of paths our own .gitignore
# lists. Everything here probes first (ls-remote / cat-file) instead of assuming, and a
# state-sync problem is logged and skipped rather than failing a run that produced a video.
set -uo pipefail

ACTION="${1:-}"; ROOT="${2:-$PWD}"
STATE_BRANCH="${STATE_BRANCH:-state}"
STATE_MAX_MB="${STATE_MAX_MB:-20}"            # per-file cap: MP4s never belong on this branch
KEEP_CLIPS="${KEEP_CLIPS:-40}"                # footage cache size cap, oldest first
GIT_AUTHOR_NAME="${GIT_AUTHOR_NAME:-acp-bot}"
GIT_AUTHOR_EMAIL="${GIT_AUTHOR_EMAIL:-acp-bot@users.noreply.github.com}"

log() { printf '[git_state] %s\n' "$*"; }
die_ok() { log "$* (skipping state sync - not a pipeline failure)"; exit 0; }

case "$ACTION" in restore|save) ;; *)
  echo "usage: ci/git_state.sh {restore|save} [repo_root]" >&2; exit 2;; esac

cd "$ROOT" || die_ok "cannot enter $ROOT"

# ---------------------------------------------------------------- preflight
# One place that answers "is git usable in this job at all?" before anything else runs.
if [ ! -d .git ]; then
  die_ok "no .git in $ROOT (checkout step missing or workspace changed)"
fi
REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
if [ -z "$REMOTE_URL" ]; then
  # Actions' default checkout keeps the remote; an empty one means a fork/no-token context.
  GITHUB_REF_URL="${GITHUB_SERVER_URL:-https://github.com}/${GITHUB_REPOSITORY:-}"
  if [ -n "${GITHUB_TOKEN:-}" ] && [ -n "$GITHUB_REF_URL" ]; then
    REMOTE_URL="https://x-access-token:${GITHUB_TOKEN}@${GITHUB_REF_URL#https://}"
    log "no origin remote; using GITHUB_TOKEN over $GITHUB_REF_URL"
  else
    die_ok "no origin remote and no GITHUB_TOKEN - state will not persist"
  fi
fi
log "repo=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo detached) shallow=$(git rev-parse --is-shallow-repository 2>/dev/null) remote=${REMOTE_URL%%@*}"
# Does the state branch exist? Ask the remote; never fetch a ref we have not confirmed.
STATE_SHA="$(git ls-remote --heads "$REMOTE_URL" "$STATE_BRANCH" 2>/dev/null | awk '{print $1}')" || STATE_SHA=""

# ------------------------------------------------------------------ restore
if [ "$ACTION" = "restore" ]; then
  [ -n "$STATE_SHA" ] || die_ok "no '$STATE_BRANCH' branch on the remote yet (first run)"
  tmp="$(mktemp -d)"
  # Filtered clone: only the two prefixes we care about, no history, no blobs we discard.
  if ! git clone -q --depth=1 --branch "$STATE_BRANCH" --no-tags \
        --filter=blob:none "$REMOTE_URL" "$tmp" 2>"$tmp/err" \
     && ! git clone -q --depth=1 --branch "$STATE_BRANCH" --no-tags "$REMOTE_URL" "$tmp" 2>>"$tmp/err"; then
    rm -rf "$tmp"; die_ok "clone of '$STATE_BRANCH' failed: $(tail -2 "$tmp/err" 2>/dev/null | tr '\n' ' ')"
  fi
  mkdir -p work assets/cache
  restored=0
  if [ -f "$tmp/work/pipeline.db" ]; then
    cp -a "$tmp/work/pipeline.db" work/pipeline.db && restored=$((restored+1))
  fi
  # Copy small state files (json/ass/vtt/txt) so a retried job can reuse its narration,
  # and the footage cache so Pexels clips are not re-downloaded every run.
  (cd "$tmp" && find work -maxdepth 2 -type f \
      \( -name '*.json' -o -name '*.vtt' -o -name '*.ass' -o -name '*.txt' \) \
      -size -2M -print 2>/dev/null | head -400) > "$tmp/.list" || true
  if [ -s "$tmp/.list" ]; then
    (cd "$tmp" && tar -cf - -T .list 2>/dev/null) | (tar -xmf - 2>/dev/null) && restored=1
  fi
  if [ -d "$tmp/assets/cache" ]; then
    n=0
    for c in "$tmp"/assets/cache/*; do
      [ -f "$c" ] || continue
      big=$(find "$c" -size +"${STATE_MAX_MB}M" 2>/dev/null | wc -l)
      [ "$big" != "0" ] && continue
      cp -a "$c" "assets/cache/" 2>/dev/null && n=$((n+1))
      [ "$n" -ge "$KEEP_CLIPS" ] && break
    done
    log "footage cache: $n clip(s) restored"
  fi
  rm -rf "$tmp"
  log "restore done ($restored item(s)); db -> $( [ -f work/pipeline.db ] && echo present || echo absent )"
  exit 0
fi

# --------------------------------------------------------------------- save
if [ "$ACTION" = "save" ]; then
  [ -d work ] || die_ok "no work/ to save"
  # Build the branch from scratch in a throwaway repo. No worktree, no archive, no
  # reset of a checked-out branch - the three inline commands that could go fatal.
  tmp="$(mktemp -d)"
  if [ -n "$STATE_SHA" ]; then
    git clone -q --depth=1 --no-tags --branch "$STATE_BRANCH" "$REMOTE_URL" "$tmp/repo" 2>/dev/null \
      || git init -q "$tmp/repo"
  else
    git init -q "$tmp/repo"
  fi
  cd "$tmp/repo"
  git config user.name "$GIT_AUTHOR_NAME"; git config user.email "$GIT_AUTHOR_EMAIL"
  # Start from the branch's own tree, then delete what we regenerate, so unchanged files
  # keep their blobs and `git status` reflects real changes only.
  rm -rf work assets .gitignore 2>/dev/null
  mkdir -p work assets/cache
  # Text state only: the SQLite queue + per-job metadata. Renders stay in artifacts.
  cp -a "$ROOT/work/pipeline.db" work/ 2>/dev/null || true
  find "$ROOT/work" -maxdepth 2 -type f \
      \( -name '*.json' -o -name '*.vtt' -o -name '*.ass' -o -name '*.txt' \) \
      -size -2M 2>/dev/null | head -400 | while read -r f; do
    dest="work/${f#$ROOT/work/}"; mkdir -p "$(dirname "$dest")"; cp -a "$f" "$dest" 2>/dev/null || true
  done
  find "$ROOT/assets/cache" -maxdepth 1 -type f -size -"$STATE_MAX_MB"M 2>/dev/null \
    | head -"$KEEP_CLIPS" | while read -r c; do cp -a "$c" assets/cache/ 2>/dev/null || true; done
  # The committed tree must not inherit the repo's own ignore rules, or `git add` reports
  # "paths are ignored" (exit 1) and nothing is ever staged - which is how the previous
  # version silently saved no state at all. Replace .gitignore with an explicit allowlist.
  printf '*\n!work/\n!work/**\n!assets/\n!assets/cache/**\n' > .gitignore
  git add -A -f . >/dev/null 2>&1 || true
  if git diff --cached --quiet 2>/dev/null; then
    log "state unchanged"; cd /; rm -rf "$tmp"; exit 0
  fi
  # Belt and braces: identical tree hash to the remote branch means nothing to push,
  # even if a line-ending or mode change made `git diff` noisy.
  if [ -n "$STATE_SHA" ]; then
    new_tree="$(git write-tree 2>/dev/null || true)"
    old_tree="$(git rev-parse -q --verify "$STATE_SHA^{tree}" 2>/dev/null \
                || git ls-remote "$REMOTE_URL" "$STATE_BRANCH" >/dev/null 2>&1 \
                && git rev-parse -q --verify HEAD^{tree} 2>/dev/null || true)"
    if [ -n "$new_tree" ] && [ "$new_tree" = "$old_tree" ]; then
      log "state tree identical to $STATE_BRANCH (${new_tree:0:8}) - no push"; cd /; rm -rf "$tmp"; exit 0
    fi
  fi
  git commit -qm "state: $(date -u +%FT%TZ) run ${GITHUB_RUN_NUMBER:-local}" || { log "commit failed"; cd /; rm -rf "$tmp"; exit 0; }
  git push -f "$REMOTE_URL" "HEAD:refs/heads/$STATE_BRANCH" >/dev/null 2>"$tmp/push.err"
  rc=$?
  if [ $rc -ne 0 ]; then
    # A push failure must not turn a successful render into a red run: log the real fatal
    # (usually "Permission denied" = Actions can't write, or "shallow update not allowed").
    log "push rejected (exit $rc): $(tail -3 "$tmp/push.err" | tr '\n' ' ')"
    echo "::warning::state not persisted - dedupe/quota counters will reset next run. $(tr -d '\n' < "$tmp/push.err" | tail -c 200)"
  else
    log "state pushed to $STATE_BRANCH ($(git ls-files | wc -l | tr -d ' ') files, $(du -sh work | cut -f1))"
  fi
  cd /; rm -rf "$tmp"
  exit 0
fi

