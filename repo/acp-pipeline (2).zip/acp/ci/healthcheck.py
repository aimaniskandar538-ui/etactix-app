#!/usr/bin/env python3
"""Container healthcheck. Passes trivially when this instance is not serving the API,
so the same image can run worker/gpu roles without a permanently unhealthy container."""
import os
import sys
import urllib.request

if os.environ.get("ACP_HEALTHCHECK_TARGET", "api") == "off":
    sys.exit(0)
port = os.environ.get("ACP_CONTROL_PORT", "8787")
try:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=5) as r:
        sys.exit(0 if r.status == 200 else 1)
except Exception:
    sys.exit(1)
