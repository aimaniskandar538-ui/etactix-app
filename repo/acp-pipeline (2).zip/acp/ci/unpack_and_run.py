#!/usr/bin/env python3
"""Unpack an uploaded acp-pipeline*.zip into the workspace and run one pipeline pass.

Written for the "I only edit this repo from a phone browser" workflow: upload the zip, and
this step does the rest. It is deliberately defensive - every failure mode prints a
::error:: annotation with the actual reason rather than a bare exit code.

Usage: python3 ci/unpack_and_run.py [workspace]
Env:   ACP_ZIP             preferred zip name(s), colon-list optional
       PIPELINE_ARGS       extra args appended to `acp run` (shlex-split)
       PIPELINE_LIMIT      jobs per run (default 1)
       PIPELINE_DRY_RUN=1  extract + report only, no pipeline execution
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


def err(msg: str) -> "None":
    print(f"::error::{msg}")


def find_zip(ws: Path) -> Path | None:
    preferred = os.environ.get("ACP_ZIP", "")
    names = [n for n in preferred.split(":") if n] + ["acp-pipeline (1).zip", "acp-pipeline.zip"]
    for n in names:
        p = ws / n
        if p.is_file():
            return p
    # fall back to any zip mentioning acp, at the root or one level down
    cands = sorted(p for p in ws.glob("*.zip") if "acp" in p.name.lower())
    cands += sorted(p for p in ws.glob("*/*.zip") if "acp" in p.name.lower() and ".git" not in str(p))
    return cands[0] if cands else None


def extract(zip_path: Path, ws: Path) -> Path:
    """Extract and flatten to the directory that CONTAINS `acp/cli.py`.

    The download may be the zip (contents under ./acp/) or an unzipped archive (contents at
    ./). Copying the wrong level is the failure that looks like "ModuleNotFoundError: acp".
    """
    out = Path("/tmp/acp-extract")
    shutil.rmtree(out, ignore_errors=True)
    with zipfile.ZipFile(zip_path) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"corrupt entry in {zip_path.name}: {bad} (re-upload the file)")
        names = z.namelist()
        z.extractall(out)

    def has_pkg(d: Path) -> bool:
        return (d / "acp" / "cli.py").is_file()

    # Ordered, boring candidates. `rglob("acp")` matched the PACKAGE directory one level too
    # deep and copied acp/*.py to the workspace root, which "extracted fine" and then died on
    # import - so check the plausible levels explicitly and copy the whole containing tree.
    cands = [out, *sorted(d for d in out.iterdir() if d.is_dir()), *sorted((d for d in out.glob("*/*") if d.is_dir()))]
    root = next((d for d in cands if has_pkg(d)), None)
    if root is None:
        sample = [n for n in names if n.endswith(".py")][:5]
        raise RuntimeError(f"extracted tree has no acp/cli.py (entries like: {sample}) - wrong zip?")
    moved = 0
    for entry in sorted(root.iterdir()):
        if entry.name == ".git":
            continue
        dst = ws / entry.name
        if dst.resolve() == entry.resolve():
            continue
        if entry.is_dir():
            shutil.copytree(entry, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(entry, dst)
        moved += 1
    gi = ws / ".gitignore"
    ignore = "\nwork/\n__pycache__/\n*.pyc\n.pytest_cache/\nassets/cache/\n"
    if not gi.exists() or "work/" not in gi.read_text():
        gi.write_text((gi.read_text() if gi.exists() else "") + ignore)
    print(f"extracted {len(names)} entries from {zip_path.name!r}: {moved} top-level items (root {root})")
    return root


def pip_install() -> None:
    pkgs = os.environ.get("PIP_PACKAGES", "requests edge-tts").split()
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "--no-warn-script-location", *pkgs],
                       capture_output=True, text=True)
    if r.returncode:
        print(f"::warning::pip install failed ({r.returncode}); continuing - requests may already be present")
        print((r.stderr or "").strip()[-400:])


def run(cmd: list[str], timeout: int = 1800) -> int:
    print("$ " + " ".join(cmd), flush=True)
    try:
        p = subprocess.run(cmd, timeout=timeout)
    except FileNotFoundError as e:
        err(f"cannot exec {cmd[0]}: {e}")
        return 127
    except subprocess.TimeoutExpired:
        err(f"timed out after {timeout}s: {' '.join(cmd)}")
        return 124
    return p.returncode


def main() -> int:
    ws = Path(sys.argv[1] if len(sys.argv) > 1 else os.environ.get("GITHUB_WORKSPACE", ".")).resolve()
    print(f"workspace: {ws}")
    print("root contents: " + ", ".join(sorted(p.name for p in ws.iterdir())[:12]))

    zpath = find_zip(ws)
    if zpath is None:
        err(f"no acp-pipeline*.zip in {ws} - upload the zip to the repo root first")
        return 3
    try:
        extract(zpath, ws)
    except Exception as e:  # noqa: BLE001 - we want the reason in the annotation, not a traceback
        err(f"extraction failed: {type(e).__name__}: {e}")
        return 4
    if not (ws / "acp" / "cli.py").is_file():
        err("acp/cli.py still missing after extraction - aborting before pip install")
        return 5
    if os.environ.get("PIPELINE_DRY_RUN") == "1":
        print("PIPELINE_DRY_RUN=1 - extraction verified, not running the pipeline")
        return 0

    pip_install()
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ws) + (":" + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    env["WORK_DIR"] = str(ws / "work")
    os.environ.update(PYTHONPATH=env["PYTHONPATH"], WORK_DIR=env["WORK_DIR"])

    limit = os.environ.get("PIPELINE_LIMIT", "1")
    steps = [("selftest", [sys.executable, "-m", "acp.cli", "selftest"], 240)]

    idea = os.environ.get("PIPELINE_IDEA", "").strip()
    if idea:
        # A fresh repo has an empty queue, and `run` without a job does nothing. `run --idea`
        # exists precisely for this (verified with `acp run --help`), so one manual idea turns
        # the scheduled run into a real end-to-end test instead of a no-op.
        steps.append(("seed idea", [sys.executable, "-m", "acp.cli", "run", "--idea", idea], 1800))
    else:
        steps.append(("loop (render + publish)",
                      [sys.executable, "-m", "acp.cli", "loop", "--once", "--limit", limit], 1800))

    for label, cmd, tmo in steps:
        rc = run(cmd, timeout=tmo)
        if rc:
            err(f"{label} exited {rc}")
            return rc
    n = len(list((ws / "work").glob("job_*/final.mp4")))
    print(f"DONE: {n} rendered video(s) in work/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
