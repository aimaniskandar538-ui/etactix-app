# Docs

* **ARCHITECTURE.md** — the 4-stage technical spec: what each stage reads/writes, the exact API
  constraints it is built around, per-platform limits as of Sept 2026, data contracts, and the three
  deployment topologies. Read this first if you want to change the design.
* **BOTTLENECKS.md** — 12 bottlenecks (cloud-render RAM, encode cost, disk, libass/font traps,
  A/V drift, YouTube quota + the hidden per-day upload cap, IG's URL requirement + container expiry
  + contradictory caps, TikTok review + 6 req/min + 200-OK errors, RSS fragility, "AI slop"
  suppression, music licensing) each with mechanism → detection → mitigation, plus a one-page
  limit→mitigation table. Read this when something breaks at 3am.
* `../n8n/README.md` — the three importable workflows and why the split is shaped like that.
* `../deploy/README.md` — systemd, Docker, and making the MP4 publicly fetchable.

Two ideas carry most of the reliability in this pipeline: **measure instead of estimate**
(per-chunk TTS + ffprobe timing replaces Whisper; ffprobe-verified QC replaces trust), and
**treat platform limits as a queue, not an error** (`publishable()` + `publish_after` + parking on
terminal codes instead of retrying into a 24 h window).
