# Bottlenecks, why they bite, and what actually works

Ordered by how soon they will hit you. Numbers are from a live 2 vCPU / 2 GB run of this repo
unless stated otherwise. Where a limit is set by a platform, the answer is *route around it*
(scheduling, caching, cheaper formats, official alternatives) — not evade it: evasion is what gets
accounts restricted, and a restricted account makes the whole pipeline worth $0.

---

## A. Compute & rendering

### B1 — RAM ceiling on cheap cloud boxes (the classic killer)
**Mechanism.** MoviePy keeps decoded frames as Python objects and spawns an ffmpeg subprocess per
operation (`CompositeVideoClip`, `TextClip`, `subclip`). A 1080×1920@30 composition with subtitles
peaks at 1.5-3 GB; a 2 GB VPS OOM-kills it, and the kernel kill leaves no Python traceback — you
just see the job vanish.
**Fix.** One ffmpeg `filter_complex`, no Python frame handling → measured **~700 MB used at peak
with OS overhead** (ffmpeg itself ~250 MB) for 3 clips + burn-in + amix, and it *streams*, so the
cost is independent of duration. If you must stay in Python, use `moviepy`'s `ffmpeg_writer`
with `buffersize=4096` and never `subclip()` in a loop.
**Extra levers:** add `ulimit -v` + a systemd `MemoryMax=1.5G` so a runaway job dies immediately and
retries instead of freezing the box; run under `nice -n 10 ionice -c3` so a render never takes the
queue/API down with it.

### B2 — CPU encode time and $/render
**Mechanism.** `libx264 -preset medium` at 1080×1920 runs ~0.4-0.8× realtime on 2 vCPU: a 30 s video
takes 40-70 s. Multiply by 3 daily videos × re-renders and you are paying for CPU you don't need.
**Fix ladder (cheapest first):**
1. `-preset veryfast -crf 21` — 3-6× faster than medium, ~12% bigger file. This is what ships.
2. Never upscale: search portrait renditions at ~1080p, not 4K. Decoding 4K costs 2-4× the time for
   pixels the platform discards anyway (all three re-encode to ~1080p).
3. `trim` per clip + `-stream_loop` instead of pre-cutting each asset into temp files (one read pass).
4. Hardware encode on your own machine if you have one: `h264_nvenc -preset p5 -cq 23` (Nvidia),
   `h264_videotoolbox -q:v 55` (Apple silicon — 5-10× and silent), `h264_vaapi` (Intel). Cloud GPU is
   rarely worth it below ~50 videos/day.
5. Only pay for cloud rendering (`Shotstack`, `Render.com`, `Remotion` Lambda, `Editframe`) once you
   need overlays/templates you can't build in ffmpeg — budget $0.02-0.15/video.
**Measured:** full stage 2→render (LLM echo + TTS + 3 clips + burn-in + loudnorm) = 12-16 s wall,
~45 s for 3 videos end to end → ~150-200 videos/day on one small VPS. Rendering is *not* your
bottleneck; publishing caps are (B6-B9).

### B3 — Disk: asset cache and intermediates
Stock clips are 3-40 MB each; a 10-video/day pipeline plus `raw.mp4` copies will fill a 20 GB disk in
a month.
**Fix.** Content-addressed cache (`assets/cache/<sha1>.mp4`) + weekly prune of cache entries not
referenced by any job (`find assets/cache -mtime +14 -delete` is the crude version; prune by DB
reference is the correct one). Delete `raw.mp4` and chunk wavs after pass 2 (keep `final.mp4`,
`captions.*`, `timings.json`, `qc.json`, `render_meta.json` — they're kilobytes and they are your
debug trail). Upload finals to R2 then delete locally if the box is small.

### B4 — Fonts and subtitle burn-in (silent, horrible failure modes)
**Symptoms and causes:**
- *No captions at all, no error*: the build's libass can't find a font → falls back to a default
  that may be missing glyphs. Static ffmpeg builds frequently have **no fontconfig**. Ship the font
  next to the ASS and pass `fontsdir=` (this repo does: `fonts/Anton-Regular.ttf`).
- *Words stacked one per line*: your chunk is wider than the canvas at that font size, and libass
  wrapped it. Fix = size chunks by **width**, not just characters (`effective_cps` in this repo =
  min(MAX_CPS, 2 × canvas*0.92 / (size*0.46))). This exact bug was caught here by eyeballing a
  rendered frame — always sample 2-3 frames after changing fonts.
- *`\N` rendered literally*: escaping through a shell heredoc / Python f-string ate your backslash.
  Write the ASS file from Python, never through a shell string.
- *Missing `{` in text*: braces are ASS control syntax — escape them (`_esc`).
- *`\i1` italic*: **not supported** in many ASS renderers; libass fakes it poorly. Never italicise.
- *Drawtext for captions*: only viable for one static line. Per-word karaoke/`\pos` needs libass.

### B5 — A/V desync and duration drift
Every clip is trimmed to its slot and the concat is `-t`-capped to the narration length, so
`|video_duration − narration| ≤ 0.05 s` by construction (measured 0.00 s in `qc.json`). The desync
people hit comes from (a) TTS duration estimated from characters, or (b) `-shortest` truncating the
*video* while audio is still going. Both are avoided by measuring each chunk with ffprobe and
looping the video input instead of using `-shortest` alone.

---

## B. Platform & API limits

### B6 — YouTube quota + the hidden upload cap
`videos.insert` is now ~1 unit against its own ~100 calls/day bucket per **project** (post-Dec-2025 /
Jun-2026 quota change); older guides saying "6 uploads/day at 1,600 units" are stale. Since ~24 May
2026 there is also an **undocumented "Video Uploads per day" limit** that 429s while Cloud Console
shows headroom.
**Fix.** Queue, don't retry-spam: on 429/`rateLimitExceeded`, park the job until after the next
Pacific-midnight reset (this repo's `publish_after`). Prefer `status.publishAt` over scheduling
locally (YouTube does the publish for you; one API call, no worker awake at 09:00). Cap yourself at
20/day (`PLATFORM_DAILY_CAPS=youtube:20`) — far below the limit, and enough for one channel. Quota
extension requires Google's audit form; you don't need it at solo scale.

### B7 — Instagram: the URL requirement, container expiry, and two contradictory caps
**Mechanism.** You cannot POST a file to IG. You hand Meta a URL and they fetch it. Containers are
processed asynchronously (30-120 s) and expire; the 24 h publishing cap is documented as 100 in one
section of Meta's page and 50 in another; separately there's a ~200 calls/h per-user-token ceiling.
**Fix.**
- Public URL without buying a CDN: `acp serve` + **Cloudflare Tunnel** (free, no port-forward, no TLS
  cert work) or a 7-day R2 signed URL (`r2 presign`), or a 20 MB file → `curl`-able nginx dir.
- **Persist `container_id`** in the job payload before polling (this repo does) so a restart resumes
  with `media_publish` instead of re-uploading and double-posting.
- Query `content_publishing_limit` and stop at remaining ≤ 1 rather than guessing 50 vs 100
  (implemented in `platform_slot`). Subcode `2207042` = the 24 h cap → **terminal, do not retry**;
  the code parks the job 24 h instead of burning the quota.
- Encode for the spec: faststart moov, H.264 high profile, closed GOP, AAC 44.1/48 kHz 128 kbps+,
  5-90 s, ≤100 MB, no HDR. The QC gate blocks >95 MB and off-9:16 output *before* publishing.

### B8 — TikTok: app review, 6 req/min, and "200 OK but no post"
**Mechanism.** `video.publish` requires a manual audit (weeks; can be rejected for "automated
content"); dev mode forces SELF_ONLY and 5 users/24 h; `/video/init` is **6 requests/min**;
`reached_active_user_cap` is an **app-wide daily publishing-user cap** (~100 reported, raised only by
contacting TikTok developer support — no self-service slider); spam-risk errors return **HTTP 200**,
so a naive client believes success; tokens expire in 24 h.
**Fix.**
- For one channel: route TikTok through an approved partner (Postiz self-host / Upload-Post /
  Post Bridge / Ayrshare). You inherit *their* audit, pay ~$9-30/mo, and skip 2 weeks of review.
  This is the standard, allowed path — it is literally what the partner program is for.
- If going direct: cache `creator_info` for the session but re-query if >1 h old (privacy options
  change → "privacy level mismatch"); treat any `error.code != ok` as failure even on HTTP 200;
  park-and-notify on the two `spam_risk_*` / `reached_active_user_cap` codes; chunked FILE_UPLOAD
  (10 MB parts) rather than PULL_FROM_URL when your host is a home IP (TikTok's fetcher is picky).
- Keep 3-25 s clips: min duration 3 s is enforced, and short clips loop better.

### B9 — Facebook/Meta app review for the IG endpoints
Business verification + a screener video + per-permission review (`instagram_content`,
`pages_manage_engagement`, …). Budget 2-6 weeks and a re-submit.
**Fix.** Start with YouTube-only automation (no review), publish IG/TikTok via an aggregator, and
apply for your own app in parallel if/when you need a feature the aggregator lacks. Also: IG
requires a **Business/Creator** account linked to a Page; personal accounts simply return 100
"Unsupported request" — a very confusing error to debug if you don't know the rule.

### B10 — RSS/HTML scrapers breaking
pytrends gets 429'd and breaks every few months; Reddit blocks datacenter IPs (403 — confirmed in
this run); Google Trends RSS is undocumented and has changed shape; HN's `hnrss` occasionally lags.
**Fix (all implemented):** per-source `try/except` so one death degrades, never fails;
scoring that doesn't depend on any single source's volume field; a `dedupe` table so a source
that starts repeating itself can't repeat your content; a `--sources` override for manual runs; and
a weekly CI job that pings each source (see `.github/workflows/ci.yml`) so you learn about breakage
from a green/yellow badge, not from a dead channel.

---

## C. Content & account risk (the real ceiling)

### B11 — "AI slop" suppression and monetization policy
All three platforms demote (or demonetise) **mass-produced, repetitive, low-transformation**
content. YouTube's reused-content rule and TikTok's unoriginal-content policy both apply to exactly
the shape of "stock clips + TTS + template captions", and it is not an API limit you can code around.
**What actually moves the needle, in order:**
1. **A hook you wrote**, not the model's first guess. 3 variants per video + your pick; kill the
   template-voice openers ("Did you know", "In this video") — the code rejects them at validation.
2. **Own footage for at least the first 3 s**, even 10 seconds of phone video. Original pixels are
   the single strongest difference between "reached 12 views" and "reached 40k" on this format.
3. **Specificity from a real source.** This pipeline passes the trend's linked headlines into the
   prompt as the *only* facts allowed, and forces `claims_to_verify` for anything numeric so the
   approval card can check it. Also makes each video unrepeatable by a competitor scraping the same
   trend.
4. **Pacing variance.** `TTS_GAP_SECONDS`, clip-per-sentence, and the readability re-split (any
   caption >3.0 s gets re-cut) mean two videos on the same template don't share a rhythm.
5. **Volume discipline.** 1-3/day per account with 90 min+ spacing (enforced) reads as a creator;
   20/day reads as a farm and gets throttled by the ranking system, not the API.
Label AI: `is_aigc` on TikTok, disclosure in description elsewhere (also required under the EU AI Act
transparency rules and platform synthetic-media policies if your content is realistic).

### B12 — Music licensing
Pexels/Pixabay clips are safe for commercial use, but **music is the thing that gets muted/claimed**.
**Fix.** YouTube Audio Library (free, cleared for YT; for TikTok/IG use the *in-app* sound picker so
the platform's own licence applies, or license Epidemic/Cartwheel/etc.). Never rip "royalty-free"
tracks from YouTube — Content ID claims auto-mute Reels/TikToks, and a muted video is a wasted post.
The repo keeps a synthesised noise bed (`assets/music/Silence.mp3`, generated at setup) as a
placeholder that cannot possibly claim anything; swap in licensed tracks.

---

## D. Quick reference: limit → mitigation

| Limit | Number (Sep 2026) | Mitigation in this repo |
|---|---|---|
| YT uploads | ~100/day/project (+ hidden per-day 429) | `youtube:20` cap, park-until-reset on 429, `publishAt` for scheduling |
| IG publish | 50 or 100 / rolling 24 h; 200 calls/h | `content_publishing_limit` probe; subcode 2207042 = park 24 h, no retries |
| IG media | ≤100 MB, 5-90 s, 9:16, faststart, no HDR | QC gate blocks >95 MB / off-aspect; encode flags set for it |
| TikTok init | 6 req/min; creator_info 20/min | one init per post, MIN_GAP_MINUTES=90 spacing |
| TikTok caps | app-wide active-user cap; ~25/account/day | prefer aggregator route; park on `reached_active_user_cap` |
| TikTok HTTP | errors arrive as 200 | every response parsed for `error.code != ok` |
| Pexels / Pixabay | 20k req/mo · 100 req/60 s | 1 search per keyword, `CLIPS_PER_VIDEO=1..4`, on-disk cache |
| edge-tts | free, unofficial, can break | Azure F0 (500k chars/mo) / OpenAI / ElevenLabs drop-in; CI pings it weekly |
| Whisper (if you used it) | ~3 GB model, GPU/CPU minutes | **eliminated** by per-chunk TTS + ffprobe timing |
| VPS RAM | 2 GB | pure ffmpeg, no MoviePy; MemoryMax + nice |
| Budget blowout | retry storms | `DAILY_BUDGET_USD`, `attempts>=3` hard stop, cost per job in the ledger |
