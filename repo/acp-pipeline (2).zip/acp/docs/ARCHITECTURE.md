# Autonomous Content Pipeline — Technical Architecture

A 4-stage, resumable, human-gated-by-default pipeline that turns public trend signals into
rendered vertical video and publishes them. Reference implementation: this repo (`acp/`).

```
                        ┌──────────────────────── SQLite (state machine + queue + ledger) ─────────────────────────┐
                        │  new → scripted → assets → voiced → captioned → rendered → awaiting_approval →         │
                        │  approved → publishing → published        (any → failed → retry resumes at last stage)  │
                        └────────────────────────────────────────────────────────────────────────────────────────┘
                                            ▲                          ▲                          ▲
   ┌──────────────────────┐   ┌─────────────┴────────┐   ┌───────────┴──────────┐   ┌──────────┴─────────────┐
   │ 1  DISCOVERY          │   │ 2  SCRIPT + PROMPTS   │   │ 3  RENDER (one host)  │   │ 4  PUBLISH             │
   │ Google Trends RSS     │   │ LLM, 1 call, strict   │   │ 3a footage pexels/    │   │ direct APIs: YT/IG/TT  │
   │ Google News RSS       │──▶│ JSON contract         │──▶│    pixabay/local/mock │──▶│ or 1 aggregator API    │
   │ Wikipedia events      │   │ 3 hooks, sentence     │   │ 3b TTS per-caption-   │   │ media host: R2 signed  │
   │ HN / Reddit / YT feeds│   │ chunks, per-sentence  │   │    chunk, ffprobe=    │   │ URL / tunnel / PULL_   │
   │ score+dedupe+cap      │   │ footage keywords      │   │    exact timing       │   │ FROM_URL               │
   └──────────────────────┘   └───────────────────────┘   │ 3c ASS karaoke + VTT  │   │ per-platform quota +   │
            no key, free         ~$0.001/video             │ 3d ffmpeg filter_complex│  │ rolling-window spacing │
                                                           └────────────────────────┘   └────────────────────────┘
   Orchestrated by: cron/systemd timers OR n8n (workflow in n8n/). Approval: Slack/Telegram/Bluesky button → API.
```

---

## 0. Design rules that shape everything below

1. **Stages are functions, the queue is the product.** Every stage is `stage_x(job_id)` that
   reads its predecessor's payload and writes its own. `run_job()` walks as far as state allows,
   so a crash at 03:00 resumes at the failed stage, not from scratch. This is why no Kafka/Celery
   is needed: SQLite + WAL + an optimistic `claim()` is enough for one creator and 2-10 jobs/day.
2. **Human-in-the-loop by default, opt-out later.** `REQUIRE_APPROVAL=true` parks every video at
   `awaiting_approval`. Turn it off only after ~4 weeks of clean output. Fully hands-off *plus*
   factually wrong is the fastest way to lose a channel.
3. **Money circuit-breaker.** `DAILY_BUDGET_USD` (default 2.0) stops new LLM/TTS calls when
   exceeded. Retry storms against paid APIs are the #1 way these pipelines bill $200 overnight.
4. **Nothing in the render path depends on a key.** `LLM_PROVIDER=echo ASSET_PROVIDER=mock
   TTS_PROVIDER=silent` renders a real MP4 offline (`bash scripts/smoke.sh`) — so you can validate
   the infra before spending a cent, and CI can test it forever.

---

## 1. Stage 1 — Trend & idea discovery

| Input | Endpoint | Auth | Notes |
|---|---|---|---|
| Google Trends daily searches | `https://trends.google.com/trending/rss?geo=US` | none | **Undocumented but stable.** Gives title + `approx_traffic` + up to 3 linked news headlines per trend. This alone replaces most paid "trend API" subscriptions. |
| Google News search RSS | `news.google.com/rss/search?q=<niche>+when:7d` | none | Best for evergreen-adjacent niches; supports `when:7d`, `after:YYYY-MM-DD` operators. |
| Wikipedia Current Events | `en.wikipedia.org/w/index.php?title=Portal:Current_events&action=raw` | none | Date-anchored factual events — the cleanest "what actually happened today" list. |
| Hacker News | `hnrss.org/newest?points=100`, `hn.algolia.com/api/v1/search_by_date` | none | Tech niche only. Algolia gives points/dates, so it is searchable. |
| Reddit | `reddit.com/r/<sub>/hot.json` | none | **Blocked from most datacenter IPs (HTTP 403).** Run from a residential IP, or use OAuth, or skip. Code degrades to a warning. |
| Competitor channels | `youtube.com/feeds/videos.xml?channel_id=…` | none | What top accounts in your niche published in the last 48 h = the strongest format signal available free. |
| pytrends / DataForSEO / Apify | (optional) | key | Only if you need multi-week time series or breakout terms. pytrends is unofficial, breaks every few months, and gets 429'd — treat as a bonus, never as a dependency. |

**Mechanics**
```
fetch all sources (each wrapped in try/except → one dead source never kills the run)
  → normalise to RawItem{title, url, source, published, meta}
  → score = 100 × recency(age) × source_weight × niche_keyword_boost × volume(traffic) × social(points)
  → sort, take top N after dedupe
```
Recency is a step function (1.0 ≤3 h, 0.75 ≤12 h, 0.5 ≤24 h, then 100 h linear decay) because
"trendy" is a cliff, not a slope. Deliberately dumb and auditable: LLM "virality" judging happens
in stage 2 where the cost is ~$0.001 per item and cacheable, not here where we scan hundreds.

**Dedupe:** SHA-1-ish normalised title → `seen(key, DEDUP_DAYS=30)`. Without this, Google Trends
serves the same 3 items all week and your channel becomes a broken record.

**Output contract:** `{title, source, url, score, age_hours, context}`. `context` (traffic,
headlines) is passed to the LLM as *the only* facts it may use — see stage 2.

---

## 2. Stage 2 — Script + visual prompts (one LLM call)

**Model choice:** any small instruction model. `gpt-4o-mini` / `llama-3.3-70b` / `groq` are all
fine and cost <$0.002 per script. Do not use a frontier model here: the bottleneck is prompt
discipline, not reasoning.

**Contract** (enforced in `stages/script.py`, so downstream stages never guess):
```json
{"hook_variants":[…3…], "hook":"…", "script_sentences":["≤42 chars each"],
 "keywords":["2-3 concrete words for stock search, one per ~2 sentences"],
 "title":"≤80", "description":"≤200", "hashtags":[…], "cta":"…", "tts_direction":"…",
 "on_screen_text":[{"start":0,"text":"…"}], "is_ai_generated":true, "claims_to_verify":[…]}
```

**The three things that make or break output quality** (each is code, not prompt vibes):

1. **Duration budget.** `TARGET_SECONDS × WORDS_PER_SECOND` caps total words; over-budget scripts
   are trimmed rather than shipped long. Measure the real rate back from TTS
   (`timings.json → words_per_second_measured`, 1.7–2.3 w/s including gaps for most neural voices
   at +8%) and tune `WORDS_PER_SECOND` (default 2.2) — a rate of 2.6, which most templates assume,
   makes every video 20% too long.
2. **Caption-sized chunks.** Sentences are re-split at ≤`MAX_CPS` chars *and* at the width that
   actually fits your canvas (`effective_cps` = min(42, 2 × chars-per-line at CAPTION_SIZE)).
   Everything downstream — audio, subtitles, clip timing — is keyed to these chunks.
3. **No fabrication.** The prompt forbids invented stats; anything numeric must be echoed into
   `claims_to_verify`, which the approval card surfaces to you. Optionally pipe the stage-1
   `context` into the prompt as the only permitted facts, or add a RAG/verification step.

**Validation gate** (`validate()`): ≥3 sentences, ≤24 chunks, no chunk over budget, no banned
openers ("did you know", "welcome back", "in this video"), title present. Failure = regenerate or
park the job — never render a rejected script.

---

## 3. Stage 3 — Media engine (the part everyone gets wrong)

### 3a Footage
- `search(keywords, orientation=portrait)` → pick one rendition near 1080×1920 (never 4K: you pay
  the bandwidth and the decode to throw 80% of the pixels away), download to a
  **content-addressed cache** (`assets/cache/<sha1>.mp4`) so retries are free.
- `CLIPS_PER_VIDEO=1` is legal and cheapest (Pexels/Pixabay allow it; verify their current terms
  for commercial use before scaling). 1 clip per video = 1 API call, ~3 MB, and the video still
  looks intentional because of the slow-zoom drift. 2-4 clips reads more produced.
- `local` provider = `assets/local_clips/*.mp4` + optional `.txt` tag sidecar. **Your own footage
  outperforms any stock search on relevance**, and it's the only source that can't be rate-limited
  or re-licensed away.
- MoneyPrinterTurbo, if you want a GUI/headless reference: it's the same 5-stage shape
  (LLM script → keywords → Pexels/Pixabay/Coverr → TTS → subtitles → compose) with WebUI+REST.
  Useful as a second opinion on prompts; the render engine is MoviePy-based, which is the part you
  want to replace on a small box.

### 3b Voice + timing — **no Whisper needed**
Conventional design: one long TTS file → transcribe with faster-whisper → derive word timings
(≈3 GB model, 10-30 s of CPU/GPU, occasional hallucinated captions). This repo instead:

```
for each caption chunk: TTS(chunk) → chunk_i.mp3
for each chunk: ffmpeg loudnorm+resample → .wav; ffprobe → exact duration
concat(chunk_0, gap, chunk_1, gap, …) → narration.wav
caption[i] = (start=cumulative, end=start+dur_i, text=chunk_i)
```
Timing is exact **by construction** (verified: Σ chunk durations == concat duration, drift 0.0 s),
costs zero GPU, and is deterministic. Gap-based pacing doubles as your "breath" control.

**When you do want word-level data:** Azure TTS (`WordBoundary` SSE events, F0 = 500k chars/mo free)
or ElevenLabs `stream-alignment` — the code ingests both and uses real boundaries for the karaoke
`\kf` fill when present, else derives them from word length. Both are invisible in the output.

**Provider economics** (per video ≈ 300 chars of narration): edge (free, unofficial, GPL3 client
+ ToS-grey service — fine for a channel, wrong for a SaaS you sell) · Azure F0 free then ~$16/1M
≈ $0.005 · OpenAI gpt-4o-mini-tts ≈ $0.005 · ElevenLabs $5/mo plan ≈ $0.02+ (best voices, cloning).

### 3c Subtitles
Hand-generated ASS: `PlayResX/Y` locked to the canvas, 2-line max with balancing
(`wrap_lines`), karaoke `\kf` per word, `\b1` + 8 px outline, `MarginV = 0.19 × H` to clear the
bottom UI (buttons/captions), `Label` style top-left (`MarginV = 0.09 × H`) for the hook text,
emphasis colour on money/risk/absolute words. VTT is written beside it so the same copy can ship as
a **caption track** (accessibility + search indexing, which burned-in pixels never get).

### 3d Render — one ffmpeg `filter_complex`
```
-loop 1 -i clip.mp4                                   # video, looped to cover narration
-i narration.wav  [-stream_loop -1 -i bgm.mp3]
-filter_complex "
 [0:v]fps=30,scale=W:H:force_original_aspect_ratio=increase,
      scale=1.08W:1.08H,
      crop=W:H:x='(in_w-W)*(t/D)/2':y='(in_h-H)*(t/D)/2',   # slow drift, no zoompan
      setsar=1,format=yuv420p,trim=duration=D,setpts=PTS-STARTPTS[v0];
 [v0][v1][v2]concat=n=3:v=1:a=0[vv];
 [vv]subtitles=filename='captions.ass':fontsdir='fonts'[vout];
 [3:a]highpass=f=80,equalizer=f=210:g=-3,acompressor=…,alimiter=0.94[vo];
 [4:a]volume=<BGM_DB>,afade…[bg]; [vo][bg]amix=inputs=2:duration=first:normalize=0,alimiter[aout]
" -c:v libx264 -preset veryfast -crf 21 -profile:v high -level 4.1 -pix_fmt yuv420p
  -g 60 -sc_threshold 0 -c:a aac -b:a 192k -ar 44100 -movflags +faststart raw.mp4
# pass 2: measure then apply loudnorm (2-run), video stream copied
```
Why each flag is there: `faststart` (IG requires moov-first or uploads fail silently) ·
`-g 60 -sc_threshold 0` (closed GOP ≈2 s, what platforms re-encode cleanly) · `yuv420p` ·
`aresample=44100` (AAC ≤48 kHz, 128 kbps min for IG) · over-scan+`crop` instead of `zoompan`
(zoompan upscales *then* samples → visible shimmer).

**Measured on a 2 vCPU / 2 GB box:** 1080×1920, 3 clips, ~28 s output → 12-16 s wall clock,
0 QC warnings, loudness −14.1 LUFS (target −14), and the pipeline runs 3 videos end-to-end in
~45 s including network. That is roughly **120-200 videos per day per small VPS.**

**QC gate** (`qc.json`) before anything is published: aspect within 2% of 9:16, duration within
0.75 s of narration, 0.5 MB < size < 95 MB, caption count == chunk count, no caption >3.2 s,
no overlaps, and a hard "no render without audio" rule.

---

## 4. Stage 4 — Publishing

Two viable architectures. **Pick per platform, not globally.**

| | Direct official API | One aggregator API |
|---|---|---|
| Cost | $0 + app review | $9-30/mo (Post Bridge, Upload-Post $24, Blotato $29, Postiz self-host $0, Ayrshare $149) |
| Setup | 3 OAuth apps, audits, token refresh, chunked uploads | connect account, one POST |
| Control | full (privacy, duet/stitch flags, AIGC label) | whatever they expose |
| Failure mode | your weekend | their outage / their ToS risk |
| Recommended | **YouTube** (free, easy) | **TikTok + Instagram** (review gates, token churn) |

### Per-platform facts that dictate the code (verified Sept 2026)
- **YouTube Shorts.** `videos.insert` no longer costs 1,600 units: since 4 Dec 2025 it is ~100 and
  since 1 Jun 2026 it bills **1 unit against its own ~100-calls/day bucket** (per *project*, not per
  channel). So 20/day is free. Shorts = ≤3 min + 9:16; there is no API flag. Resumable upload,
  `privacyStatus` or `publishAt` (use `publishAt` = YouTube-native scheduling, saves you a queue).
  ⚠ Since ~24 May 2026 many projects see a **hidden "Video Uploads per day" 429** even with quota
  headroom ([issue](https://github.com/googleapis/google-api-python-client/issues/2753)) — budget
  for it, back off on 429 and retry the next PT-midnight window, never in a loop.
- **Instagram Reels.** 3 calls: `POST /{id}/media (media_type=REELS, video_url)` → poll
  `status_code` → `POST /media_publish`. Video **must** be at a public URL; containers expire;
  processing takes 30-120 s (**so persist the container id** or a worker restart double-posts).
  Specs: 9:16, **5-90 s for Reels-tab eligibility**, H.264/HEVC, AAC ≤48 kHz, ≤100 MB, faststart,
  no HDR, ≤25 Mbps. Publishing cap: Meta's own page says 100 posts/24 h in one section and 50 in
  another → **do not hardcode**; read `GET /{id}/content_publishing_limit` before each burst. Plus a
  separate ~200 calls/hour per user token. Business/Creator account + IG Business Suite membership.
- **TikTok Content Posting API.** `creator_info/query` (20 req/min) → `video/init` (**6 req/min** —
  a burst of 10 fails) → chunked PUT to a 1-hour upload URL (FILE_UPLOAD) *or* PULL_FROM_URL →
  poll `status/fetch`. `privacy_level` is **mandatory** and must be a current option for that
  creator. `title` ≤2200 chars incl. hashtags; min 3 s; ≤4 GB; 1080×1920 preferred; `is_aigc`
  available — label it. Dev mode = everything SELF_ONLY, 5 users/24 h. `video.publish` needs a
  passed audit (weeks; inbox/`video.upload` mode is easier but keeps the creator in the loop).
  **"200 (intentional)" errors** — `reached_active_user_cap` (an app-wide daily publishing-user
  cap, reportedly ~100 and raised only by emailing TikTok support), `spam_risk_too_many_posts`,
  `spam_risk_user_banned_from_posting` — must be treated as **terminal for the day**, not retried.
- **Aggregators** handle all of the above, plus token refresh, for one API key. Postiz is AGPL and
  self-hostable ($0) — the only option that is both cheap *and* your data.

### Queue design (in `orchestrate.py`)
```
platform_slot(platform):
  1. our own cap (PLATFORM_DAILY_CAPS, set well under the platform's)
  2. live headroom probe where the API offers one (IG content_publishing_limit)
  3. min spacing per account (MIN_GAP_MINUTES)  ← the API limits are per-minute AND per-24h
  4. optional PUBLISH_WINDOWS (audience-hours gating)
not available → state stays 'approved' + publish_after = +20 min; after 6 holds → 'failed' (paged)
```
Plus: `publish` JSON per job records container ids/ids/errors, so retries are idempotent and you
can answer "did this actually go out?" from the DB, not by opening 3 apps.

---

## 5. Deployment topologies

| Scale | Host | Cost/mo | Notes |
|---|---|---|---|
| Prototype (2-3 videos/day) | existing laptop + Tailscale funnel for IG/TikTok | $0 | `acp serve` + a cron |
| Solo production (3-10/day) | Hetzner CAX11/CPX11 2-4 GB ARM/x86 | $5-10 | renders fine; add `nice -n 10` |
| Batch-render elsewhere | Mac mini M4 (VideoToolbox `h264_videotoolbox`) + tiny VPS for the queue | $5 + owned | 5-10× faster encode, silent |
| Many channels | 4× c6i.2xlarge + S3 + SQS/Celery (or Modal/Ray) | $60-300 | only once you have >50 videos/day |

Data plane: **R2** (free 10 GB, free egress) for the public video URL, `pipeline.db` in WAL with a
daily `sqlite3 .backup`, and `assets/cache` on disk (cheap, keeps re-renders at $0). Nothing else
needs to be durable — a job's intermediates are disposable.

---

## 6. Data contracts (so you can swap any stage)

| Artifact | Producer | Shape | Consumed by |
|---|---|---|---|
| `jobs` row | stage 1 | state, idea, source_url, score, cost_usd, attempts, publish_after, approved | everything |
| `payload.script` | stage 2 | hook, script_sentences[], keywords[], title, description, hashtags[], claims_to_verify[] | 3a/3b/3c/4 |
| `payload.assets` | 3a | clips[], clip_meta[{path,duration,bytes,credit}], bytes, api_calls | 3d |
| `timings.json` | 3b | captions[{start,end,text,words[[w,s,e]]}], duration, max_chunk, provider, words_per_second_measured | 3c/3d/QC |
| `captions.ass` / `.vtt` | 3c | ASS + WebVTT | 3d (burn) + stage 4 (track) |
| `qc.json` | 3d | duration, aspect, size_mb, warnings[], loudnorm | approval gate |
| `payload.publish` | stage 4 | {platform: {id,url,at,error,held}} | audit + retries |
