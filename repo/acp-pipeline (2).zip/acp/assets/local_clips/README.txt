Drop your own vertical clips here (mp4/mov). Best ROI footage source.
