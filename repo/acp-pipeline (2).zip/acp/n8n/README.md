# n8n wiring (3 workflows, import as-is)

The Python pipeline owns every stage; n8n only owns **when**, **who approves**, and **alert me**.
That split is deliberate: put rendering logic in a workflow and you get a 40-node canvas you cannot
debug, cannot version, and cannot test.

```
ACP 1 - generate      schedule → POST /trends → per job: /script → /render → QC? → approval ping
ACP 2 - approve+publish  telegram/webhook "approve 42" → /approve → GET /publishable → /publish → wait → loop
ACP 3 - watchdog      hourly: /status → alert if cost>90% budget or failed+stuck>3, else drain queue
```

Import: n8n → Workflows → **⋯ → Import from File** → pick each `acp-*.json`. Then in each HTTP node
set the **Base URL credential** to `http://acp:8787` (compose) or `http://host.docker.internal:8787`
(n8n in Docker, pipeline on the host), plus `Authorization: Bearer $ACP_CONTROL_TOKEN`.

Two things to fix per install:
1. **The host in every HTTP node** — replace `https://ACP-HOST.example:8787`. Nothing else about the
   URLs is dynamic; the pipeline needs no n8n env vars.
2. **`chatUserId`** in the three Telegram nodes (or swap those nodes for Slack/Discord/Bluesky/Email —
   approval is just "POST /jobs/:id/approve or /reject", any channel works).

Why the shapes are what they are:
* **cron, not fixed-interval**, in ACP 1: a long render must not shift the rest of the day.
* `/script` and `/render` are **separate calls** so a bad script costs one LLM call, never render
  minutes, and so you can retry stage 2 without touching ffmpeg.
* **QC gate before the approval ping** (`render.warnings.length == 0`): blocks publish requests for
  off-aspect / oversized / drifting renders. You should not be asked to approve a broken file.
* **`GET /publishable`, not "publish everything approved"** — the caps, IG's
  `content_publishing_limit` headroom, per-account spacing and `PUBLISH_WINDOWS` are all decided in
  Python, where they can be unit-tested. n8n just loops the returned list.
* **Wait 120 min between publishes** in ACP 2: TikTok's `video/init` is 6 req/min and IG's cap is a
  rolling 24 h window; a loop with no sleep converts a working queue into a rate-limited one.
* `settings.timezone` is set per workflow — schedule drift across timezones is the #1 "why did it
  fire at 3am" report.

Make.com note: the same 4 HTTP calls map 1:1 (Schedule → HTTP: POST /trends → Iterate → HTTP:
/script → /render → Router on `state` → Slack approval → HTTP: /approve → /publishable → /publish).
Make's free tier (1,000 operations/mo) is fine for 3 videos/day: each video is ~8 operations.
