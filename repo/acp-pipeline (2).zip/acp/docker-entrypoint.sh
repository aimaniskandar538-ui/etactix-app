#!/usr/bin/sh
# Container entrypoint: fix bind-mount ownership once, drop root, then exec a subcommand.
#
# Why: renders land in a bind-mounted ./work, owned by whoever created it on the host.
# A non-root container writing into it gets EACCES - the single most common "works on my
# machine, dies in Docker" for this pipeline. If you start as root and ACP_FIX_OWNERSHIP=1,
# we chown the writable dirs once and then drop to uid 1000 (or APP_UID).
set -eu

CMD_NAME="${1:-api}"

if [ "$(id -u)" = "0" ] && [ "${ACP_FIX_OWNERSHIP:-1}" = "1" ]; then
  chown -R "${APP_UID:-1000}:${APP_GID:-1000}" /app/work /app/assets /app/secrets 2>/dev/null || true
  exec gosu "${APP_UID:-1000}" "$0" "$@"
fi

cd /app
# Renders are CPU-saturated by design; renicing keeps the API + publisher responsive on a
# 1-2 vCPU box instead of turning a render into a 20-second HTTP timeout.
if [ -n "${ACP_NICE:-}" ] && command -v renice >/dev/null 2>&1; then
  renice -n "$ACP_NICE" -p $$ >/dev/null 2>&1 || true
fi

case "$CMD_NAME" in
  api)
    # HTTP control plane for n8n / Make / the approval buttons.
    exec python -m acp.cli serve
    ;;
  menu)
    # Interactive dispatcher; needs `docker compose run -it`.
    exec python -m acp.cli menu
    ;;
  worker)
    # Long-running render+publish loop. ACP_LOOP_INTERVAL (s) sets the cadence.
    exec python -m acp.cli loop --interval "${ACP_LOOP_INTERVAL:-21600}" --limit "${ACP_LIMIT:-2}"
    ;;
  render-only)
    exec python -m acp.cli loop --interval "${ACP_LOOP_INTERVAL:-21600}" --limit "${ACP_LIMIT:-2}" --no-publish
    ;;
  once)
    # Single pass then exit - what a cron job or GitHub Action should run.
    if [ "${ACP_PUBLISH:-0}" = "1" ]; then
      exec python -m acp.cli loop --once --limit "${ACP_LIMIT:-2}"
    fi
    exec python -m acp.cli loop --once --limit "${ACP_LIMIT:-2}" --no-publish
    ;;
  smoke)
    # Offline end-to-end: no accounts, no spend. Use it to prove the image renders.
    exec bash scripts/smoke.sh
    ;;
  test)
    exec python -m pytest tests -q
    ;;
  *)
    # any acp subcommand: `docker compose run --rm acp-api trends -n 10`.
    # "$@" (not "$CMD_NAME") so arguments survive, and the case arm above already matched
    # the known entrypoints - an unknown first word here is a real acp command.
    exec python -m acp.cli "$@"
    ;;

esac
