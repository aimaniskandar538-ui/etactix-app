"""
Configuration for the Autonomous Content Pipeline (ACP).

Zero required external deps: .env is parsed by hand so the repo runs on a bare VPS
with nothing but `pip install requests`.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "work"
ASSETS = ROOT / "assets"


def _strip_inline_comment(raw: str) -> str:
    """Drop a trailing ` # comment`, but never inside quotes.

    This matters because .env.example documents values inline:
        PUBLISH_WINDOWS=9-22   # local hours you allow publishing
    Without stripping, the value becomes "9-22   # local hours..." and the first thing
    it does is crash the publish queue on int() - and ACP_CONTROL_TOKEN= (deliberately
    empty) silently turns the API into an auth wall that nothing can pass.
    """
    s = raw.strip()
    if s[:1] in ('"', "'"):
        q = s[0]
        end = s.find(q, 1)
        return s[1:end] if end > 0 else s.strip(q)
    cut = s.find(" #")
    if cut == -1 and s.startswith("#"):
        return ""
    return (s[:cut] if cut != -1 else s).strip()


def load_dotenv(path: Path | None = None) -> None:
    """Minimal .env loader (no python-dotenv). Values already in the environment win."""
    p = path or (ROOT / ".env")
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = _strip_inline_comment(v)
        if not v:  # an empty value means "unset" - it must not shadow a real env var
            continue
        os.environ.setdefault(k.strip(), v)


def _b(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


# (the loader already drops empty values, so `KEY=` in .env.example never reaches here)


def _num(name: str):
    """Tolerant numeric parse: leading number wins, so a stray suffix or comment in a
    hand-edited .env degrades to the default instead of raising deep inside the queue."""
    raw = os.getenv(name, "") or ""
    m = re.match(r"\s*(-?\d+(?:\.\d+)?)", raw)
    return float(m.group(1)) if m else None


def _f(name: str, default: float) -> float:
    v = _num(name)
    return default if v is None else v


def _i(name: str, default: int) -> int:
    v = _num(name)
    return default if v is None else int(v)


def _resolve_fonts_dir() -> Path:
    env = os.getenv("FONTS_DIR", "")
    if env:
        return Path(env)
    for cand in (ROOT / "fonts", Path("/usr/share/acp-fonts")):
        if cand.exists() and any(cand.glob("*.*t[tf]")):
            return cand
    return ROOT / "fonts"


@dataclass
class Settings:
    # --- paths / runtime -------------------------------------------------
    # WORK_DIR lets you run a scratch/isolated pipeline (CI, A/B of a new prompt, a second
    # channel on the same box) without touching the production queue.
    work_dir: Path = field(default_factory=lambda: Path(os.getenv("WORK_DIR") or WORK))
    db_path: Path = field(default_factory=lambda: Path(os.getenv("DB_PATH") or (Path(os.getenv("WORK_DIR") or WORK)) / "pipeline.db"))
    # Resolution order: FONTS_DIR (explicit) -> ./fonts (repo checkout) -> the baked-in copy
    # at /usr/share/acp-fonts (set by the Dockerfile, survives a bind mount over /app).
    fonts_dir: Path = field(default_factory=lambda: _resolve_fonts_dir())
    ffmpeg_bin: str = field(default_factory=lambda: os.getenv("FFMPEG_BIN", "ffmpeg"))
    ffprobe_bin: str = field(default_factory=lambda: os.getenv("FFPROBE_BIN", "ffprobe"))
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))

    # --- stage 1: discovery ---------------------------------------------
    geo: str = field(default_factory=lambda: os.getenv("GEO", "US"))
    hl: str = field(default_factory=lambda: os.getenv("HL", "en-US"))
    ideas_per_run: int = field(default_factory=lambda: _i("IDEAS_PER_RUN", 2))
    trends_weight: float = field(default_factory=lambda: _f("TRENDS_WEIGHT", 1.0))
    news_weight: float = field(default_factory=lambda: _f("NEWS_WEIGHT", 0.85))
    reddit_weight: float = field(default_factory=lambda: _f("REDDIT_WEIGHT", 0.7))
    hn_weight: float = field(default_factory=lambda: _f("HN_WEIGHT", 0.6))
    yt_trend_channel_ids: str = field(default_factory=lambda: os.getenv("YT_TREND_CHANNEL_IDS", ""))
    reddit_subreddits: str = field(default_factory=lambda: os.getenv("REDDIT_SUBREDDITS", "all"))
    http_user_agent: str = field(
        default_factory=lambda: os.getenv(
            "HTTP_USER_AGENT", "Mozilla/5.0 (compatible; acp-pipeline/1.0; +https://example.com/bot)"
        )
    )
    dedup_days: int = field(default_factory=lambda: _i("DEDUP_DAYS", 30))

    # --- stage 2: script / prompts --------------------------------------
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "openai"))
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "gpt-4o-mini"))
    llm_base_url: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL", "https://api.openai.com/v1"))
    llm_api_key: str = field(default_factory=lambda: os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY", ""))
    llm_max_output_tokens: int = field(default_factory=lambda: _i("LLM_MAX_OUTPUT_TOKENS", 1400))
    llm_temperature: float = field(default_factory=lambda: _f("LLM_TEMPERATURE", 0.85))
    target_seconds: int = field(default_factory=lambda: _i("TARGET_SECONDS", 28))
    words_per_second: float = field(default_factory=lambda: _f("WORDS_PER_SECOND", 2.2))
    max_cps: int = field(default_factory=lambda: _i("MAX_CPS", 42))  # caption chars per screen
    # Characters that fit on ONE line at CAPTION_SIZE for a condensed display font
    # (Anton ~0.46em per char). Chunk budget = min(MAX_CPS, 2 * this). Raise it only
    # if you also lower CAPTION_SIZE, or libass will wrap you into a word-per-line tower.
    chars_per_line: int = field(default_factory=lambda: _i("CHARS_PER_LINE", 0))
    niche: str = field(default_factory=lambda: os.getenv("NICHE", ""))   # empty = pure trend mode
    brand_voice: str = field(default_factory=lambda: os.getenv("BRAND_VOICE", ""))
    language: str = field(default_factory=lambda: os.getenv("CONTENT_LANG", "en"))

    # --- stage 3a: footage ----------------------------------------------
    asset_provider: str = field(default_factory=lambda: os.getenv("ASSET_PROVIDER", "pexels"))
    pexels_key: str = field(default_factory=lambda: os.getenv("PEXELS_API_KEY", ""))
    pixabay_key: str = field(default_factory=lambda: os.getenv("PIXABAY_API_KEY", ""))
    coverr_key: str = field(default_factory=lambda: os.getenv("COVERR_API_KEY", ""))
    clips_per_video: int = field(default_factory=lambda: _i("CLIPS_PER_VIDEO", 1))  # 1 = cheapest
    download_max_bytes: int = field(default_factory=lambda: _i("DOWNLOAD_MAX_MB", 60) * 1_000_000)
    min_clip_seconds: float = field(default_factory=lambda: _f("MIN_CLIP_SECONDS", 4.0))

    # --- stage 3b: voice -------------------------------------------------
    tts_provider: str = field(default_factory=lambda: os.getenv("TTS_PROVIDER", "edge"))
    edge_voice: str = field(default_factory=lambda: os.getenv("EDGE_VOICE", "en-US-AriaNeural"))
    edge_rate: str = field(default_factory=lambda: os.getenv("EDGE_RATE", "+8%"))
    azure_key: str = field(default_factory=lambda: os.getenv("AZURE_SPEECH_KEY", ""))
    azure_region: str = field(default_factory=lambda: os.getenv("AZURE_SPEECH_REGION", "swedencentral"))
    azure_voice: str = field(default_factory=lambda: os.getenv("AZURE_VOICE", "en-US-AvaMultilingualNeural"))
    openai_tts_model: str = field(default_factory=lambda: os.getenv("OPENAI_TTS_MODEL", "gpt-4o-mini-tts"))
    openai_tts_voice: str = field(default_factory=lambda: os.getenv("OPENAI_TTS_VOICE", "nova"))
    elevenlabs_key: str = field(default_factory=lambda: os.getenv("ELEVENLABS_API_KEY", ""))
    elevenlabs_voice: str = field(default_factory=lambda: os.getenv("ELEVENLABS_VOICE_ID", "21m00Tcm4TlvDq8ikWAM"))
    gap_seconds: float = field(default_factory=lambda: _f("TTS_GAP_SECONDS", 0.16))

    # --- stage 3c: render ------------------------------------------------
    video_w: int = field(default_factory=lambda: _i("VIDEO_W", 1080))
    video_h: int = field(default_factory=lambda: _i("VIDEO_H", 1920))
    fps: int = field(default_factory=lambda: _i("FPS", 30))
    x264_preset: str = field(default_factory=lambda: os.getenv("X264_PRESET", "veryfast"))
    # "" = probe the ffmpeg build and pick the fastest encoder it actually has
    # (h264_nvenc -> h264_videotoolbox -> h264_vaapi -> libx264). Override to pin one.
    video_encoder: str = field(default_factory=lambda: os.getenv("FFMPEG_ENCODER", ""))
    crf: int = field(default_factory=lambda: _i("CRF", 21))
    target_lufs: float = field(default_factory=lambda: _f("TARGET_LUFS", -14.0))
    bgm_db: float = field(default_factory=lambda: _f("BGM_DB", -18.0))
    caption_font: str = field(default_factory=lambda: os.getenv("CAPTION_FONT", "Arial"))
    caption_size: int = field(default_factory=lambda: _i("CAPTION_SIZE", 86))
    caption_style: str = field(default_factory=lambda: os.getenv("CAPTION_STYLE", "karaoke"))  # karaoke|block
    motion: str = field(default_factory=lambda: os.getenv("MOTION", "slowzoom"))  # none|slowzoom
    music_file: str = field(default_factory=lambda: os.getenv("BGM_FILE", str(ASSETS / "music" / "Silence.mp3")))

    # --- stage 4: publishing --------------------------------------------
    public_base_url: str = field(default_factory=lambda: os.getenv("PUBLIC_BASE_URL", ""))
    media_dir: Path = field(default_factory=lambda: Path(os.getenv("MEDIA_DIR", str(WORK / "public"))))
    auto_publish: bool = field(default_factory=lambda: _b("AUTO_PUBLISH", False))
    require_approval: bool = field(default_factory=lambda: _b("REQUIRE_APPROVAL", True))
    youtube_credentials: str = field(default_factory=lambda: os.getenv("YOUTUBE_CLIENT_SECRETS", ""))
    youtube_token: str = field(default_factory=lambda: os.getenv("YOUTUBE_TOKEN_PATH", str(ROOT / "secrets" / "yt.token")))
    ig_user_id: str = field(default_factory=lambda: os.getenv("IG_USER_ID", ""))
    ig_token: str = field(default_factory=lambda: os.getenv("IG_ACCESS_TOKEN", ""))
    tiktok_client_key: str = field(default_factory=lambda: os.getenv("TIKTOK_CLIENT_KEY", ""))
    tiktok_client_secret: str = field(default_factory=lambda: os.getenv("TIKTOK_CLIENT_SECRET", ""))
    tiktok_token_path: str = field(default_factory=lambda: os.getenv("TIKTOK_TOKEN_PATH", str(ROOT / "secrets" / "tiktok.token")))
    postiz_key: str = field(default_factory=lambda: os.getenv("POSTIZ_API_KEY", ""))
    postiz_base_url: str = field(default_factory=lambda: os.getenv("POSTIZ_BASE_URL", "https://api.postiz.com"))
    uploadpost_key: str = field(default_factory=lambda: os.getenv("UPLOADPOST_API_KEY", ""))
    platforms: str = field(default_factory=lambda: os.getenv("PLATFORMS", "youtube"))
    platform_daily_caps: str = field(
        default_factory=lambda: os.getenv("PLATFORM_DAILY_CAPS", "youtube:20,instagram:3,tiktok:3,postiz:20,uploadpost:20")
    )
    min_gap_minutes: int = field(default_factory=lambda: _i("MIN_GAP_MINUTES", 90))

    # --- guardrails ------------------------------------------------------
    daily_budget_usd: float = field(default_factory=lambda: _f("DAILY_BUDGET_USD", 2.0))
    control_token: str = field(default_factory=lambda: os.getenv("ACP_CONTROL_TOKEN", ""))
    control_port: int = field(default_factory=lambda: _i("ACP_CONTROL_PORT", 8787))

    def caps(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for part in self.platform_daily_caps.split(","):
            if ":" in part:
                k, v = part.split(":", 1)
                try:
                    out[k.strip()] = int(v)
                except ValueError:
                    pass
        return out


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        load_dotenv()
        WORK.mkdir(parents=True, exist_ok=True)
        _settings = Settings()
        _settings.work_dir.mkdir(parents=True, exist_ok=True)
        _settings.media_dir.mkdir(parents=True, exist_ok=True)
    return _settings
