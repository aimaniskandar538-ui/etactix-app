"""Small shared helpers: logging, retries, ffmpeg probing, hashing."""
from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from typing import Any

log = logging.getLogger("acp")


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
        stream=sys.stdout,
        datefmt="%H:%M:%S",
    )
    for noisy in ("urllib3", "asyncio", "edge_tts"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def which(bin_name: str) -> str | None:
    return shutil.which(bin_name)


def probe(media: str | None) -> dict[str, Any]:
    """ffprobe -> {'duration': float, 'width': int, 'height': int}. Safe on missing files."""
    from .config import get_settings

    s = get_settings()
    if not media or not Path_exists(media):
        return {"duration": 0.0, "width": 0, "height": 0}
    cmd = [
        s.ffprobe_bin, "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height,r_frame_rate:format=duration",
        "-of", "json", str(media),
    ]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=60).stdout
        data = json.loads(out or "{}")
        st = (data.get("streams") or [{}])[0]
        return {
            "duration": float(data.get("format", {}).get("duration", 0.0) or 0.0),
            "width": int(st.get("width") or 0),
            "height": int(st.get("height") or 0),
        }
    except Exception as e:  # noqa: BLE001 - probing must never kill a pipeline run
        log.warning("ffprobe failed for %s: %s", media, e)
        return {"duration": 0.0, "width": 0, "height": 0}


def Path_exists(p: str) -> bool:
    from pathlib import Path

    return Path(p).exists()


def run(cmd: list[str], timeout: int = 900, check: bool = True) -> subprocess.CompletedProcess:
    log.debug("exec: %s", " ".join(str(c) for c in cmd))
    t0 = time.time()
    cp = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, timeout=timeout)
    if check and cp.returncode != 0:
        tail = (cp.stderr or cp.stdout or "")[-2000:]
        raise RuntimeError(f"command failed ({cp.returncode}): {tail}")
    log.debug("exec done in %.1fs", time.time() - t0)
    return cp


def sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", "ignore")).hexdigest()[:16]


def retry(times: int = 3, base_delay: float = 1.5, retry_on=(Exception,)):
    def deco(fn):
        def wrapper(*a, **kw):
            last: Exception | None = None
            for i in range(times):
                try:
                    return fn(*a, **kw)
                except retry_on as e:  # noqa: PERF203
                    last = e
                    sleep = base_delay * (2**i)
                    msg = str(e).lower()
                    throttled = ("429" in msg) or ("rate limit" in msg) or ("too many" in msg)
                    if throttled:
                        sleep *= 3  # be polite; the API told us to slow down
                    log.warning("retry %s/%s after error: %s", i + 1, times, str(e)[:180])
                    time.sleep(sleep)
            raise last if last else RuntimeError("unknown failure")

        return wrapper

    return deco


def strip_ns(xml: str) -> ET.Element:
    """Parse RSS/Atom. We keep namespace URIs (stripping the xmlns declarations, as many
    tutorials do, breaks feeds that use an undeclared-on-element prefix like Google
    Trends' <ht:keyword>). Use local_name()/findtext_ns() for terse lookups instead."""
    return ET.fromstring(xml)


def local_name(tag) -> str:
    """'{http://...}title' -> 'title'; plain tags pass through."""
    return str(tag).rsplit("}", 1)[-1]


def findtext_ns(el: ET.Element | None, local: str, default: str = "") -> str:
    """First direct child with this local name (any namespace), else default."""
    if el is None:
        return default
    for child in el:
        if local_name(child.tag) == local:
            return (child.text or default).strip()
    return default


def iter_local(el: ET.Element, local: str):
    for child in el.iter():
        if local_name(child.tag) == local:
            yield child


def words(text: str) -> int:
    return len(re.findall(r"\w+", text or "", flags=re.UNICODE))


def tsv_safe(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def read_json_if_exists(path: str | None) -> dict | None:
    import pathlib

    if not path:
        return None
    # Guard the exact mistake that caused an obscure pipeline failure: callers sometimes pass
    # inline JSON instead of a path. pathlib would raise ENAMETOOLONG (>NAME_MAX) or quietly
    # return None (shorter), so detect it here and parse it as what it is.
    looks_like_json = path.lstrip()[:1] in "{["
    if looks_like_json and len(path) > 255:
        try:
            import json as _json
            v = _json.loads(path)
            return v if isinstance(v, dict) else None
        except Exception:
            return None
    p = pathlib.Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return None


def human(n: float | None) -> str:
    if n is None:
        return "-"
    if n < 1:
        return f"${n*100:.1f}c"
    return f"${n:.2f}"
