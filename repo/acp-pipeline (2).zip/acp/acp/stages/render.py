"""
STAGE 3d - Assembly + render (pure FFmpeg: one encode pass + one audio pass).

Why not MoviePy on a $5 VPS: MoviePy holds decoded frames in Python and spawns a
subprocess per operation; a 1080x1920@30 job peaks at 1.5-3 GB RSS and gets
OOM-killed on a 2 GB box. One ffmpeg filter_complex peaks around 150-300 MB,
streams instead of buffering, and needs no intermediate files.

Pass 1: clips -> scale/crop to canvas (+ slow zoom drift) -> concat -> burn ASS
        captions -> mix narration + BGM -> H.264/AAC, faststart.
Pass 2: two-run loudnorm to -14 LUFS (TikTok/Reels/Shorts safe), video stream
        copied so quality and caption burn-in are untouched.

Deterministic: same script + same clips -> same frame count.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

from ..config import get_settings
from ..util import log, probe, retry, run

MAX_CAPTION_SECONDS = 3.0  # keep in sync with stages/speech.py


ENCODER_ORDER = ("libx264a",)  # placeholder, replaced below


def pick_encoder(s, available: set[str] | None = None) -> tuple[str, list[str]]:
    """Fastest encoder this ffmpeg build actually supports -> (name, extra flags).

    Hardware encoders are 5-10x cheaper than x264 per rendered second, but they only
    exist if the build was compiled with them and the device is present - so probe
    once at render time instead of trusting config. Falls back to libx264, which works
    everywhere.
    """
    import subprocess

    if available is None:
        try:
            out = subprocess.run([s.ffmpeg_bin, "-hide_banner", "-encoders"],
                                 capture_output=True, text=True, timeout=30).stdout
            available = {ln.split()[1] for ln in out.splitlines()
                         if ln.startswith(" V") and len(ln.split()) > 1}
        except Exception:  # noqa: BLE001 - probe failed, let x264 be the safe default
            available = set()
    wanted = (s.video_encoder,) if s.video_encoder else (
        "h264_nvenc", "h264_videotoolbox", "h264_amf", "h264_qsv", "h264_vaapi", "libx264")
    for enc in wanted:
        if enc in available:
            if enc == "h264_nvenc":
                return enc, ["-preset", "p5", "-rc", "vbr", "-cq", str(min(51, s.crf + 7)), "-b:v", "0"]
            if enc == "h264_videotoolbox":
                return enc, ["-q:v", str(max(1, 100 - s.crf * 3))]
            if enc in ("h264_amf", "h264_qsv"):
                return enc, ["-quality", "balanced"]
            if enc == "h264_vaapi":
                return enc, ["-global_quality", str(s.crf + 4)]
            return enc, ["-preset", s.x264_preset, "-crf", str(s.crf), "-profile:v", "high", "-level", "4.1"]
    return "libx264", ["-preset", s.x264_preset, "-crf", str(s.crf), "-profile:v", "high", "-level", "4.1"]


def _esc(path: str) -> str:
    """Escape for ffmpeg filtergraph filenames (colons/backslashes are the classic footgun)."""
    return str(path).replace("\\", "/").replace(":", "\\:")


def _fmt(t: float) -> str:
    return f"{max(0.0, float(t)):.3f}"


def dur_for(i: int, total: float, n: int) -> float:
    """Even-slice fallback used by callers that have no source-length info."""
    return total / n if i < n - 1 else max(0.4, total - i * (total / n))


def plan_clips(assets: dict, total: float, s) -> list[dict]:
    """Map clips onto the narration timeline.

    Clips shorter than their even slice are used at full length (trimming them
    wastes footage) and the leftover time is redistributed proportionally over the
    clips that can absorb it. Sources that still cannot fill their slot get
    -stream_loop applied, so the frame count always equals duration*fps exactly.
    """
    clips = [c for c in (assets.get("clip_meta") or []) if c.get("path") or c.get("url")]
    if not clips:
        raise RuntimeError("render called with no clips")
    n = len(clips)
    avail = [float(c.get("probe", {}).get("duration") or 0.0) for c in clips]
    even = total / n
    dur = [min(avail[i], even) if avail[i] > 0 else even for i in range(n)]
    short = sum(dur)
    room = [max(0.0, (avail[i] or total) - dur[i]) if avail[i] > 0 else total - dur[i] for i in range(n)]
    left = max(0.0, total - short)
    cap = sum(room) or 1.0
    for i in range(n):
        dur[i] += left * (room[i] / cap)
    drift = total - sum(dur)
    if abs(drift) > 1e-9 and n:
        dur[-1] = max(0.4, dur[-1] + drift)
    out = []
    for i, c in enumerate(clips):
        out.append(
            {
                "src": c.get("path") or c.get("url"),
                "dur": round(dur[i], 3),
                "avail": avail[i],
                "needs_loop": bool(0 < avail[i] < dur[i] - 0.05),
            }
        )
    return out


def build_video_filter(parts: list[dict], s, ass: str | None) -> str:
    fc: list[str] = []
    for i, p in enumerate(parts):
        f = [f"fps={s.fps}", f"scale={s.video_w}:{s.video_h}:force_original_aspect_ratio=increase"]
        if s.motion == "slowzoom":
            # overscan 8% then drift the crop window: cheaper and sharper than zoompan
            f.append(f"scale={int(s.video_w * 1.08)}:{int(s.video_h * 1.08)}")
            d = _fmt(p["dur"])
            f.append(f"crop={s.video_w}:{s.video_h}:x='(in_w-{s.video_w})*(t/{d})/2':y='(in_h-{s.video_h})*(t/{d})/2'")
        else:
            f.append(f"crop={s.video_w}:{s.video_h}")
        f += ["setsar=1", "format=yuv420p", f"trim=duration={_fmt(p['dur'])}", "setpts=PTS-STARTPTS"]
        fc.append(f"[{i}:v]" + ",".join(f) + f"[v{i}]")
    if len(parts) == 1:
        fc.append("[v0]null[vv]")
    else:
        fc.append("".join(f"[v{i}]" for i in range(len(parts))) + f"concat=n={len(parts)}:v=1:a=0[vv]")
    if ass and Path(ass).exists():
        fc.append(f"[vv]subtitles=filename='{_esc(ass)}':fontsdir='{_esc(str(s.fonts_dir))}'[vout]")
    else:
        fc.append("[vv]null[vout]")
    return ";".join(fc)


def build_audio_filter(parts_count: int, s, has_voice: bool, bgm: str | None, total: float) -> tuple[str, bool]:
    idx = parts_count
    chains: list[str] = []
    if not has_voice:
        chains.append(f"anullsrc=r=44100:cl=stereo,atrim=duration={_fmt(total)}[aout]")
        return ";".join(chains), False
    chains.append(
        f"[{idx}:a]highpass=f=80,equalizer=f=210:t=q:w=1.2:g=-3,"
        "acompressor=threshold=0.12:ratio=3:attack=8:release=180:makeup=1.6,"
        "alimiter=limit=0.94[vo]"
    )
    if bgm:
        vol = math.pow(10, s.bgm_db / 20)
        fade_start = max(0.1, total - 0.9)
        chains.append(
            f"[{idx+1}:a]aformat=sample_rates=44100:channel_layouts=stereo,"
            f"volume={vol:.4f},afade=t=in:st=0:d=0.6,afade=t=out:st={_fmt(fade_start)}:d=0.9[bg]"
        )
        chains.append("[vo][bg]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,alimiter=limit=0.97[aout]")
        return ";".join(chains), True
    chains.append("[vo]alimiter=limit=0.97[aout]")
    return ";".join(chains), False


def _parse_loudnorm(text: str) -> dict | None:
    try:
        raw = json.loads(text[text.rindex("{") : text.rindex("}") + 1])
        return {
            "input_output_i": raw.get("input_i"),
            "input_lra": raw.get("input_lra"),
            "input_threshold": raw.get("input_threshold"),
            "true_peak": raw.get("input_tp"),
            "target_offset": raw.get("target_offset"),
        }
    except (ValueError, json.JSONDecodeError):
        return None


@retry(times=2)
def render(job_dir: Path, script: dict, assets: dict, timings: dict) -> dict:
    s = get_settings()
    job_dir.mkdir(parents=True, exist_ok=True)
    total = float(timings.get("duration") or script.get("estimated_seconds") or 20.0)
    caps = timings.get("captions") or []
    if caps:  # never cut the final caption mid-word: the hold lives past the last audio sample
        total = max(total, float(caps[-1]["end"]) + 0.10)
    parts = plan_clips(assets, total, s)

    cmd: list[str] = [s.ffmpeg_bin, "-hide_banner", "-loglevel", "error", "-y"]
    for p in parts:
        if p["needs_loop"]:
            cmd += ["-stream_loop", str(max(1, math.ceil(p["dur"] / max(0.5, p["avail"]))))]
        cmd += ["-i", p["src"]]

    narration = timings.get("audio") or str(job_dir / "narration.wav")
    has_voice = Path(narration).exists()
    bgm = s.music_file if Path(s.music_file).exists() and Path(s.music_file).stat().st_size > 40_000 else None
    if has_voice:
        cmd += ["-i", narration]
    if bgm:
        cmd += ["-stream_loop", "-1", "-i", bgm]

    vfilter = build_video_filter(parts, s, timings.get("ass"))
    afilter, _ = build_audio_filter(len(parts), s, has_voice, bgm, total)
    encoder, enc_flags = pick_encoder(s)
    if encoder != "libx264":
        log.info("using %s (hardware encoder detected)", encoder)
    raw = job_dir / "raw.mp4"
    cmd += [
        "-filter_complex", f"{vfilter};{afilter}",
        "-map", "[vout]", "-map", "[aout]", "-t", _fmt(total),
        "-r", str(s.fps),
        "-c:v", encoder, *enc_flags, "-pix_fmt", "yuv420p",
        *(["-g", str(s.fps * 2), "-keyint_min", str(s.fps), "-sc_threshold", "0"] if encoder == "libx264" else ["-g", str(s.fps * 2)]),
        "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2",
        "-movflags", "+faststart", "-shortest", str(raw),
    ]
    log.info("render pass 1: %s clips -> %.1fs @ %sx%s via %s", len(parts), total, s.video_w, s.video_h, encoder)
    run(cmd, timeout=1800)

    out = job_dir / "final.mp4"
    meas = None
    if has_voice:
        pre = run([s.ffmpeg_bin, "-hide_banner", "-nostats", "-i", str(raw), "-af",
                   f"loudnorm=I={s.target_lufs}:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                  timeout=600, check=False)
        meas = _parse_loudnorm(pre.stderr or "")
    af = f"loudnorm=I={s.target_lufs}:TP=-1.5:LRA=11"
    if meas and all(meas.get(k) is not None for k in ("input_output_i", "input_lra", "input_threshold", "true_peak", "target_offset")):
        af += (f":measured_I={meas['input_output_i']}:measured_TP={meas['true_peak']}"
               f":measured_LRA={meas['input_lra']}:measured_thresh={meas['input_threshold']}"
               f":offset={meas['target_offset']}:linear=true")
    run([s.ffmpeg_bin, "-hide_banner", "-loglevel", "error", "-y", "-i", str(raw), "-af", af,
         "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2",
         "-movflags", "+faststart", str(out)], timeout=600)

    meta = probe(str(out))
    size = out.stat().st_size
    qc: dict = {
        "video": str(out),
        "encoder": encoder,
        "duration": round(meta["duration"], 2),
        "expected": round(total, 2),
        "seconds_off": round(abs(meta["duration"] - total), 2),
        "width": meta["width"],
        "height": meta["height"],
        "size_mb": round(size / 1e6, 2),
        "aspect": round(meta["width"] / meta["height"], 4) if meta["height"] else 0,
        "bgm": bool(bgm),
        "loudnorm": meas,
        "warnings": [],
    }
    if qc["seconds_off"] > 0.75:
        qc["warnings"].append(f"duration drift {qc['seconds_off']}s vs narration")
    if qc["size_mb"] > 95:
        qc["warnings"].append("file >95MB: Instagram API caps Reels at 100MB - raise CRF or shorten")
    if qc["aspect"] and abs(qc["aspect"] - 9 / 16) > 0.02:
        qc["warnings"].append(f"aspect {qc['aspect']:.3f} is not 9:16 - Reels-tab eligibility at risk")
    if qc["size_mb"] < 0.4:
        qc["warnings"].append("suspiciously small file - likely a failed/black render")
    if meta["duration"] and (meta["duration"] < 3):
        qc["warnings"].append("under 3s: TikTok rejects clips shorter than 3 seconds")
    if not has_voice:
        qc["warnings"].append("no narration audio track mixed")
    if timings.get("max_chunk", 0) and float(timings["max_chunk"]) > MAX_CAPTION_SECONDS + 0.05:
        qc["warnings"].append(f"slowest caption is {timings['max_chunk']}s - raise WORDS_PER_SECOND budget or lower MAX_CPS")
    if timings.get("words_per_second_measured"):
        qc["words_per_second_measured"] = timings["words_per_second_measured"]

    (job_dir / "qc.json").write_text(json.dumps({k: v for k, v in qc.items() if k != "video"}, indent=1))
    (job_dir / "render_meta.json").write_text(
        json.dumps({"parts": [{k: p[k] for k in ('dur', 'avail', 'needs_loop')} for p in parts],
                    "vfilter": vfilter[:2000], "afilter": afilter, "clip_count": len(parts)}, indent=1)
    )
    log.info("render done: %.1f MB, %.2fs, %s warning(s)", qc["size_mb"], qc["duration"], len(qc["warnings"]))
    return qc


def selfcheck(s) -> dict:
    """Can this box render at all? Used by `acp selftest`."""
    import subprocess

    out = {"ffmpeg": None, "has_subtitles": False, "has_libx264": False, "has_aac": False,
           "fonts_dir": str(s.fonts_dir), "font_files": 0}
    try:
        out["ffmpeg"] = subprocess.run([s.ffmpeg_bin, "-version"], capture_output=True, text=True, timeout=20).stdout.splitlines()[0]
        fv = subprocess.run([s.ffmpeg_bin, "-hide_banner", "-filters"], capture_output=True, text=True).stdout
        av = subprocess.run([s.ffmpeg_bin, "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
        out["has_subtitles"] = "subtitles" in fv
        out["encoders_h264"] = sorted(x for x in av.split() if x.startswith(("h264_", "libx264")))
        out["has_libx264"] = "libx264" in av
        out["has_aac"] = " aac " in av
    except FileNotFoundError:
        out["error"] = "ffmpeg not found on PATH"
    if Path(s.fonts_dir).exists():
        out["font_files"] = len(list(Path(s.fonts_dir).glob("*.*t[tf]")))
    return out
