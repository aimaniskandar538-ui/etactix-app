"""
STAGE 3b - Narration + caption timing, designed around two decisions:

1. NO WHISPER / NO ASR. Instead of synthesising one long voiceover and then
   transcribing it to find caption timing, we synthesise one audio file per caption
   chunk and measure each with ffprobe. Timing is exact by construction,
   deterministic, costs 0 GPU-seconds and adds no model to deploy.
   (Verified here: sum(chunk durations) == concat duration, drift < 0.05s.)

2. READABILITY REBALANCE. TTS speed is not linear in characters, so a chunk sized by
   characters can still run 3.5s on screen. After measuring, any chunk over
   MAX_CAPTION_SECONDS is re-split at a word boundary and re-synthesised (bounded
   tries), then the timeline is rebuilt. This is the single biggest "feels cheap"
   fix in automated short-form.

Providers: edge (free, no key) | azure (F0 = 500k chars/mo free, real WordBoundary
=> true karaoke) | openai | elevenlabs | silent (offline CI). Word boundaries are
used when a provider gives them, otherwise per-word timing is derived from word
length - invisible to viewers, and it costs nothing.
"""
from __future__ import annotations

import asyncio
import json
import re
import statistics
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from ..config import get_settings
from ..util import log, probe, run, tsv_safe

MAX_CAPTION_SECONDS = 3.0
REBALANCE_TRIES = 3
# Conservative pre-measurement reading rate (chars/sec) for a ~2.2 words/sec neural voice.
MAX_RATE_CHARS_PER_SECOND = 14.5


@dataclass
class Word:
    text: str
    start: float
    end: float


@dataclass
class Caption:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "start": round(self.start, 3),
            "end": round(self.end, 3),
            "text": self.text,
            "words": [[w.text, round(w.start, 3), round(w.end, 3)] for w in self.words],
        }


# --------------------------------------------------------------------- chunking
BOUNDARY = (",", ";", ":", "—", "-", " and ", " but ", " so ", " because ", " which ", " that ")


def hard_split(text: str, max_cps: int) -> list[str]:
    """Split to fit a character budget, preferring natural speech boundaries.

    Greedy with lookahead: we take tokens up to the budget, but stop early at a
    comma/semicolon/conjunction once the line has enough on it. A caption that ends
    at "Stop scrolling," reads like speech; one that ends at "because why the"
    reads like a broken teleprompter. Long words stay whole rather than hyphenated.
    """
    if len(text) <= max_cps:
        return [text]
    toks = text.split()
    if len(toks) < 2:
        return [text]
    out, i = [], 0
    while i < len(toks):
        j, cur = i, len(toks[i])
        while j + 1 < len(toks) and cur + 1 + len(toks[j + 1]) <= max_cps:
            j += 1
            cur += 1 + len(toks[j])
            low = toks[j].lower()
            if cur >= max_cps * 0.5 and (low.endswith((",", ";", ":", "—", "-")) or low in ("and", "but", "so", "or", "because", "which", "that")):
                break
        out.append(" ".join(toks[i : j + 1]))
        i = j + 1
    # merge a one-word orphan into the previous line if it still fits.
    # NOTE: pop first, then mutate - `out[-2] = out[-2] + " " + out.pop()` explodes,
    # because Python binds the assignment *target* (the index) before evaluating the
    # RHS, so it writes to index -2 of a list that has just shrunk.
    while len(out) > 1 and len(out[-1].split()) == 1 and len(out[-2]) + 1 + len(out[-1]) <= max_cps * 1.2:
        tail = out.pop()
        out[-1] = out[-1] + " " + tail
    return [o for o in out if o]


def effective_cps(max_cps: int, video_w: int, font_size: int, override: int = 0) -> int:
    """Chars per caption line, clamped by what actually fits on the canvas.

    libass wraps a line that overflows, and a 2-line caption that becomes a 7-line
    word-tower is unreadable. A condensed display face is ~0.46em per glyph; two
    lines is the maximum anyone reads at speed.
    """
    per_line = override or max(6, int(video_w * 0.92 / max(1.0, font_size * 0.46)))
    return max(14, min(max_cps, 2 * per_line))


def chunk_sentences(sentences: list[str], max_cps: int) -> list[str]:
    """Caption chunks: one short sentence, or two very short ones merged. Never mid-sentence."""
    out: list[str] = []
    for raw in sentences:
        s = tsv_safe(raw)
        for part in re.split(r"(?<=[.!?])\s+", s):
            part = part.strip()
            if not part:
                continue
            if len(part) > max_cps:
                out.extend(hard_split(part, max_cps))
                continue
            if out and len(out[-1]) + len(part) + 1 <= max_cps and len(out[-1].split()) <= 3:
                out[-1] = f"{out[-1]} {part}"
                continue
            out.append(part)
    while len(out) > 1 and len(out[-1].split()) == 1 and len(out[-2]) + 1 + len(out[-1]) <= max_cps:
        tail = out.pop()
        out[-1] = out[-1] + " " + tail
    return out


def time_split(text: str, cps: float, max_cps: int) -> list[str]:
    """Cut a caption that measures too slow on screen, at a natural boundary if possible.

    Unlike a character-budgeted split, this knows the *measured* rate, so the halves are
    sized by time. It always returns 2+ parts when there are 2+ words: the caller's only
    goal here is "no single caption over MAX_CAPTION_SECONDS", and a slightly short line is
    strictly better than a 3.5s one. Prefer cuts after a comma/conjunction nearest the cut.
    """
    toks = text.split()
    if len(toks) < 2:
        return [text]
    budget = max(8, int(MAX_CAPTION_SECONDS * max(4.0, cps)))
    cut = max(1, min(len(toks) - 1, budget and len(toks) // 2 or 1))
    near = lambda i: abs(i - len(toks) / 2)
    cand = [i + 1 for i, w in enumerate(toks[:-1])
            if w.lower().endswith((",", ";", ":", "—")) or w.lower() in ("and", "but", "so", "or", "because", "which", "that")]
    cand = [i for i in cand if i > 1 and i < len(toks)]
    if cand:
        cut = min(cand, key=near)
    left, right = " ".join(toks[:cut]), " ".join(toks[cut:])
    if len(right) > max_cps * 2 and len(right.split()) > 2:      # still too heavy: recurse
        return [left] + time_split(right, cps, max_cps)
    return [left, right]


def _balanced_cps(max_cps: int, chars_per_second: float, floor: int = 18) -> int:
    """Char budget implied by the reading-rate ceiling.

    Note it can come out *below* the caller's MAX_CPS: readability wins over a
    preference. A 3.5s caption on a 4-line screen is what makes viewers leave, and
    nobody ever complained a caption was "too short to read".
    """
    return max(floor, int(MAX_CAPTION_SECONDS * chars_per_second))


# --------------------------------------------------------------------- providers
def _edge(texts: list[str], outdir: Path, tag: str) -> tuple[list[Path], list[list[dict]]]:
    s = get_settings()
    import edge_tts

    async def go() -> None:
        for i, c in enumerate(texts):
            await edge_tts.Communicate(c, s.edge_voice, rate=s.edge_rate).save(str(outdir / f"{tag}_{i:03d}.mp3"))

    asyncio.run(go())
    return [outdir / f"{tag}_{i:03d}.mp3" for i in range(len(texts))], []


def _azure(texts: list[str], outdir: Path, tag: str) -> tuple[list[Path], list[list[dict]]]:
    """Azure REST TTS with WordBoundary metadata: real per-word timing, free to 500k chars/mo."""
    s = get_settings()
    import urllib.error
    import urllib.request
    import xml.etree.ElementTree as ET

    files: list[Path] = []
    per_chunk: list[list[dict]] = []
    for i, c in enumerate(texts):
        body = (
            '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="'
            + unicodedata.normalize("NFKC", s.hl)
            + '"><voice name="' + s.azure_voice + '"><prosody rate="+8%">' + _xml_escape(c) + "</prosody></voice></speak>"
        )
        req = urllib.request.Request(
            f"https://{s.azure_region}.tts.speech.microsoft.com/cognitiveservices/v1",
            data=body.encode(),
            headers={
                "Ocp-Apim-Subscription-Key": s.azure_key,
                "Content-Type": "application/ssml+xml",
                "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3",
                "User-Agent": "acp-pipeline",
                "Accept": "audio/mpeg, multipart/mixed",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=45) as r:  # noqa: S310
                ctype, payload = r.headers.get("Content-Type", ""), r.read()
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"Azure TTS HTTP {e.code}: {e.read().decode()[:200]}") from e
        p = outdir / f"{tag}_{i:03d}.mp3"
        p.write_bytes(payload)
        files.append(p)
        bounds: list[dict] = []
        if "multipart" in ctype.lower():
            for line in payload.decode("utf-8", "replace").splitlines():
                if "<WordBoundary" not in line:
                    continue
                frag = line[line.index("<WordBoundary") : line.rindex("</WordBoundary>") + 15]
                try:
                    el = ET.fromstring(re.sub(r"\sxmlns(:\w+)?=\"[^\"]+\"", "", frag))
                    t0 = int(el.findtext("audioOffset") or 0) / 10_000_000
                    d = int(el.findtext("audioDuration") or 0) / 10_000_000
                    if (el.findtext("text") or "").strip():
                        bounds.append({"text": el.findtext("text").strip(), "start": t0, "end": t0 + d})
                except ET.ParseError:
                    continue
        per_chunk.append(bounds)
    return files, per_chunk


def _openai(texts: list[str], outdir: Path, tag: str) -> tuple[list[Path], list[list[dict]]]:
    s = get_settings()
    import time
    import urllib.request

    files: list[Path] = []
    for i, c in enumerate(texts):
        payload = json.dumps({"model": s.openai_tts_model, "voice": s.openai_tts_voice, "input": c, "response_format": "mp3"}).encode()
        req = urllib.request.Request(
            s.llm_base_url.rstrip("/") + "/audio/speech",
            data=payload,
            headers={"Authorization": f"Bearer {s.llm_api_key}", "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=90) as r:  # noqa: S310
            p = outdir / f"{tag}_{i:03d}.mp3"
            p.write_bytes(r.read())
        files.append(p)
        time.sleep(0.15)  # tts endpoints are rpm-limited; do not ride the ceiling
    return files, []


def _elevenlabs(texts: list[str], outdir: Path, tag: str) -> tuple[list[Path], list[list[dict]]]:
    """Tries the timestamped-speech (char alignment) endpoint; falls back to plain TTS."""
    s = get_settings()
    import urllib.request

    files: list[Path] = []
    per_chunk: list[list[dict]] = []
    for i, c in enumerate(texts):
        bounds: list[dict] = []
        try:
            req = urllib.request.Request(
                f"https://api.elevenlabs.io/v1/stream-alignment/{s.elevenlabs_voice}",
                data=json.dumps({"text": c, "character_alignment": True}).encode(),
                headers={"xi-api-key": s.elevenlabs_key, "Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=90) as r:  # noqa: S310
                for line in r.read().decode("utf-8", "replace").splitlines():
                    try:
                        ev = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    chars = ev.get("chars") or []
                    st = ev.get("characterStartTimesMs") or []
                    en = ev.get("characterEndTimesMs") or []
                    word, wstart = "", None
                    for ch, a, b in zip(chars, st, en):
                        if ch == " ":
                            if word:
                                bounds.append({"text": word, "start": wstart / 1000, "end": b / 1000})
                            word, wstart = "", None
                        else:
                            word += ch
                            wstart = a if wstart is None else wstart
                    if word:
                        bounds.append({"text": word, "start": (wstart or 0) / 1000, "end": (en[-1] if en else 0) / 1000})
        except Exception as e:  # noqa: BLE001 - alignment is a paid/plan-gated endpoint
            log.info("elevenlabs alignment unavailable (%s) - falling back to proportional timing", str(e)[:120])
        per_chunk.append(bounds)
        req = urllib.request.Request(
            f"https://api.elevenlabs.io/v1/text-to-speech/{s.elevenlabs_voice}?output_format=mp3_44100_128",
            data=json.dumps({"text": c, "voice_settings": {"stability": 0.35, "similarity_boost": 0.75}}).encode(),
            headers={"xi-api-key": s.elevenlabs_key, "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=90) as r:  # noqa: S310
            p = outdir / f"{tag}_{i:03d}.mp3"
            p.write_bytes(r.read())
        files.append(p)
    return files, per_chunk


def _silent(texts: list[str], outdir: Path, tag: str) -> tuple[list[Path], list[list[dict]]]:
    s = get_settings()
    files = []
    for i, c in enumerate(texts):
        dur = max(1.4, len(c) / 13.0)
        p = outdir / f"{tag}_{i:03d}.mp3"
        run([s.ffmpeg_bin, "-v", "error", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", f"{dur:.2f}", "-c:a", "libmp3lame", str(p)], timeout=60)
        files.append(p)
    return files, []


def _xml_escape(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


PROVIDERS = {"edge": _edge, "azure": _azure, "openai": _openai, "elevenlabs": _elevenlabs, "silent": _silent}


# --------------------------------------------------------------------- assembly
def _proportional_words(text: str, start: float, end: float) -> list[Word]:
    toks = text.split()
    if not toks:
        return []
    weights = [max(1, len(re.sub(r"\W", "", t))) for t in toks]
    total = sum(weights) or 1
    span, t, out = end - start, start, []
    for tok, w in zip(toks, weights):
        d = max(0.08, span * w / total)
        out.append(Word(tok, t, t + d))
        t += d
    if out:
        out[-1] = Word(out[-1].text, out[-1].start, max(out[-1].start + 0.08, end))
    return out


def synthesize(sentences: list[str], job_dir: Path) -> dict:
    """-> {'audio', 'captions', 'chunks', 'chars', 'duration', provider, ...}"""
    s = get_settings()
    job_dir.mkdir(parents=True, exist_ok=True)
    name = s.tts_provider.lower()
    fn = PROVIDERS.get(name) or PROVIDERS["silent"]
    if name not in PROVIDERS or (name == "azure" and not s.azure_key) or (name == "openai" and not s.llm_api_key) or (name == "elevenlabs" and not s.elevenlabs_key):
        if name != "silent":
            log.warning("TTS provider '%s' unusable (missing key?) -> silent narration for this run", name)
        fn = _silent_provider
    budget = effective_cps(s.max_cps, s.video_w, s.caption_size, s.chars_per_line)
    if budget < s.max_cps:
        log.info("caption budget narrowed to %s chars to fit %sx%s text width", budget, s.video_w, s.caption_size)
    chunks = chunk_sentences(sentences, budget)
    if not chunks:
        raise RuntimeError("no narration text after chunking")

    # ---- pass 1: synthesise everything, measure every chunk
    files, bounds_by_chunk = fn(chunks, job_dir, "c00")
    entries: list[dict] = []
    for i, (c, f) in enumerate(zip(chunks, files)):
        path, dur = _normalise(f, job_dir)
        if dur > 0:
            entries.append({"text": c, "path": path, "dur": dur, "bounds": bounds_by_chunk[i] if i < len(bounds_by_chunk) else []})
    if not entries:
        raise RuntimeError("TTS produced no audio (check provider, key and quota)")
    # Worst per-chunk rate, not the aggregate: caption gaps drag an average down and hide
    # exactly the outlier we are trying to fix.
    worst_rate = max(len(e["text"]) / max(0.25, e["dur"]) for e in entries)

    # ---- pass 2: re-split anything that reads too slowly on screen (bounded tries; each
    #      pass re-measures, so a voice that speaks slower than assumed still converges)
    for attempt in range(REBALANCE_TRIES):
        too_slow = [i for i, e in enumerate(entries)
                    if e["dur"] > MAX_CAPTION_SECONDS + 0.05 and len(e["text"].split()) > 2]
        if not too_slow:
            break
        plans: list[tuple[int, list[str]]] = []   # (entry index, its replacement pieces)
        texts: list[str] = []
        for i in too_slow:
            e = entries[i]
            rate = len(e["text"]) / max(0.25, e["dur"])          # this chunk's own measured rate
            pieces = time_split(e["text"], rate, budget)
            if len(pieces) < 2 or max(len(x) for x in pieces) >= len(e["text"]) // 2 * 1.4:
                continue   # a split that cannot roughly halve the line is churn, not a fix
            plans.append((i, pieces))
            texts.extend(pieces)
        if not plans:
            log.info("rebalance pass %s: nothing left that can be split further", attempt + 1)
            break
        sfiles, sbounds = fn(texts, job_dir, f"c1{attempt}")
        measured = [_normalise(f, job_dir) for f in sfiles]
        rebuilt: list[dict] = []
        consumed = 0
        split_idx = {i for i, _ in plans}
        for i, e in enumerate(entries):
            if i not in split_idx:
                rebuilt.append(e)
                continue
            pieces = dict(plans)[i]
            for piece in pieces:
                path, dur = measured[consumed]
                rebuilt.append(
                    {
                        "text": piece,
                        "path": path,
                        "dur": dur,
                        "bounds": sbounds[consumed] if consumed < len(sbounds) else [],
                    }
                )
                consumed += 1
        entries = [e for e in rebuilt if e["dur"] > 0]
        worst_rate = max(len(e["text"]) / max(0.25, e["dur"]) for e in entries)
        log.info(
            "readability rebalance %s: %s chunks, %.1fs, slowest %.2fs (worst rate %.1f chars/s)",
            attempt + 1, len(entries), sum(e["dur"] for e in entries),
            max(e["dur"] for e in entries), worst_rate,
        )
    chunks = [e["text"] for e in entries]

    # ---- concat with breath gaps
    gap = max(0.0, float(s.gap_seconds))
    gap_file = None
    if gap > 0:
        gap_file = job_dir / "gap.wav"
        run([s.ffmpeg_bin, "-v", "error", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", f"{gap:.3f}", str(gap_file)], timeout=60)
    listfile = job_dir / "concat.txt"
    lines: list[str] = []
    for i, e in enumerate(entries):
        lines.append(f"file '{e['path']}'")
        if gap_file and i < len(entries) - 1:
            lines.append(f"file '{gap_file}'")
    listfile.write_text("\n".join(lines))
    narration = job_dir / "narration.wav"
    run([s.ffmpeg_bin, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(listfile), "-c:a", "pcm_s16le", str(narration)], timeout=300)
    total = probe(str(narration))["duration"]

    # ---- caption model
    captions: list[Caption] = []
    t = 0.0
    for e in entries:
        start, end = t, t + e["dur"]
        b = e.get("bounds") or []
        if b:
            shift = start - b[0]["start"]
            words_ = [Word(x["text"], max(start, x["start"] + shift), min(end, max(x["end"] + shift, x["start"] + shift + 0.05))) for x in b if x.get("text")]
        else:
            words_ = _proportional_words(e["text"], start, end)
        captions.append(Caption(start, end, e["text"], words_))
        t = end + gap
    if captions:
        last = captions[-1]
        if (last.end - last.start) < MAX_CAPTION_SECONDS:
            last.end = min(total, last.end + min(0.35, MAX_CAPTION_SECONDS + 0.35 - (last.end - last.start)))
        # carry the karaoke highlight into the hold, otherwise the last word finishes
        # filling and then just sits there highlighted-but-not-speaking
        if last.words and last.words[-1].end < last.end:
            last.words[-1] = Word(last.words[-1].text, last.words[-1].start, last.end)

    durs = [c.end - c.start for c in captions]
    words_total = sum(len(c.text.split()) for c in captions)
    payload = {
        "provider": name if fn is not _silent_provider else "silent",
        "voice": {"edge": s.edge_voice, "azure": s.azure_voice, "openai": s.openai_tts_voice, "elevenlabs": s.elevenlabs_voice}.get(name, "none"),
        "chunks": len(captions),
        "chars": sum(len(c) for c in chunks),
        "duration": round(total, 3),
        "median_chunk": round(statistics.median(durs), 2) if durs else 0,
        "max_chunk": round(max(durs), 2) if durs else 0,
        # Feed this back as WORDS_PER_SECOND so stage 2's word budget tracks reality per voice.
        "words_per_second_measured": round(words_total / max(0.1, total), 2),
        "captions": [c.to_dict() for c in captions],
    }
    (job_dir / "timings.json").write_text(json.dumps(payload, indent=1))
    log.info("narration: %s chunks, %.2fs, %s chars, max caption %.2fs (%s/%s)", payload["chunks"], total, payload["chars"], payload["max_chunk"], payload["provider"], payload["voice"])
    return {"audio": str(narration), "timings_path": str(job_dir / "timings.json"), **payload}


def _silent_provider(texts: list[str], outdir: Path, tag: str):
    return _silent(texts, outdir, tag)


def _normalise(src, job_dir: Path) -> tuple[str, float]:
    """Loudness-match + resample one chunk; return (path_to_use, duration_seconds).

    Measuring duration here (rather than trusting a character-count estimate) is what
    makes caption timing exact without any ASR pass.
    """
    s = get_settings()
    src = Path(src)
    n = job_dir / (src.stem + ".wav") if src.suffix.lower() != ".wav" else src
    run(
        [s.ffmpeg_bin, "-v", "error", "-y", "-i", str(src),
         "-af", "aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "2", str(n)],
        timeout=180,
    )
    return str(n), probe(str(n))["duration"]
