"""
STAGE 3c - caption files (ASS for burn-in, VTT for the caption track).

The look that survives on short-form - 1-2 words per screen, fat outline, karaoke
fill, positioned clear of the app UI - is only expressible in ASS, so we generate
ASS directly rather than converting SRT. VTT ships alongside as a real caption
track (accessibility + YouTube indexes track text, it does not index burned pixels).
"""
from __future__ import annotations

import json
from pathlib import Path

from ..config import get_settings

ASS_HEADER = """[Script Info]
Title: ACP auto captions
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
PlayResX: {w}
PlayResY: {h}

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,{font},{size},&H00FFFFFF,&H0017C9FB,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,{outline},{shadow},2,{ml},{mr},{mv},1
Style: Label,{font},{label},&H00FFFFFF,&H0017C9FB,&H00000000,&HA0000000,-1,0,0,0,100,100,2,0,3,4,3,8,70,70,{labelmv},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

EMPHASIS = {
    "money": "million billion dollar dollars cost price free paid salary revenue profit loss".split(),
    "risk": "never stop warning danger illegal banned risk scam mistake fail fraud".split(),
    "abs": "only everyone nobody always never secret real actually truth proof wrong".split(),
}
ALL_KW = set().union(*EMPHASIS.values())


def _ts(t: float) -> str:
    t = max(0.0, float(t))
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"


def _esc(text: str) -> str:
    return text.replace("{", "(").replace("}", ")").replace("\n", "\\N")


def per_line_chars(s) -> int:
    """Width budget for a single caption line (condensed display face ~0.46em/glyph)."""
    return max(6, int(s.video_w * 0.92 / max(1.0, s.caption_size * 0.46)))


def wrap_lines(pieces: list[str], width: int, max_lines: int = 2) -> list[str]:
    """Group formatted caption tokens into <=max_lines lines that stay inside width.

    Greedy on rendered length (markup tags do not print), with a final balance pass
    so the last line is not a lone orphan hanging under everything else.
    """
    lines: list[str] = []
    cur = ""
    for tok in pieces:
        if cur and len(cur) + 1 + len(tok) > width and len(lines) < max_lines - 1:
            lines.append(cur)
            cur = tok
        else:
            cur = f"{cur} {tok}".strip() if cur else tok
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:  # overflow: merge the tail into the last allowed line
        lines = lines[: max_lines - 1] + [" ".join(lines[max_lines - 1 :])]
    if len(lines) == 2 and abs(len(lines[0]) - len(lines[1])) > width * 0.35:
        words = (lines[0] + " " + lines[1]).split()
        mid = max(1, len(words) // 2)
        lines = [" ".join(words[:mid]), " ".join(words[mid:])]
    return lines


def build_ass(captions: list[dict], on_screen: list[dict] | None = None, karaoke: bool = True) -> str:
    s = get_settings()
    head = ASS_HEADER.format(
        w=s.video_w, h=s.video_h, font=s.caption_font, size=s.caption_size,
        label=int(s.caption_size * 0.6), outline=max(3, int(s.caption_size * 0.09)), shadow=2,
        ml=70, mr=70, mv=int(s.video_h * 0.19), labelmv=int(s.video_h * 0.09),
    )
    lines = [head]
    for c in captions:
        ws = c.get("words") or []
        if karaoke and len(ws) >= 2:
            # short-form rule: at most 2 lines, ~4 words per line, or it reads like
            # a paragraph and people scroll away. per = words/line for <=2 lines.
            per = math_ceil(len(ws) / 2)
            groups = [ws[i : i + per] for i in range(0, len(ws), per)]
            rendered = []
            for g in groups:
                pieces = []
                for w, wstart, wend in g:
                    lead = max(0, int((float(wstart) - float(c["start"])) * 1000))
                    fill = max(1, int((float(wend) - float(wstart)) * 1000))
                    emph = str(w).lower().strip(".,!?:;\"'") in ALL_KW
                    tag = r"{\c&H0017C9FB&}" if emph else ""
                    pieces.append(f"{{\\kf{fill}\\ko{lead}}}{tag}{_esc(str(w))}")
                rendered.append(" ".join(pieces))
            rendered = wrap_lines(rendered, per_line_chars(s))
            text = r"{\an2\b1}" + "\\N".join(rendered)
        else:
            text = r"{\an2\b1}" + _esc(c["text"])
        lines.append(f"Dialogue: 0,{_ts(c['start'])},{_ts(c['end'])},Main,,0,0,0,,{text}")

    for o in on_screen or []:
        try:
            start = float(o.get("start", 0) or 0)
            end = float(o.get("end") or (start + 2.2))
        except (TypeError, ValueError):
            continue
        label = _esc(str(o.get("text") or "")[:32])
        if label:
            lines.append(f"Dialogue: 1,{_ts(start)},{_ts(end)},Label,,0,0,0,,{{\\fad(120,200)}}{label}")
    return "\n".join(lines) + "\n"


def math_ceil(x: float) -> int:
    import math

    return max(1, int(math.ceil(x)))


def build_vtt(captions: list[dict]) -> str:
    def ts(t: float) -> str:
        return f"{int(t // 3600):02d}:{int(t % 3600 // 60):02d}:{int(t % 60):02d}.{int(t % 1 * 1000):03d}"

    out = ["WEBVTT", ""]
    for i, c in enumerate(captions, 1):
        out += [str(i), f"{ts(c['start'])} --> {ts(c['end'])}", c["text"], ""]
    return "\n".join(out)


def write_files(job_dir: Path, captions: list[dict], on_screen: list[dict] | None = None) -> dict:
    s = get_settings()
    ass = build_ass(captions or [], on_screen, karaoke=(s.caption_style == "karaoke"))
    (job_dir / "captions.ass").write_text(ass)
    (job_dir / "captions.vtt").write_text(build_vtt(captions or []))
    (job_dir / "captions.json").write_text(json.dumps(captions or [], indent=1))
    return {"ass": str(job_dir / "captions.ass"), "vtt": str(job_dir / "captions.vtt"), "count": len(captions or [])}


def qc_stats(job_dir: Path) -> dict:
    """Readability numbers worth alerting on. <0.4s per caption is unreadable."""
    p = job_dir / "captions.json"
    if not p.exists():
        return {}
    caps = json.loads(p.read_text())
    durs = [c["end"] - c["start"] for c in caps] or [0]
    return {
        "captions": len(caps),
        "min_seconds": round(min(durs), 2),
        "avg_chars_per_second": round(sum(len(c["text"]) for c in caps) / max(1e-6, sum(durs)), 1),
        "max_words_per_caption": max((len(c["text"].split()) for c in caps), default=0),
    }
