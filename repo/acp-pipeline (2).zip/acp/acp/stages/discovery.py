"""
STAGE 1 - Trend & idea discovery.

Design goals: (a) free, key-less sources first, (b) never crash the run because one
source is down or blocked, (c) dedupe so the channel does not repeat itself.

Sources implemented (all reachable without a paid plan):
  * Google Trends daily RSS       -> no key, the single best free trend signal
  * Google News topic RSS         -> no key, hard-news angle / "explainer" fuel
  * Wikipedia Current Events      -> no key, date-anchored factual events
  * Reddit hot JSON               -> no key, niche communities + comment counts
  * Hacker News (hnrss/Algolia)   -> no key, tech niche
  * YouTube channel Atom feeds    -> no key, watch what top competitors shipped

Scoring is deliberately dumb and auditable: recency * source weight, then a
niche-keyword boost. LLM "virality" judging happens in stage 2 where it is cheap
and cacheable, not here where we scan hundreds of items.
"""
from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Callable, Iterable

from ..config import get_settings
from ..util import findtext_ns, iter_local, local_name, log, retry, strip_ns, tsv_safe, words

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"


@dataclass
class RawItem:
    title: str
    url: str = ""
    source: str = ""
    weight: float = 1.0
    published: datetime | None = None
    meta: dict = field(default_factory=dict)

    @property
    def age_hours(self) -> float:
        if not self.published:
            return 12.0  # unknown -> treat as half a day old
        return max(0.0, (datetime.now(timezone.utc) - self.published).total_seconds() / 3600.0)


def _get(url: str, timeout: int = 15) -> str:
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (fixed hosts)
        return r.read().decode("utf-8", "replace")


def _parse_dt(text: str | None) -> datetime | None:
    if not text:
        return None
    text = text.strip()
    try:
        return parsedate_to_datetime(text)
    except (TypeError, ValueError):
        pass
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            d = datetime.strptime(text, fmt)
            return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


# --------------------------------------------------------------------------- sources
def fetch_google_trends(geo: str = "US") -> list[RawItem]:
    """Google's official, key-free daily trending-searches RSS."""
    url = f"https://trends.google.com/trending/rss?geo={geo.upper()}"
    xml = _get(url)
    out: list[RawItem] = []
    root = strip_ns(xml)
    for item in root.iter("item"):
        title = (item.findtext("title") or "").strip()
        if not title:
            continue
        traffic = findtext_ns(item, "approx_traffic")
        pub = _parse_dt(item.findtext("pubDate"))
        tags = [findtext_ns(n, "news_item_title") for n in list(item) if local_name(n.tag) == "news_item"][:3]
        out.append(
            RawItem(
                title=title,
                url="",
                source="google_trends",
                weight=1.0,
                published=pub,
                meta={"traffic": traffic, "news_headlines": tags[:3]},
            )
        )
    log.info("google_trends[%s]: %s items", geo, len(out))
    return out


def fetch_google_news(topic: str = "", query: str = "", lang: str = "en", geo: str = "US") -> list[RawItem]:
    import urllib.parse

    if query:
        q = urllib.parse.urlencode({"q": query, "hl": lang, "gl": geo, "ceid": f"{geo}:{lang}"})
        url = f"https://news.google.com/rss/search?{q}"
    else:
        q = urllib.parse.urlencode({"hl": lang, "gl": geo, "ceid": f"{geo}:{lang}"})
        url = f"https://news.google.com/rss?{q}"
    root = strip_ns(_get(url))
    out: list[RawItem] = []
    for item in root.iter("item"):
        title = re.sub(r"\s*-\s*[^-]{2,40}$", "", (item.findtext("title") or "").strip())
        out.append(
            RawItem(
                title=tsv_safe(title),
                url=(item.findtext("link") or "").strip(),
                source="google_news",
                weight=0.85,
                published=_parse_dt(item.findtext("pubDate")),
                meta={"provider": (item.findtext("source") or "").strip()},
            )
        )
    log.info("google_news: %s items", len(out))
    return out


def fetch_wikipedia_current_events(lang: str = "en") -> list[RawItem]:
    """Portal:Current_events wikitext: lines look like '**<b>Topic</b> - summary'."""
    url = f"https://{lang}.wikipedia.org/w/index.php?title=Portal:Current_events&action=raw"
    text = _get(url)
    out: list[RawItem] = []
    day = None
    for line in text.splitlines():
        m = re.match(r"==(\d{1,2}\s+\w+\s+\d{4})==", line.strip("=").strip())
        if m:
            day = _parse_dt(m.group(1))
            continue
        m2 = re.match(r"\*\s*<b>(.+?)</b>\s*[-\u2013]\s*(.+)", line)
        if m2:
            topic = tsv_safe(re.sub(r"<[^>]+>", "", m2.group(1)))
            summary = tsv_safe(re.sub(r"<[^>]+>", "", m2.group(2)))
            out.append(
                RawItem(
                    title=topic if len(topic) <= 60 else summary[:80],
                    url=f"https://{lang}.wikipedia.org/wiki/Portal:Current_events",
                    source="wikipedia_current_events",
                    weight=0.9,
                    published=day,
                    meta={"summary": summary[:400]},
                )
            )
    log.info("wikipedia_current_events: %s items", len(out))
    return out


def fetch_reddit(subreddits: str = "all", limit: int = 25) -> list[RawItem]:
    out: list[RawItem] = []
    for sub in [s.strip() for s in subreddits.split(",") if s.strip()]:
        url = f"https://www.reddit.com/r/{sub}/hot.json?limit={limit}&raw_json=1"
        try:
            import json as _json

            data = _json.loads(_get(url, timeout=12))
            for ch in data.get("data", {}).get("children", []):
                d = ch.get("data", {})
                if d.get("stickied") or d.get("over_18"):
                    continue
                out.append(
                    RawItem(
                        title=tsv_safe(d.get("title", ""))[:160],
                        url="https://reddit.com" + (d.get("permalink") or ""),
                        source=f"reddit:{sub}",
                        weight=0.7,
                        published=datetime.fromtimestamp(d.get("created_utc", 0), tz=timezone.utc),
                        meta={"ups": d.get("ups", 0), "comments": d.get("num_comments", 0)},
                    )
                )
        except Exception as e:  # noqa: BLE001 - reddit blocks datacentre IPs often
            log.warning("reddit:%s unavailable (%s) - skipping source", sub, str(e)[:120])
    log.info("reddit: %s items", len(out))
    return out


def fetch_hackernews(query: str = "", limit: int = 25) -> list[RawItem]:
    if query:
        url = f"https://hn.algolia.com/api/v1/search_by_date?query={query}&tags=story&hitsPerPage={limit}"
        import json as _json

        try:
            data = _json.loads(_get(url, timeout=12))
            hits = data.get("hits", [])
        except Exception as e:  # noqa: BLE001
            log.warning("hn search unavailable: %s", str(e)[:120])
            return []
        return [
            RawItem(
                title=tsv_safe(h.get("title") or ""),
                url=h.get("url") or f"https://news.ycombinator.com/item?id={h.get('objectID')}",
                source="hackernews_search",
                weight=0.6,
                published=_parse_dt(h.get("created_at")),
                meta={"points": h.get("points", 0)},
            )
            for h in hits
            if h.get("title")
        ]
    root = strip_ns(_get("https://hnrss.org/newest?points=100", timeout=12))
    out = []
    for item in root.iter("item"):
        out.append(
            RawItem(
                title=tsv_safe(re.sub(r"<[^>]+>", "", item.findtext("title") or "")),
                url=(item.findtext("link") or "").strip(),
                source="hackernews",
                weight=0.6,
                published=_parse_dt(item.findtext("pubDate")),
            )
        )
    return out


def fetch_youtube_channels(channel_ids: str, limit: int = 5) -> list[RawItem]:
    """Atom feeds of channels you benchmark against: what they just posted is a trend signal."""
    out: list[RawItem] = []
    for cid in [c.strip() for c in channel_ids.split(",") if c.strip()]:
        try:
            root = strip_ns(_get(f"https://www.youtube.com/feeds/videos.xml?channel_id={cid}", timeout=12))
        except Exception as e:  # noqa: BLE001
            log.warning("youtube feed %s failed: %s", cid, str(e)[:100])
            continue
        for entry in list(root.iter("entry"))[:limit]:
            title = tsv_safe(entry.findtext("title") or "")
            link = ""
            for lk in entry.iter("link"):
                if lk.attrib.get("rel") == "alternate":
                    link = lk.attrib.get("href", "")
            out.append(
                RawItem(
                    title=title,
                    url=link,
                    source="youtube_channel",
                    weight=0.75,
                    published=_parse_dt(entry.findtext("published")),
                    meta={"channel_id": cid},
                )
            )
    log.info("youtube_channels: %s items", len(out))
    return out


# --------------------------------------------------------------------------- scoring
def score(item: RawItem, niche_keywords: list[str], weight_map: dict[str, float]) -> float:
    """Recency decay * source trust * niche boost. Transparent on purpose."""
    hours = item.age_hours
    recency = 1.0 if hours <= 3 else (0.75 if hours <= 12 else (0.5 if hours <= 24 else max(0.1, 1.0 - (hours - 24) / 96)))
    trust = 1.0
    for prefix, w in weight_map.items():
        if item.source.startswith(prefix):
            trust = w
            break
    boost = 1.0
    blob = (item.title + " " + " ".join(str(v) for v in item.meta.values())).lower()
    # Only distinctive terms may boost: a generic word ("general", "data", "new") matches
    # half the news and quietly outranks real trends. Tune via NICHE_KEYWORD_MIN_LEN.
    kmin = int(os.environ.get("NICHE_KEYWORD_MIN_LEN", "6"))
    hits = sum(1 for k in niche_keywords if k and len(k) >= kmin and k.lower() in blob)
    if hits:
        boost = 1.0 + 0.18 * min(hits, 4)
    volume = 1.0
    traffic = str(item.meta.get("traffic", ""))
    if traffic:
        n = re.sub(r"[^0-9]", "", traffic)
        volume = 1.0 + (min(int(n), 1_000_000) / 1_000_000) * 0.5 if n else 1.0
    social = 1.0
    pts = int(item.meta.get("points") or item.meta.get("ups") or 0)
    if pts:
        social = 1.0 + min(pts, 5000) / 5000
    return round(100 * recency * trust * boost * volume * social, 2)


def candidates(
    niche_keywords: Iterable[str] = (),
    sources: list[Callable[[], list[RawItem]]] | None = None,
) -> list[RawItem]:
    s = get_settings()
    niche = list(niche_keywords or [])
    weight_map = {
        "google_trends": s.trends_weight,
        "google_news": s.news_weight,
        "wikipedia": 0.9,
        "reddit": s.reddit_weight,
        "hackernews": s.hn_weight,
        "youtube_channel": 0.75,
    }
    if sources is None:
        sources = [lambda: fetch_google_trends(s.geo)]
        if s.reddit_subreddits:
            sources.append(lambda: fetch_reddit(s.reddit_subreddits))
        if s.yt_trend_channel_ids:
            sources.append(lambda: fetch_youtube_channels(s.yt_trend_channel_ids))
        if niche:
            sources.append(lambda: fetch_google_news(query="+".join(list(niche)[:3]) + " when:7d", lang=s.language, geo=s.geo))
            sources.append(lambda: fetch_hackernews(query=list(niche)[0]))
        else:
            sources.append(lambda: fetch_wikipedia_current_events("en"))

    items: list[RawItem] = []
    for fetch in sources:
        try:
            items.extend(fetch())
        except Exception as e:  # noqa: BLE001 - a dead source must not kill discovery
            log.warning("source %s failed: %s", getattr(fetch, "__name__", "lambda"), str(e)[:160])

    for it in items:
        it.meta["_score"] = score(it, niche, weight_map)
    items.sort(key=lambda i: (i.meta["_score"], i.source == 'google_trends'), reverse=True)
    log.info("discovery: %s raw items, best score %s", len(items), items[0].meta["_score"] if items else "-")
    return items


def _norm_key(title: str) -> str:
    t = re.sub(r"[^a-z0-9 ]", "", (title or "").lower())
    return " ".join(t.split())[:80]


def select_ideas(items: list[RawItem], seen_key: Callable[[str], bool], remember: Callable[[str], None], limit: int) -> list[dict]:
    """Top-N, one per normalized title, skipping anything used in the last N days."""
    chosen: list[dict] = []
    used_titles: set[str] = set()
    for it in items:
        key = _norm_key(it.title)
        if len(key) < 8 or key in used_titles:
            continue
        if words(it.title) > 22:  # a topic, not an essay title
            continue
        if seen_key(key):
            log.debug("skip (recently used): %s", it.title[:60])
            continue
        used_titles.add(key)
        chosen.append(
            {
                "title": it.title,
                "key": key,
                "source": it.source,
                "url": it.url,
                "score": it.meta.get("_score", 0),
                "age_hours": round(it.age_hours, 1),
                "context": {k: v for k, v in it.meta.items() if k not in ("_score",) and v},
            }
        )
        if len(chosen) >= limit:
            break
    for c in chosen:
        remember(c["key"])
    return chosen


def discover(limit: int | None = None, dry_run: bool = False) -> list[dict]:
    s = get_settings()
    limit = limit or s.ideas_per_run
    niche = [k for k in re.split(r"[,;]", s.niche) if k.strip()]
    items = candidates(niche)
    if dry_run:
        return [
            {"title": i.title, "source": i.source, "score": i.meta.get("_score"), "url": i.url}
            for i in items[: limit * 6]
        ]
    from ..db import Store

    store = Store(s.db_path)
    picked = select_ideas(
        items,
        seen_key=lambda k: store.seen(k, s.dedup_days),
        remember=store.remember,
        limit=limit,
    )
    if len(picked) < limit:  # trend drought -> fall back to evergreen news
        try:
            extra = select_ideas(
                fetch_google_news(lang=s.language, geo=s.geo),
                seen_key=lambda k: store.seen(k, s.dedup_days),
                remember=store.remember,
                limit=limit - len(picked),
            )
            picked += extra
        except Exception as e:  # noqa: BLE001
            log.warning("news fallback failed: %s", str(e)[:120])
    log.info("selected %s ideas: %s", len(picked), [p["title"][:48] for p in picked])
    return picked


if __name__ == "__main__":
    t0 = time.time()
    for i, d in enumerate(discover(limit=8, dry_run=True), 1):
        print(f"{i:2d} {d['score']:6.1f}  {d['source']:<26} {d['title'][:80]}")
    print(f"({time.time()-t0:.1f}s)")
