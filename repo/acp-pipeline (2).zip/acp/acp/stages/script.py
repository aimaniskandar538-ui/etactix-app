"""
STAGE 2 - Script + visual prompt generation.

One LLM call per idea, one strict JSON contract, everything downstream depends on:
  * 3 hook variants + the chosen one (hooks are the whole game on short-form)
  * narration sentences, already chunked to caption size (<= max_cps chars)
  * stock-footage search keywords PER sentence -> clip pacing matches the words
  * title / description / hashtags / TTS direction / AIGC flag / claims to verify

Two cheap guardrails that prevent 90% of "why did it post garbage" incidents:
  1. duration budget - reject and regenerate if the script overshoots TARGET_SECONDS
  2. claims_to_verify - anything factual is surfaced for human review (or a
     RAG/news-quote step) before publishing.
"""
from __future__ import annotations

import re
from typing import Any

from ..config import get_settings
from ..llm import complete_json
from ..util import log, words

SYSTEM = """You are a short-form video producer writing for TikTok / Reels / YouTube Shorts.
Rules:
- Spoken language only. No emojis in narration, no hashtags in narration, no bullet points.
- Never start with "Hey guys", "Welcome back", "In this video", "Did you know".
- Sentence 1 is the hook: a specific, slightly uncomfortable claim, a number, or an open loop.
- Sentences must be short enough to read on a phone in under 2.5 seconds.
- Concrete beats abstract: numbers, names, objects, times of day.
- Never invent quotes, statistics or events. If you use a number, put it in claims_to_verify.
- End with one soft CTA max."""

SCHEMA = """{
  "hook_variants": ["3 alternatives, each <= 90 chars"],
  "hook": "the best of the three",
  "chosen_hook_reason": "one sentence",
  "script_sentences": ["7-12 spoken sentences, <= {max_cps} characters each"],
  "keywords": ["5-8 stock-video search terms, one per 2 sentences, 2-3 words, concrete nouns: 'night city traffic', 'hands typing keyboard'"],
  "title": "<= 80 chars, curiosity gap, no clickbait lies",
  "description": "<= 200 chars, first line is the hook restated",
  "hashtags": ["3-5 niche tags plus #shorts"],
  "cta": "one short spoken line",
  "tts_direction": "tone, pace, emphasis notes for the voice talent",
  "on_screen_text": [{"start": 0.0, "text": "SHORT LABEL"}, {"start": 4.0, "text": "ANOTHER"}],
  "is_ai_generated": true,
  "claims_to_verify": ["each factual number/date/name used"],
  "estimated_seconds": 28
}"""


def _split_long(sentence: str, max_cps: int) -> list[str]:
    """Force caption-sized chunks: models routinely ignore the length rule."""
    from .speech import hard_split

    return hard_split(sentence.strip(), max_cps)


def _clean(payload: dict, idea: str, max_cps: int, target_seconds: int) -> dict[str, Any]:
    sents: list[str] = []
    for s in payload.get("script_sentences") or []:
        s = re.sub(r"\s+", " ", str(s)).strip()
        if not s:
            continue
        sents += _split_long(s, max_cps)
    if not sents:
        raise ValueError("model returned no script_sentences")
    # duration budget
    est = round(words(" ".join(sents)) / max(1.0, get_settings().words_per_second))
    if est > target_seconds * 1.35:
        log.warning("script over budget (%ss > %.0fs) - trimming tail sentences", est, target_seconds * 1.35)
        while sents and round(words(" ".join(sents)) / get_settings().words_per_second) > target_seconds:
            sents.pop(0 if len(sents) % 2 else -1)  # trim the weaker end alternately
        est = round(words(" ".join(sents)) / get_settings().words_per_second)

    hooks = [str(h).strip() for h in (payload.get("hook_variants") or []) if str(h).strip()]
    hook = _split_long(str(payload.get("hook") or (hooks[0] if hooks else sents[0])).strip(), max_cps)[0]
    # narration must open with the chosen hook, and it must stay inside one caption
    if hook.lower() != sents[0].lower():
        sents[0] = hook
    sents = [part for sent in sents for part in _split_long(sent, max_cps)]
    kws = [re.sub(r"\s+", " ", str(k)).strip().lower() for k in (payload.get("keywords") or [])]
    kws = [k for k in kws if 2 < len(k) < 40]
    if not kws:
        kws = [idea[:40].lower()]
    tags = [str(t).strip() for t in (payload.get("hashtags") or []) if str(t).strip()]
    if not any(t.lower() in ("#shorts", "#reels", "#tiktok") for t in tags):
        tags.append("#shorts")
    return {
        "topic": idea,
        "hook": hook,
        "hooks": hooks or [hook],
        "hook_reason": payload.get("chosen_hook_reason", ""),
        "script_sentences": sents,
        "voiceover_script": " ".join(sents),
        "keywords": kws[:8],
        "title": str(payload.get("title") or hook)[:80],
        "description": str(payload.get("description") or "")[:200],
        "hashtags": tags[:6],
        "cta": payload.get("cta", ""),
        "tts_direction": payload.get("tts_direction", ""),
        "on_screen_text": payload.get("on_screen_text") or [],
        "is_ai_generated": bool(payload.get("is_ai_generated", True)),
        "claims_to_verify": payload.get("claims_to_verify") or [],
        "estimated_seconds": est,
        "words": words(" ".join(sents)),
    }


def generate(idea: str, context: dict | None = None) -> dict[str, Any]:
    s = get_settings()
    ctx = ""
    if context:
        bits = [f"{k}: {v}" for k, v in context.items() if v and k != "_score"]
        ctx = "\n\nFacts from the source feed (you may rely on these, nothing else):\n" + "\n".join(bits[:6])
    user = (
        f"TOPIC: {idea}\n"
        f"NICHE: {s.niche}\n"
        f"LANGUAGE: {s.language}\n"
        f"TARGET DURATION: {s.target_seconds}s (hard ceiling {int(s.target_seconds*1.35)}s)\n"
        f"SPOKEN RATE: ~{s.words_per_second} words/second -> {int(s.target_seconds*s.words_per_second)} words total\n"
        f"CAPTION LIMIT: {s.max_cps} characters per caption chunk\n"
        f"FOOTAGE STYLE: stock b-roll only, no text overlays in keywords, no brand names\n"
        f"{ctx}"
    )
    schema = SCHEMA.replace("{max_cps}", str(s.max_cps))
    payload, usage = complete_json(SYSTEM, user, schema)
    script = _clean(payload, idea, s.max_cps, s.target_seconds)
    script["_usage"] = usage
    log.info(
        "script ok: %s sentences, %s words, ~%ss, %s keywords, cost~$%s",
        len(script["script_sentences"]),
        script["words"],
        script["estimated_seconds"],
        len(script["keywords"]),
        usage.get("usd_hint", 0),
    )
    return script


def validate(script: dict) -> tuple[bool, list[str]]:
    """Pre-render gate. Fails fast rather than burning render minutes on junk."""
    problems: list[str] = []
    s = get_settings()
    n = len(script.get("script_sentences") or [])
    if n < 3:
        problems.append(f"only {n} sentences - too thin to hold retention")
    if n > 24:
        problems.append(f"{n} caption chunks - will feel rushed")
    if not (script.get("keywords") or []):
        problems.append("no footage keywords")
    over = [c for c in script.get("script_sentences", []) if len(c) > s.max_cps + 12]
    if over:
        problems.append(f"{len(over)} caption chunks exceed {s.max_cps} chars")
    for bad in ("did you know", "welcome back", "in this video"):
        if bad in (script.get("hook", "") + " " + " ".join(script.get("script_sentences", []))).lower():
            problems.append(f"banned opener: '{bad}'")
    if not script.get("title"):
        problems.append("missing title")
    return (not problems, problems)
