"""
STAGE 3a - Footage sourcing.

Cost control is the point here, not variety:
  * one download per keyword, reused across sentences (1 API call + 1 file fetch
    per video at the extreme) - see `clips_per_video`
  * on-disk content-addressed cache, so a retry after a failed render costs nothing
  * local folder pool as fallback: your own clips beat any stock search on relevance
  * vertical (portrait) preference - cropping a landscape 4K clip to 9:16 throws
    away ~60% of the pixels and the bitrate you paid for

Providers: pexels | pixabay | coverr | local | mock. `mock` generates synthetic
clips so the whole pipeline is testable with no keys (that is what CI runs).
"""
from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path
from typing import Any

from ..config import ASSETS, get_settings
from ..util import log, probe, retry, run, sha1, tsv_safe

CACHE = ASSETS / "cache"
LOCAL = ASSETS / "local_clips"


def _cache_get(key: str) -> Path | None:
    p = CACHE / f"{key}.mp4"
    return p if p.exists() and p.stat().st_size > 10_000 else None


def _cache_put(key: str, tmp: Path) -> Path:
    CACHE.mkdir(parents=True, exist_ok=True)
    dst = CACHE / f"{key}.mp4"
    shutil.move(str(tmp), dst)
    return dst


@retry(times=3)
def _download(url: str, dst: Path, max_bytes: int) -> Path:
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (acp-pipeline/1.0)"})
    with urllib.request.urlopen(req, timeout=60) as r, dst.open("wb") as f:  # noqa: S310
        got = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            got += len(chunk)
            f.write(chunk)
            if got > max_bytes:
                raise RuntimeError(f"{url} exceeds DOWNLOAD_MAX_MB ({max_bytes/1e6:.0f}MB)")
    return dst


# --------------------------------------------------------------------- providers
def search_pexels(query: str, per_page: int = 6) -> list[dict]:
    s = get_settings()
    import urllib.parse
    import urllib.request

    q = urllib.parse.urlencode(
        {"query": query, "orientation": "portrait", "per_page": per_page, "size": "medium", "locale": "en-US"}
    )
    req = urllib.request.Request(
        f"https://api.pexels.com/videos/search?{q}", headers={"Authorization": s.pexels_key}
    )
    with urllib.request.urlopen(req, timeout=25) as r:  # noqa: S310
        data = json.loads(r.read().decode())
    out = []
    for v in data.get("videos", []):
        dur = float(v.get("duration") or 0)
        if dur < s.min_clip_seconds:
            continue
        files = sorted(
            (f for f in v.get("video_files", []) if f.get("mime_type") == "video/mp4"),
            key=lambda f: abs(int(f.get("height") or 0) - s.video_h),
        )
        if not files:
            continue
        pick = files[0]
        for f in files:  # prefer a rendition close to target res, no bigger than needed
            if int(f.get("height") or 0) >= s.video_h * 0.8:
                pick = f
                break
        out.append(
            {
                "id": f"px-{v.get('id')}",
                "url": pick["link"],
                "bytes": int(pick.get("bytes") or 0),
                "duration": dur,
                "w": int(pick.get("width") or 0),
                "h": int(pick.get("height") or 0),
                "credit": "Pexels",
                "query": query,
            }
        )
    return out


def search_pixabay(query: str) -> list[dict]:
    s = get_settings()
    import urllib.parse
    import urllib.request

    q = urllib.parse.urlencode({"key": s.pixabay_key, "q": query, "video_type": "film", "safesearch": "true", "per_page": 5})
    with urllib.request.urlopen(f"https://pixabay.com/api/videos/?{q}", timeout=25) as r:  # noqa: S310
        data = json.loads(r.read().decode())
    out = []
    for h in data.get("hits", []):
        dur = float(h.get("duration") or 0)
        if dur < s.min_clip_seconds:
            continue
        item = h.get("item") or {}
        urls = item.get("videos") or {}
        pick = urls.get("medium") or urls.get("small") or urls.get("large") or {}
        if not pick.get("url"):
            continue
        out.append(
            {
                "id": f"pb-{h.get('id')}",
                "url": pick["url"],
                "bytes": int(pick.get("size") or 0),
                "duration": dur,
                "w": int(pick.get("width") or item.get("width") or 0),
                "h": int(pick.get("height") or item.get("height") or 0),
                "credit": "Pixabay",
                "query": query,
            }
        )
    return out


def search_coverr(query: str) -> list[dict]:
    """Coverr's API shape changes with plan; keep it optional and defensive."""
    s = get_settings()
    if not s.coverr_key:
        raise RuntimeError("COVERR_API_KEY not set")
    import urllib.parse
    import urllib.request

    q = urllib.parse.urlencode({"query": query, "limit": 5})
    req = urllib.request.Request(f"https://api.coverr.co/videos/search?{q}", headers={"Authorization": s.coverr_key})
    with urllib.request.urlopen(req, timeout=25) as r:  # noqa: S310
        data = json.loads(r.read().decode())
    out = []
    for v in data.get("results", data if isinstance(data, list) else []):
        srcs = v.get("sources") or v.get("files") or []
        mp4 = next((x for x in srcs if str(x.get("mime_type", "video/mp4")).endswith("mp4") or str(x.get("format", "")).lower() == "mp4"), None)
        link = (mp4 or {}).get("url") or v.get("download_url")
        if link:
            out.append(
                {
                    "id": f"cv-{v.get('id')}",
                    "url": link,
                    "bytes": int((mp4 or {}).get("size") or 0),
                    "duration": float(v.get("duration") or 0),
                    "w": 0,
                    "h": 0,
                    "credit": "Coverr",
                    "query": query,
                }
            )
    return out


def search_local(query: str) -> list[dict]:
    """Own footage pool: `assets/local_clips/*.mp4`, optional `query.txt` sidecar tags."""
    out = []
    for p in sorted(LOCAL.glob("*")):
        if p.suffix.lower() not in (".mp4", ".mov", ".webm", ".mkv"):
            continue
        tags = ""
        side = p.with_suffix(".txt")
        if side.exists():
            tags = side.read_text(errors="ignore").lower()
        meta = probe(str(p))
        score = 1.0
        if tags and query:
            score = sum(1 for w in re.findall(r"\w+", query.lower()) if w in tags) or 0.2
        out.append(
            {
                "id": f"loc-{p.name}",
                "url": str(p),
                "bytes": p.stat().st_size,
                "duration": meta["duration"],
                "w": meta["width"],
                "h": meta["height"],
                "credit": "owned",
                "query": query,
                "_score": score,
            }
        )
    out.sort(key=lambda d: -d.get("_score", 0))
    return out


@retry(times=1)
def make_mock(query: str, seconds: float | None = None) -> list[dict]:
    """Synthetic clip so the pipeline is runnable with zero accounts/keys."""
    s = get_settings()
    out = ASSETS / "mock"
    out.mkdir(parents=True, exist_ok=True)
    seconds = float(seconds or os.environ.get("MOCK_CLIP_SECONDS", "30"))
    p = out / f"mock_{sha1(query)}_{int(seconds)}s.mp4"
    if not p.exists():
        hue = int(sha1(query)[:3], 16) % 360
        run(
            [
                s.ffmpeg_bin, "-v", "error", "-y", "-f", "lavfi",
                "-i", f"gradients=size={s.video_w}x{s.video_h}:rate={s.fps}:duration={seconds}:c0=black:c1=0x{hue:06x}:speed=0.02",
                "-f", "lavfi", "-i", f"anoisesrc=colour=brown:amplitude=0.02:duration={seconds}",
                "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-shortest", str(p),
            ],
            timeout=120,
        )
    return [
        {
            "id": f"mock-{sha1(query)}",
            "url": str(p),
            "bytes": p.stat().st_size,
            "duration": 8.0,
            "w": s.video_w,
            "h": s.video_h,
            "credit": "synthetic",
            "query": query,
        }
    ]


SEARCHERS: dict[str, Any] = {
    "pexels": search_pexels,
    "pixabay": search_pixabay,
    "coverr": search_coverr,
    "local": search_local,
    "mock": make_mock,
}


# --------------------------------------------------------------------- assembly
def _portrait_ok(clip: dict, s) -> bool:
    if not clip.get("w") or not clip.get("h"):
        return True
    ar = clip["w"] / max(1, clip["h"])
    return ar <= (s.video_w / s.video_h) + 0.35  # portrait-ish or square-ish


def _pick(query: str, s, used: set[str]) -> dict | None:
    providers = [s.asset_provider] + [p for p in ("local", "pixabay", "pexels") if p != s.asset_provider]
    for name in providers:
        fn = SEARCHERS.get(name)
        if not fn:
            continue
        if name in ("pexels", "pixabay", "coverr") and not getattr(s, f"{name}_key"):
            continue
        try:
            hits = fn(query)
        except Exception as e:  # noqa: BLE001
            log.warning("%s search failed (%s) -> next provider", name, str(e)[:140])
            continue
        hits = [c for c in hits if c.get("url") and c["id"] not in used]
        hits = [c for c in hits if _portrait_ok(c, s)] or hits
        if not hits:
            continue
        hits.sort(key=lambda c: (0 if c.get("h", 0) >= s.video_h else 1, abs(c.get("bytes", 0) - 4_000_000)))
        return hits[0]
    return None


def gather(script: dict) -> dict:
    """-> {'clips':[local paths], 'credits':[...], 'bytes':int, 'api_calls':int}"""
    s = get_settings()
    keywords = script.get("keywords") or [script["topic"]]
    n_clips = max(s.clips_per_video, 1)
    used: set[str] = set()
    api_calls = 0
    picked: list[dict] = []

    for i in range(n_clips):
        query = tsv_safe(keywords[i % len(keywords)])
        clip = _pick(query, s, used)
        api_calls += 1
        if not clip:
            log.warning("no asset for '%s' - leaving gap (see README: fall back to local pool)", query)
            continue
        used.add(clip["id"])
        if clip["url"].startswith(("http://", "https://")):
            key = sha1(f"{clip['id']}:{clip['url']}")
            cached = _cache_get(key)
            if cached:
                clip["path"] = str(cached)
                clip["cached"] = True
            else:
                tmp = CACHE / f"tmp_{key}.mp4"
                CACHE.mkdir(parents=True, exist_ok=True)
                try:
                    _download(clip["url"], tmp, s.download_max_bytes)
                    clip["path"] = str(_cache_put(key, tmp))
                except Exception as e:  # noqa: BLE001
                    log.warning("download failed for %s: %s", clip["url"][:80], str(e)[:140])
                    continue
        else:
            clip["path"] = clip["url"]
        clip["probe"] = probe(clip.get("path"))
        picked.append(clip)

    if not picked:
        raise RuntimeError(
            "no footage available: set PEXELS_API_KEY/PIXABAY_API_KEY, add clips to assets/local_clips/, "
            "or run with ASSET_PROVIDER=mock"
        )
    total_bytes = sum(int(p.get("bytes") or p.get("probe", {}).get("duration") and Path(p["path"]).stat().st_size or 0) for p in picked)
    return {
        "clips": [p["path"] for p in picked],
        "clip_meta": [
            {k: v for k, v in p.items() if k not in ("url",)} for p in picked
        ],
        "credits": sorted({p.get("credit", "?") for p in picked}),
        "bytes": total_bytes,
        "api_calls": api_calls,
        "queries": [p.get("query") for p in picked],
    }
