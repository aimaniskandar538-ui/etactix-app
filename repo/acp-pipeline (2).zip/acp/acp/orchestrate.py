"""
The orchestrator: a resumable state machine over SQLite with platform-aware
scheduling, a cost circuit-breaker and idempotent claiming.

    new -> scripted -> assets -> voiced -> captioned -> rendered
        -> awaiting_approval -> approved -> publishing -> published
        (any step -> failed, retryable) | skipped

n8n/Make can drive the exact same transitions over HTTP (see api.py + n8n/), which
is why nothing here knows about cron: this module is a library of steps, the
scheduler is whatever you point at it.

Two guards that matter in production:
  * `budget_ok()` - a runaway retry loop on an LLM + ElevenLabs account is the #1
    way these pipelines bill $300 overnight. Hard stop per day, per job.
  * `platform_slot()` - every social API has a per-account *rolling 24 h* publishing
    cap (IG 50-100, TikTok ~25/account + an app-wide active-user cap, YT 100 uploads
    /project). We schedule around those instead of discovering them via 429.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import get_settings
from .db import Store
from .util import log, read_json_if_exists


class Pipeline:
    def __init__(self) -> None:
        self.s = get_settings()
        self.db = Store(self.s.db_path)

    # ------------------------------------------------------------------ helpers
    def job_dir(self, job_id: int) -> Path:
        p = Path(self.s.work_dir) / f"job_{job_id:05d}"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def budget_ok(self, job_id: int | None = None) -> tuple[bool, str]:
        spent = self.db.today_cost()
        if spent >= self.s.daily_budget_usd:
            return False, f"daily budget exhausted (${spent:.2f} >= ${self.s.daily_budget_usd:.2f})"
        if job_id:
            j = self.db.get(job_id)
            if j and (j.get("attempts") or 0) >= 3:
                return False, "job hit 3 attempts - needs human eyes"
        return True, ""

    def public_host(self, job_id: int, video: str) -> str | None:
        """URL the platform's fetcher can GET. Three routes, cheapest first:
        1. PUBLIC_BASE_URL: we hardlink/copy the render into MEDIA_DIR (which is what
           `acp serve` exposes at /media/... and what your tunnel should point at)
        2. R2/S3: upload + presign (no tunnel, survives reboots, best for VPS)
        3. nothing -> TikTok falls back to FILE_UPLOAD; IG simply can't run."""
        from .publishers.youtube import public_url

        s = self.s
        if s.public_base_url:
            src, dst_dir = Path(video), Path(s.media_dir) / f"job_{job_id:05d}"
            dst_dir.mkdir(parents=True, exist_ok=True)
            dst = dst_dir / Path(video).name
            if not dst.exists() and src.exists():
                try:
                    os.link(src, dst)  # hardlink: no copy, no extra disk
                except OSError:
                    shutil.copy2(src, dst)
            return s.public_base_url.rstrip("/") + f"/media/job_{job_id:05d}/{Path(video).name}"
        return public_url(self.job_dir(job_id), video)

    # ------------------------------------------------------------------ stages
    def stage_script(self, job_id: int) -> None:
        from .stages import script as stage2

        # _need() is the precondition guard; it raises if the queue skipped a state.
        job = self._need(job_id, ("new",))
        ok, why = self.budget_ok(job_id)
        if not ok:
            self.db.update(job_id, None, error=why, publish_after=_plus_minutes(30))
            return
        # `jobs.json` is a TEXT COLUMN holding this job's context/payload - NOT a path.
        # Going through read_json_if_exists() made Path(context_json).exists() run, which for
        # any context longer than NAME_MAX raised ENAMETOOLONG and, worse, silently returned
        # None for short ones - so trend context (headlines, traffic) never reached the prompt.
        context = self.db.payload(job_id) if job.get("json") else {}
        payload = stage2.generate(job["idea"], context or {})
        good, problems = stage2.validate(payload)
        usage = payload.pop("_usage", {})
        self.db.add_cost(job_id, float(usage.get("usd_hint", 0)))
        if not good:
            raise RuntimeError("script rejected: " + "; ".join(problems))
        self.db.patch_payload(job_id, script=payload, llm_usage=usage)
        self.db.update(job_id, "scripted", script=payload["voiceover_script"])

    def stage_assets(self, job_id: int) -> None:
        from .stages import assets as stage3a

        # _need() is the precondition guard; it raises if the queue skipped a state.
        self._need(job_id, ("scripted",))
        script = self.db.payload(job_id).get("script") or {}
        res = stage3a.gather(script)
        self.db.patch_payload(job_id, assets=res)
        self.db.update(job_id, "assets")
        log.info("job %s: %s clip(s), %s bytes, %s api call(s)", job_id, len(res["clips"]), res["bytes"], res["api_calls"])

    def stage_voice(self, job_id: int) -> None:
        from .stages import speech as stage3b

        # _need() is the precondition guard; it raises if the queue skipped a state.
        self._need(job_id, ("assets",))
        script = self.db.payload(job_id).get("script") or {}
        res = stage3b.synthesize(script.get("script_sentences") or [script.get("voiceover_script", "")], self.job_dir(job_id))
        # per-provider money estimate
        cost = 0.0
        if res["provider"] == "elevenlabs":
            cost = res["chars"] / 1e6 * 60.0
        elif res["provider"] == "openai":
            cost = res["chars"] / 1e6 * 15.0
        self.db.add_cost(job_id, round(cost, 5))
        self.db.patch_payload(job_id, voice=res)
        self.db.update(job_id, "voiced")

    def stage_captions(self, job_id: int) -> None:
        from .stages import subs

        # _need() is the precondition guard; it raises if the queue skipped a state.
        self._need(job_id, ("voiced", "captioned"))
        p = self.db.payload(job_id)
        script = p.get("script") or {}
        res = subs.write_files(self.job_dir(job_id), (p.get("voice") or {}).get("captions") or [], script.get("on_screen_text"))
        res["qc"] = subs.qc_stats(self.job_dir(job_id))
        self.db.patch_payload(job_id, subs=res)
        self.db.update(job_id, "captioned")

    def stage_render(self, job_id: int) -> None:
        from .stages import render as stage3d

        # _need() is the precondition guard; it raises if the queue skipped a state.
        self._need(job_id, ("captioned",))
        p = self.db.payload(job_id)
        d = self.job_dir(job_id)
        voice = dict(p.get("voice") or {})
        voice["ass"] = str(d / "captions.ass")
        res = stage3d.render(d, p.get("script") or {}, p.get("assets") or {}, voice)
        self.db.patch_payload(job_id, render=res)
        next_state = "awaiting_approval" if (self.s.require_approval and not self.s.auto_publish) else "approved"
        self.db.update(job_id, next_state)
        if res["warnings"]:
            log.warning("job %s QC warnings: %s", job_id, " | ".join(res["warnings"]))

    def stage_publish(self, job_id: int, platforms: list[str] | None = None, dry: bool = False) -> dict:
        from .publishers import build

        job = self.db.get(job_id)
        if not job:
            raise KeyError(f"no job {job_id}")
        if (job.get("approved") in (None, 0)) and self.s.require_approval and not dry:
            raise PermissionError(f"job {job_id} is not approved (set approved=1 or REQUIRE_APPROVAL=false)")
        p = self.db.payload(job_id)
        render = p.get("render") or {}
        video = render.get("video")
        if not video or not Path(video).exists():
            raise RuntimeError("nothing rendered yet / video file missing")
        script = p.get("script") or {}
        platforms = platforms or [x.strip() for x in self.s.platforms.split(",") if x.strip()]
        results = dict(json.loads(job.get("publish") or "{}"))
        self.db.update(job_id, "publishing")

        meta = {
            "title": script.get("title"),
            "description": script.get("description"),
            "hashtags": script.get("hashtags"),
            "hook": script.get("hook"),
            "duration": render.get("duration"),
            "is_ai_generated": script.get("is_ai_generated", True),
            "publish_at": p.get("publish_at"),
            "cover_ms": 1000,
        }
        url_needed = [x for x in platforms if x in ("instagram", "postiz", "uploadpost", "mock")]
        media_url = self.public_host(job_id, video) if (url_needed or "tiktok" in platforms) else None

        for platform in platforms:
            slot_ok, why = self.platform_slot(platform)
            if not slot_ok:
                held = self.db.payload(job_id).get("publish_holds", 0) + 1
                self.db.patch_payload(job_id, publish_holds=held)
                results[platform] = {"held": why, "at": _now(), "hold_no": held}
                if held >= 6:
                    self.db.update(job_id, "failed", publish=json.dumps(results, indent=1), error=f"publish held {held}x: {why}")
                else:
                    self.db.update(job_id, "approved", publish=json.dumps(results, indent=1), publish_after=_plus_minutes(20))
                log.warning("job %s held back (%s/6): %s", job_id, held, why)
                continue
            if dry:
                results[platform] = {"provider": platform, "dry_run": True, "meta": meta, "media_url": media_url, "video": video}
                continue
            try:
                pub = build(platform)
                if platform == "youtube":  # only YouTube takes a local file (resumable upload)
                    out = pub.upload(meta, video, local_path=video)
                else:
                    if not media_url:
                        raise RuntimeError(
                            f"{platform} publishes by URL: set PUBLIC_BASE_URL (tunnel) or R2_BUCKET/R2_ENDPOINT"
                        )
                    kw: dict = {}
                    if platform == "tiktok":
                        kw["public_url"] = media_url
                    if platform == "instagram":
                        kw["container_id"] = (results.get(platform) or {}).get("container_id")
                    out = pub.publish(meta, media_url if platform == "instagram" else video, **kw)
                results[platform] = {**out, "at": _now()}
                self.db.quota_spend(platform)
            except Exception as e:  # noqa: BLE001
                from .publishers.tiktok import TikTokError

                park = isinstance(e, TikTokError) and e.park
                results[platform] = {"error": str(e)[:500], "at": _now(), "parked_until": _plus_minutes(1440 if park else 15)}
                log.error("job %s %s failed%s: %s", job_id, platform, " (parked 24h)" if park else "", str(e)[:220])
                if park:
                    self.db.update(job_id, "awaiting_approval", publish=json.dumps(results), publish_after=_plus_hours(24))
                    return results
            self.db.update(job_id, None, publish=json.dumps(results))
        ok = [k for k, v in results.items() if isinstance(v, dict) and not v.get("error") and not v.get("held")]
        state = "published" if (ok and not dry) else "approved"
        self.db.update(job_id, state, publish=json.dumps(results, indent=1),
                       error=None if ok else (json.dumps(results)[:400] if not ok else None))
        if ok:
            self.db.patch_payload(job_id, publish_holds=0)
        return results

    # ------------------------------------------------------------------ scheduling
    def platform_slot(self, platform: str) -> tuple[bool, str]:
        caps = self.s.caps()
        cap = caps.get(platform)
        if cap:
            used = self.db.quota_used(time.strftime("%Y-%m-%d"), platform)
            if used >= cap:
                return False, f"{platform}: {used}/{cap} posts today (our cap) - waiting for the rolling window"
        if platform == "instagram":
            try:
                from .publishers.instagram import Instagram

                head = Instagram().headroom()
                if head.get("remaining") is not None and head["remaining"] <= 1:
                    return False, f"instagram: Meta reports {head['remaining']} of {head['limit']} left in 24h window"
            except Exception as e:  # noqa: BLE001 - creds may legitimately be absent
                log.debug("ig headroom check skipped: %s", str(e)[:120])
        # spacing: never two posts to the same account inside MIN_GAP_MINUTES
        for job in self.db.list_jobs("published", 8):
            try:
                pr = json.loads(job.get("publish") or "{}")
            except json.JSONDecodeError:
                continue
            r = pr.get(platform) or {}
            at = r.get("at")
            if at:
                try:
                    dt = datetime.fromisoformat(at)
                    if datetime.now(timezone.utc) - dt < timedelta(minutes=self.s.min_gap_minutes):
                        return False, f"{platform}: last post {round((datetime.now(timezone.utc)-dt).total_seconds()/60)} min ago; min gap is {self.s.min_gap_minutes} min"
                except ValueError:
                    pass
        return True, ""

    def publish_windows(self, hour: int | None = None) -> bool:
        """Optional posting windows (audience local time). Empty env = always ok."""
        spec = __import__("os").environ.get("PUBLISH_WINDOWS", "")
        if not spec:
            return True
        hour = datetime.now().hour if hour is None else hour
        for part in spec.split(","):
            if "-" in part:
                a, b = part.split("-")
                if int(a) <= hour < int(b):
                    return True
        return False

    def approve(self, job_id: int, approve: bool = True) -> None:
        self.db.update(job_id, "approved" if approve else "skipped", approved=1 if approve else 0)

    def _need(self, job_id: int, expect: tuple[str, ...]) -> dict:
        job = self.db.get(job_id)
        if not job:
            raise KeyError(f"no such job {job_id}")
        if job["state"] not in expect:
            raise RuntimeError(f"job {job_id} is '{job['state']}', expected one of {expect}")
        return job

    # ------------------------------------------------------------------ drivers
    def run_job(self, job_id: int, until: str = "rendered") -> dict:
        """Advance one job as far as its current state allows. Safe to call repeatedly
        (n8n cron, systemd timer, or a loop): each stage is claimed, so a second
        worker never double-renders or double-posts."""
        steps = [
            ("new", self.stage_script),
            ("scripted", self.stage_assets),
            ("assets", self.stage_voice),
            ("voiced", self.stage_captions),
            ("captioned", self.stage_render),
        ]
        for state, fn in steps:
            job = self.db.get(job_id)
            if not job:
                break
            if job["state"] != state:
                continue
            self.db.update(job_id, None, attempts=(job.get("attempts") or 0) + 1)
            try:
                fn(job_id)
            except Exception as e:  # noqa: BLE001
                self.db.fail(job_id, f"{state}: {type(e).__name__}: {e}")
                raise
            if state == until:
                break
        return {"job": self.db.get(job_id), "payload_keys": list(self.db.payload(job_id))}

    def create_from_ideas(self, ideas: list[dict]) -> list[int]:
        ids = []
        for idea in ideas:
            ids.append(
                self.db.create_job(
                    idea=idea.get("title") or str(idea)[:120],
                    source=idea.get("source", "manual"),
                    source_url=idea.get("url", ""),
                    score=float(idea.get("score") or 0),
                    json=json.dumps(idea.get("context") or {}),
                )
            )
        return ids

    def publishable(self, limit: int = 3) -> list[dict]:
        """Approved jobs that can go out RIGHT NOW (quota + spacing + window all clear).

        The availability check lives in Python, not in n8n, so the automation tool only
        has to iterate a list - no per-platform business logic in the workflow UI.
        """
        out = []
        for j in self.db.next_job("approved", 40):
            ok_all = self.publish_windows()
            detail = {}
            for plat in [x.strip() for x in self.s.platforms.split(",") if x.strip()]:
                ok, why = self.platform_slot(plat)
                detail[plat] = "ready" if ok else why
                ok_all = ok_all and ok
            if ok_all:
                out.append({"id": j["id"], "idea": j["idea"], "ready": list(detail), "cost_usd": j["cost_usd"]})
            if len(out) >= limit:
                break
        return out

    def clean(self, keep_days: int = 7, cache_days: int = 14) -> dict:
        """Delete intermediates of old jobs (keep final.mp4 + the debug JSON) and prune the
        footage cache. Run weekly from cron; disk full is how pipelines die silently."""
        import time as _t

        cutoff = _t.time() - keep_days * 86400
        removed, freed = 0, 0
        keep = ("final.mp4", "qc.json", "timings.json", "captions.json", "captions.ass",
                "captions.vtt", "render_meta.json", "cover.jpg")
        for d in sorted(Path(self.s.work_dir).glob("job_*")):
            if not d.is_dir() or d.stat().st_mtime > cutoff:
                continue
            for f in d.iterdir():
                if f.name in keep:
                    continue
                try:
                    freed += f.stat().st_size
                    f.unlink()
                    removed += 1
                except OSError:
                    pass
        cache_removed = 0
        cd = Path(self.s.work_dir).parent / "assets" / "cache"
        if cd.exists():
            ref = set()
            for j in self.db.list_jobs(None, 2000):
                for c in (self.db.payload(j["id"]).get("assets") or {}).get("clips", []) or []:
                    ref.add(Path(c).name)
            for f in cd.glob("*.mp4"):
                if f.stat().st_mtime < _t.time() - cache_days * 86400 or (cache_days == 0 and f.name not in ref):
                    freed += f.stat().st_size
                    f.unlink()
                    cache_removed += 1
        return {"removed": removed, "cache_removed": cache_removed, "freed_mb": round(freed / 1e6, 1)}

    def status(self) -> dict:
        counts = self.db.counts()
        today = self.db.list_jobs(None, 200)
        today = [j for j in today if j["run_date"] == time.strftime("%Y-%m-%d")]
        return {
            "states": counts,
            "today_jobs": len(today),
            "today_cost_usd": round(self.db.today_cost(), 4),
            "budget_usd": self.s.daily_budget_usd,
            "queued_publish": len(self.db.next_job("approved", 100)),
            "caps": self.s.caps(),
            "used_today": {p: self.db.quota_used(time.strftime("%Y-%m-%d"), p) for p in self.s.caps()},
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _plus_minutes(m: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(minutes=m)).isoformat(timespec="seconds")


def _plus_hours(h: float) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=h)).isoformat(timespec="seconds")
