"""
ACP - Autonomous Content Pipeline.

CLI:
  acp selftest                     check deps/keys, print the exact gaps
  acp trends [-n 8]               stage 1 only (discovery)
  acp new --idea "..."            create one job by hand
  acp run [--limit 2] [--publish] one full pass over the queue
  acp status | jobs | log         what happened
  acp approve <id> | reject <id>  human gate
  acp publish <id> [--dry-run]    stage 4
  acp retry <id>                  resume from the last good state
  acp auth youtube                one-time OAuth dance -> refresh token
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .config import ROOT, get_settings
from .db import Store
from .util import human, setup_logging


def _is_tty() -> bool:
    try:
        return bool(sys.stdin.isatty() and sys.stdout.isatty())
    except (ValueError, OSError):
        return False


def choose(options: list[tuple[str, str]], prompt: str = "choose> ") -> int:
    """Tiny stdlib picker. Returns the 0-based index, or -1 on EOF / non-interactive stdin.

    -1 is the important part: CI, cron and `docker exec` have no TTY, and a menu that
    raises EOFError in a cron job turns an outage into a 3am page.
    """
    if not _is_tty():
        return -1
    for i, (label, _fn) in enumerate(options, 1):
        print(f"  {i:2d}) {label}")
    try:
        raw = input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return -1
    if raw in ("", "0", "q", "quit", "exit"):
        return -1
    try:
        n = int(raw) - 1
    except ValueError:
        hits = [i for i, (label, _f) in enumerate(options) if label.lower().startswith(raw.lower())]
        n = hits[0] if len(hits) == 1 else -2
    return n if 0 <= n < len(options) else -2


def cmd_menu(a) -> int:
    """Interactive dispatcher. Reuses main() so a menu choice and a CLI call are the same code."""
    options: list[tuple[str, list[str]]] = [
        ("selftest  - deps, keys, ffmpeg capabilities", ["selftest"]),
        ("trends    - stage 1: show today's ranked ideas", ["trends", "-n", "10"]),
        ("new       - queue one idea of your own", ["new", "--idea", None]),
        ("run       - stages 2-3 for queued jobs (render only)", ["run", "--limit", "2"]),
        ("jobs      - list jobs", ["jobs"]),
        ("approve   - approve a rendered job by id", ["approve", None]),
        ("publish   - publish one approved job", ["publish", None]),
        ("publish-queue - publish everything allowed right now", ["publish-queue"]),
        ("status    - queue, spend, quota headroom", ["status"]),
        ("log       - recent events", ["log", "--limit", "25"]),
        ("inspect   - one job in full detail", ["inspect", None]),
        ("retry     - resume a failed job", ["retry", None]),
        ("clean     - prune intermediates + footage cache", ["clean"]),
        ("serve     - run the HTTP control API for n8n/Make", ["serve"]),
    ]
    while True:
        print(f"\nACP - autonomous content pipeline\n{'-' * 40}")
        st = Pipeline_snapshot()
        print(st)
        idx = choose([(label, argv) for label, argv in options], "what would you like to do> ")
        if idx == -1:
            return 0
        if idx == -2:
            print("  ! not a valid choice")
            continue
        label, argv = options[idx]
        argv = [x if x is not None else _ask_arg(label) for x in argv]
        if any(x is None for x in argv):
            print("  (cancelled: missing argument)")
            continue
        print(f"$ acp {' '.join(argv)}\n")
        rc = main(argv)
        if argv[0] == "serve":      # blocking server: exit after one run when invoked from a menu
            return rc
        if not a.loop_menu:
            return rc
        print()


def _ask_arg(label: str) -> str | None:
    if "--idea" in label or label.startswith(("new",)):
        key = "idea text"
    else:
        key = "job id"
    try:
        v = input(f"  {key}> ").strip()
    except (EOFError, KeyboardInterrupt):
        return None
    return v or None


def Pipeline_snapshot() -> str:
    try:
        from .orchestrate import Pipeline

        s = Pipeline().status()
        states = ", ".join(f"{k}={v}" for k, v in sorted(s["states"].items())) or "empty"
        return (f"queue: {states} | today: {s['today_jobs']} jobs, "
                f"${s['today_cost_usd']:.3f}/${s['budget_usd']:.2f} | ready to publish: {s['queued_publish']}")
    except Exception as e:  # noqa: BLE001 - the banner must never break the menu
        return f"queue: (unavailable: {type(e).__name__}: {str(e)[:60]})"


def cmd_selftest(_a) -> int:
    from .stages.render import selfcheck
    from . import __version__

    s = get_settings()
    print(f"ACP v{__version__}  root={ROOT}")
    print("-- render toolchain --")
    for k, v in selfcheck(s).items():
        print(f"  {k:14} {v}")
    print("-- python deps --")
    for mod, why in (("requests", "optional"), ("edge_tts", "free TTS (TTS_PROVIDER=edge)"), ("pytest", "tests")):
        try:
            __import__(mod)

            print(f"  {mod:14} ok")
        except ImportError:
            print(f"  {mod:14} MISSING ({why})")
    print("-- keys --")
    keys = {
        "LLM": bool(s.llm_api_key or s.llm_provider == "echo"),
        "PEXELS": bool(s.pexels_key),
        "PIXABAY": bool(s.pixabay_key),
        "AZURE_SPEECH": bool(s.azure_key),
        "ELEVENLABS": bool(s.elevenlabs_key),
        "YOUTUBE_TOKEN": Path(s.youtube_token).exists(),
        "IG": bool(s.ig_user_id and s.ig_token),
        "TIKTOK": Path(s.tiktok_token_path).exists(),
        "POSTIZ": bool(s.postiz_key),
        "PUBLIC_BASE_URL": bool(s.public_base_url),
    }
    for k, v in keys.items():
        print(f"  {k:15} {'set' if v else '-'}")
    if not keys["LLM"]:
        print("  tip: LLM_PROVIDER=echo + ASSET_PROVIDER=mock runs the whole pipeline offline")
    if not keys["PEXELS"] and not keys["PIXABAY"] and not any(Path(s.work_dir).parent.glob("assets/local_clips/*.mp4")):
        print("  tip: no footage keys and no local clips -> ASSET_PROVIDER=mock")
    free = []
    if not keys["LLM"]:
        free.append("echo")
    return 0


def cmd_trends(a) -> int:
    from .stages.discovery import discover

    items = discover(limit=a.limit, dry_run=not a.persist)
    for i, d in enumerate(items, 1):
        print(f"{i:2d} {d.get('score', 0):7.1f}  {d.get('source', '')[:22]:<22} {d['title'][:92]}")
    if a.persist:
        from .orchestrate import Pipeline

        ids = Pipeline().create_from_ideas(items)
        print(f"created jobs {ids}")
    return 0


def cmd_new(a) -> int:
    from .orchestrate import Pipeline

    p = Pipeline()
    jid = p.db.create_job(idea=a.idea, source="manual", score=100)
    print(f"job {jid} created (state=new). Next: acp run --job {jid}")
    return 0


def cmd_run(a) -> int:
    from .orchestrate import Pipeline

    p = Pipeline()
    ids: list[int] = []
    if a.idea:
        ids += p.create_from_ideas([{"title": a.idea, "source": "manual", "score": 100}])
    if a.limit:
        ids += [j["id"] for j in p.db.list_jobs("new", a.limit)]
    if not ids and not a.job:
        print("nothing to do: no --idea/--limit jobs in state 'new'. (acp trends --persist)")
    for jid in ([a.job] if a.job else []) + [i for i in ids if i != a.job]:
        try:
            res = p.run_job(jid, until=a.until)
            job = res["job"]
            print(f"job {jid}: {job['state']}  cost {human(job.get('cost_usd'))}")
            if job["state"] in ("rendered", "awaiting_approval", "approved") and (a.publish or (p.s.auto_publish and not p.s.require_approval)):
                out = p.stage_publish(jid, platforms=a.platforms.split(",") if a.platforms else None, dry=a.dry_run)
                print(f"  publish -> {json.dumps(out)[:400]}")
        except Exception as e:  # noqa: BLE001
            print(f"job {jid}: FAILED {type(e).__name__}: {e}", file=sys.stderr)
    return 0


def cmd_status(_a) -> int:
    from .orchestrate import Pipeline

    p = Pipeline()
    print(json.dumps(p.status(), indent=1))
    return 0


def cmd_jobs(a) -> int:
    s = get_settings()
    store = Store(s.db_path)
    rows = store.list_jobs(a.state, a.limit)
    if not rows:
        print("(no jobs)")
        return 0
    print(f"{'id':>4} {'state':<18} {'cost':>7}  idea")
    for j in rows:
        print(f"{j['id']:>4} {j['state']:<18} {human(j.get('cost_usd')):>7}  {(j['idea'] or '')[:70]}")
        if j.get("error"):
            print(f"{'':>4} {'':<18} {'':>7}  ! {j['error'][:110]}")
    return 0


def cmd_log(a) -> int:
    s = get_settings()
    for e in Store(s.db_path).recent_events(a.limit):
        print(f"{e['ts']}  job={e['job_id']}  {e['kind']}: {str(e['payload'])[:120]}")
    return 0


def cmd_inspect(a) -> int:
    s = get_settings()
    j = Store(s.db_path).get(a.id)
    if not j:
        print("no such job", file=sys.stderr)
        return 2
    p = json.loads(j.get("json") or "{}")
    out = {
        "id": j["id"], "state": j["state"], "idea": j["idea"], "cost_usd": j["cost_usd"],
        "error": j["error"], "publish": json.loads(j.get("publish") or "{}"),
        "script": {k: (p.get("script") or {}).get(k) for k in ("title", "hook", "estimated_seconds", "keywords", "claims_to_verify")},
        "voice": {k: (p.get("voice") or {}).get(k) for k in ("provider", "chunks", "duration", "chars")},
        "render": {k: (p.get("render") or {}).get(k) for k in ("video", "duration", "size_mb", "width", "height", "warnings")},
        "assets": {"clips": (p.get("assets") or {}).get("clips"), "credits": (p.get("assets") or {}).get("credits"), "bytes": (p.get("assets") or {}).get("bytes")},
    }
    print(json.dumps(out, indent=1))
    return 0


def cmd_approve(a) -> int:
    from .orchestrate import Pipeline

    Pipeline().approve(a.id, approve=not a.reject)
    print(f"job {a.id} {'rejected' if a.reject else 'approved'}")
    return 0


def cmd_publish(a) -> int:
    from .orchestrate import Pipeline

    out = Pipeline().stage_publish(a.id, platforms=(a.platforms.split(",") if a.platforms else None), dry=a.dry_run)
    print(json.dumps(out, indent=1))
    return 0


def cmd_retry(a) -> int:
    s = get_settings()
    store = Store(s.db_path)
    j = store.get(a.id)
    if not j:
        print("no such job", file=sys.stderr)
        return 2
    # resume at the last completed state so finished work is never redone
    p = store.payload(a.id)
    back = "new"
    for stage, key in (("voiced", "voice"), ("assets", "assets"), ("scripted", "script")):
        if p.get(key):
            back = stage
            break
    if p.get("render"):
        back = "rendered"
    if a.from_state:
        back = a.from_state
    store.update(a.id, back, error=None, attempts=0)
    print(f"job {a.id} reset to '{back}'; run: acp run --job {a.id}")
    return 0


def cmd_auth(a) -> int:
    """One-time YouTube OAuth: prints a URL, you paste the code back. Stores refresh token."""
    s = get_settings()
    if a.provider != "youtube":
        print("this helper only does YouTube (TikTok/IG need their own OAuth apps + review)", file=sys.stderr)
        return 2
    sec = Path(s.youtube_credentials)
    if not sec.exists():
        print(f"put the downloaded OAuth client JSON at {sec} (Desktop app)", file=sys.stderr)
        return 2
    info = json.loads(sec.read_text())
    info = info.get("installed") or info.get("web") or {}
    import urllib.parse

    scope = "https://www.googleapis.com/auth/youtube.upload"
    url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(
        {"client_id": info["client_id"], "redirect_uri": "urn:ietf:wg:oauth:2.0:oob", "response_type": "code", "scope": scope, "access_type": "offline", "prompt": "consent"}
    )
    print("Open this URL, allow access, paste the code:\n" + url)
    code = input("code> ").strip()
    import urllib.request

    body = urllib.parse.urlencode({"client_id": info["client_id"], "client_secret": info["client_secret"], "code": code, "grant_type": "authorization_code", "redirect_uri": "urn:ietf:wg:oauth:2.0:oob"}).encode()
    req = urllib.request.Request("https://oauth2.googleapis.com/token", data=body, method="POST")
    import time

    with urllib.request.urlopen(req, timeout=30) as r:  # noqa: S310
        d = json.loads(r.read().decode())
    d["expires_at"] = time.time() + int(d.get("expires_in", 3600))
    tok = Path(s.youtube_token)
    tok.parent.mkdir(parents=True, exist_ok=True)
    tok.write_text(json.dumps(d))
    print(f"token saved -> {tok}  (refresh_token present: {'refresh_token' in d})")
    return 0


def cmd_publish_queue(a) -> int:
    """Drain the publish queue under the platform caps/windows. Cron-friendly: does nothing
    when nothing is ready, exits non-zero when something had to be parked for >24h."""
    from .orchestrate import Pipeline

    p = Pipeline()
    ready = p.publishable(a.limit)
    if not ready:
        print("nothing ready (nothing approved, caps full, or outside PUBLISH_WINDOWS)")
        return 0
    # Posting to a live account is the one action worth confirming - but never when stdin
    # is not a terminal, or the cron/CI invocation would hang until it is killed.
    if not a.yes and _is_tty():
        ids = ", ".join(f"#{r['id']}" for r in ready)
        print(f"about to publish to {p.s.platforms}: {ids}")
        try:
            if input("  confirm [y/N]> ").strip().lower() not in ("y", "yes"):
                # non-zero on purpose: a script/cron must be able to tell "cancelled" from "posted"
                print("  cancelled (nothing published; pass -y to skip the prompt)")
                return 1
        except (EOFError, KeyboardInterrupt):
            print("  cancelled (stdin closed)")
            return 1
    parked = 0
    for row in ready:
        out = p.stage_publish(row["id"], platforms=a.platforms.split(",") if a.platforms else None)
        bad = [k for k, v in out.items() if isinstance(v, dict) and (v.get("error") or v.get("held"))]
        parked += len(bad)
        print(f"job {row['id']}: " + ", ".join(f"{k}={v.get('url') or 'held' if isinstance(v, dict) else '?'}" for k, v in out.items()))
    stuck = [j["id"] for j in p.db.list_jobs("failed", 50) if "held" in (j.get("error") or "")]
    if stuck:
        print(f"parked too long, needs a human: {stuck}", file=sys.stderr)
        return 1
    return 0


def cmd_clean(a) -> int:
    from .orchestrate import Pipeline

    print(json.dumps(Pipeline().clean(a.keep_days, a.cache_days), indent=1))
    return 0


def cmd_loop(a) -> int:
    """Long-running worker for `docker run` / systemd: run the queue on a cadence, publish when
    allowed, and exit cleanly on SIGTERM so `docker stop` never leaves a half-written job."""
    import signal
    import time as _t
    from datetime import datetime, timezone

    from .orchestrate import Pipeline
    from .util import setup_logging

    stop = {"now": False}
    signal.signal(signal.SIGTERM, lambda *_: stop.update(now=True))
    signal.signal(signal.SIGINT, lambda *_: stop.update(now=True))

    p = Pipeline()
    cadence = a.interval
    last_run = 0.0
    print(f"acp loop: cadence {cadence}s, limit {a.limit}/run, publish={not a.no_publish}, "
          f"auto_publish={p.s.auto_publish} (Ctrl-C or SIGTERM to stop)", flush=True)
    while not stop["now"]:
        due = (_t.time() - last_run) >= cadence
        if due or p.db.list_jobs("new", 1) or p.db.list_jobs("failed", 1):
            last_run = _t.time()
            try:
                if a.limit:
                    for j in p.db.list_jobs("new", a.limit):
                        p.run_job(j["id"])
                        print(f"  job {j['id']}: {p.db.get(j['id'])['state']}", flush=True)
                if not a.no_publish:
                    for row in p.publishable(a.limit or 3):
                        res = p.stage_publish(row["id"])
                        print(f"  publish {row['id']}: "
                              + ", ".join(f"{k}={v.get('url') or 'held' if isinstance(v, dict) else '?'}" for k, v in res.items()),
                              flush=True)
                snap = p.status()
                print(f"  [{datetime.now(timezone.utc):%H:%M:%S}] states={snap['states']} "
                      f"spend=${snap['today_cost_usd']:.3f}/{snap['budget_usd']:.2f}", flush=True)
            except Exception as e:  # noqa: BLE001 - a worker that dies on one bad job is worse than one that logs
                print(f"  ! loop error: {type(e).__name__}: {str(e)[:300]}", file=sys.stderr, flush=True)
        # sleep in 1s slices so SIGTERM is honoured quickly
        for _ in range(0, max(1, min(a.sleep_slice, cadence))):
            if stop["now"]:
                break
            _t.sleep(1)
        if a.once:
            break
    print("acp loop: stopped cleanly", flush=True)
    return 0


def cmd_serve(_a) -> int:
    from .api import serve

    serve()
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="acp", description="Autonomous Content Pipeline for short-form video")
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd")          # omitted on purpose: bare `acp` opens the menu

    p = sub.add_parser("menu", help="interactive menu (default when run with no arguments)")
    p.add_argument("--loop-menu", action="store_true", help="stay in the menu after each action")
    p.set_defaults(fn=cmd_menu, loop_menu=False)

    p = sub.add_parser("loop", help="container/cron worker: run the queue on a cadence, SIGTERM-safe")
    p.add_argument("--interval", type=int, default=int(os.environ.get("ACP_LOOP_INTERVAL", "21600")),
                   help="seconds between scheduled passes (default 21600 = 6h)")
    p.add_argument("--limit", type=int, default=int(os.environ.get("ACP_LIMIT", "2")), help="jobs per pass (0 = publish only)")
    p.add_argument("--no-publish", action="store_true", help="render only, never touch a platform API")
    p.add_argument("--once", action="store_true", help="single pass then exit (useful in CI / for testing)")
    p.add_argument("--sleep-slice", type=int, default=1)
    p.set_defaults(fn=cmd_loop)

    sub.add_parser("selftest", help="check dependencies, keys and toolchain").set_defaults(fn=cmd_selftest)

    p = sub.add_parser("trends", help="stage 1: show/select ideas")
    p.add_argument("-n", "--limit", type=int, default=8)
    p.add_argument("--persist", action="store_true", help="create jobs from the top results")
    p.set_defaults(fn=cmd_trends)

    p = sub.add_parser("new", help="create a job from a manual idea")
    p.add_argument("--idea", required=True)
    p.set_defaults(fn=cmd_new)

    p = sub.add_parser("run", help="advance jobs through stages 1-3 (+4 with --publish)")
    p.add_argument("--limit", type=int, default=0, help="how many state=new jobs to process")
    p.add_argument("--job", type=int)
    p.add_argument("--idea")
    p.add_argument("--until", default="rendered", help="stop after this state (rendered|captioned|assets...)")
    p.add_argument("--publish", action="store_true")
    p.add_argument("--platforms", default="", help="comma list: youtube,instagram,tiktok,postiz,uploadpost,mock")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(fn=cmd_run)

    sub.add_parser("status", help="queue + budget + quota snapshot").set_defaults(fn=cmd_status)

    p = sub.add_parser("jobs", help="list jobs")
    p.add_argument("--state")
    p.add_argument("--limit", type=int, default=25)
    p.set_defaults(fn=cmd_jobs)

    p = sub.add_parser("log", help="recent events")
    p.add_argument("--limit", type=int, default=30)
    p.set_defaults(fn=cmd_log)

    p = sub.add_parser("inspect", help="full job detail")
    p.add_argument("id", type=int)
    p.set_defaults(fn=cmd_inspect)

    p = sub.add_parser("approve", help="approve a rendered job for publishing")
    p.add_argument("id", type=int)
    p.add_argument("--reject", action="store_true")
    p.set_defaults(fn=cmd_approve)

    p = sub.add_parser("publish", help="stage 4")
    p.add_argument("id", type=int)
    p.add_argument("--platforms", default="")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(fn=cmd_publish)

    p = sub.add_parser("retry", help="resume a failed job")
    p.add_argument("id", type=int)
    p.add_argument("--from-state", default="")
    p.set_defaults(fn=cmd_retry)

    p = sub.add_parser("auth", help="one-time OAuth setup")
    p.add_argument("provider", choices=["youtube"])
    p.set_defaults(fn=cmd_auth)

    p = sub.add_parser("publish-queue", help="stage 4 for every approved job that is allowed right now")
    p.add_argument("--limit", type=int, default=3)
    p.add_argument("-y", "--yes", action="store_true",
                   help="skip the interactive confirmation (required for cron/CI; auto-skipped when stdin is not a TTY)")
    p.add_argument("--platforms", default="", help="override PLATFORMS, e.g. youtube,instagram")
    p.set_defaults(fn=cmd_publish_queue)

    p = sub.add_parser("clean", help="prune job intermediates and the footage cache")
    p.add_argument("--keep-days", type=int, default=7)
    p.add_argument("--cache-days", type=int, default=14)
    p.set_defaults(fn=cmd_clean)

    sub.add_parser("serve", help="run the HTTP control API for n8n/Make").set_defaults(fn=cmd_serve)
    return ap


def main(argv: list[str] | None = None) -> int:
    ap = build_parser()
    argv = list(sys.argv[1:] if argv is None else argv)
    # Bare `acp` (or `acp --help` at a terminal) opens the menu instead of an argparse error,
    # so the container entrypoint and a human get the same program. Non-TTY keeps the old
    # behaviour: cron gets a usage error, not a menu waiting on stdin forever.
    if not argv:
        if _is_tty():
            return cmd_menu(argparse.Namespace(loop_menu=True))
        ap.error("the following arguments are required: cmd  (or run `acp` at a terminal for the menu)")
    args = ap.parse_args(argv)
    if getattr(args, "cmd", None) is None:
        args = argparse.Namespace(cmd="menu", fn=cmd_menu, loop_menu=True, verbose=False)
    setup_logging("DEBUG" if args.verbose else os.environ.get("LOG_LEVEL", "INFO"))
    try:
        return args.fn(args)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
