"""
HTTP control plane - what n8n / Make.com call. Stdlib only, so the render box needs
no Flask/FastAPI and no extra attack surface. Bearer token from ACP_CONTROL_TOKEN.

  GET  /health
  GET  /status                      queue, today's cost, quota headroom
  POST /trends      {limit}         stage 1 -> creates jobs
  POST /jobs        {idea}          manual idea
  POST /jobs/{id}/run   {until}     stages 2-3
  POST /jobs/{id}/approve|reject    human gate (n8n sends this after a Slack/Telegram reply)
  POST /jobs/{id}/publish {platforms, dry_run}
  GET  /jobs?state=&limit=
  GET  /jobs/{id}
  GET  /media/<file>                serves work/public so IG/TikTok PULL_FROM_URL works via a tunnel
  POST /mock/publish                local stand-in for a publisher (tests the stage-4 path offline)
"""
from __future__ import annotations

import json
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .config import get_settings


def _now_iso() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Handler(BaseHTTPRequestHandler):
    server_version = "acp/1.0"

    # ---------------------------------------------------------------- plumbing
    def _auth(self) -> bool:
        s = get_settings()
        if not (s.control_token or "").strip():
            return True  # local use; set a NON-EMPTY ACP_CONTROL_TOKEN before exposing it
        return self.headers.get("Authorization", "").replace("Bearer ", "") == s.control_token

    def _send(self, code: int, obj) -> None:
        body = json.dumps(obj, indent=1, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json_body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode())
        except json.JSONDecodeError:
            return {}

    def log_message(self, fmt: str, *a) -> None:  # quieter + single-line for n8n logs
        print(f"acp-api {self.address_string()} {fmt % a}")

    # ------------------------------------------------------------------- verbs
    def do_GET(self) -> None:  # noqa: N802
        u = urlparse(self.path)
        if not self._auth():
            return self._send(401, {"error": "bad or missing bearer token"})
        if u.path == "/health":
            return self._send(200, {"ok": True})
        if u.path == "/status":
            from .orchestrate import Pipeline

            return self._send(200, Pipeline().status())
        if u.path.startswith("/media/"):
            s = get_settings()
            f = (s.media_dir / u.path[len("/media/") :]).resolve()
            if not str(f).startswith(str(s.media_dir.resolve())) or not f.exists():
                return self._send(404, {"error": "not found"})
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4" if f.suffix == ".mp4" else "text/plain")
            self.send_header("Content-Length", str(f.stat().st_size))
            self.end_headers()
            with f.open("rb") as fh:
                while chunk := fh.read(1 << 20):
                    self.wfile.write(chunk)
            return
        if u.path == "/jobs":
            from .db import Store

            q = parse_qs(u.query)
            rows = Store(get_settings().db_path).list_jobs((q.get("state") or [""])[0] or None, int((q.get("limit") or ["25"])[0]))
            return self._send(200, {"jobs": rows})
        if u.path == "/publishable":
            from .orchestrate import Pipeline

            n = int((parse_qs(u.query).get("limit") or ["3"])[0])
            rows = Pipeline().publishable(n)
            return self._send(200, {"ready": rows, "count": len(rows), "at": _now_iso()})
        if u.path.startswith("/jobs/"):
            from .orchestrate import Pipeline

            try:
                jid = int(u.path.split("/")[2])
            except ValueError:
                return self._send(400, {"error": "job id must be an integer"})
            job = Pipeline().db.get(jid)
            return self._send(200 if job else 404, job or {"error": "no such job"})
        if u.path == "/awaiting":
            from .orchestrate import Pipeline

            rows = Pipeline().db.list_jobs("awaiting_approval", 20)
            return self._send(200, {"awaiting": [
                {"id": j["id"], "idea": j["idea"], "cost_usd": j["cost_usd"], "video": (Pipeline().db.payload(j["id"]).get("render") or {}).get("video")}
                for j in rows]})
        return self._send(404, {"error": "no route", "path": u.path})

    def do_POST(self) -> None:  # noqa: N802
        u = urlparse(self.path)
        if not self._auth():
            return self._send(401, {"error": "bad or missing bearer token"})
        body = self._json_body()
        try:
            from .orchestrate import Pipeline

            p = Pipeline()
            if u.path == "/trends":
                from .stages.discovery import discover

                ideas = discover(limit=int(body.get("limit", 2)))
                ids = p.create_from_ideas(ideas)
                return self._send(200, {"ideas": ideas, "jobs": ids})
            if u.path == "/jobs":
                jid = p.db.create_job(idea=body.get("idea", "")[:300], source=body.get("source", "api"), score=float(body.get("score") or 100))
                if body.get("run", True):
                    p.run_job(jid, until=body.get("until", "rendered"))
                return self._send(200, {"job_id": jid, "job": p.db.get(jid)})
            if u.path.startswith("/jobs/"):
                bits = u.path.strip("/").split("/")
                jid = int(bits[1])
                action = bits[2] if len(bits) > 2 else ""
                if action == "run":
                    p.run_job(jid, until=body.get("until", "rendered"))
                    return self._send(200, {"job": p.db.get(jid)})
                if action in ("approve", "reject"):
                    p.approve(jid, approve=action == "approve")
                    return self._send(200, {"job": p.db.get(jid)})
                if action == "publish":
                    out = p.stage_publish(jid, platforms=body.get("platforms"), dry=bool(body.get("dry_run")))
                    return self._send(200, {"results": out, "job": p.db.get(jid)})
                if action == "retry":
                    j = p.db.get(jid)
                    p.db.update(jid, body.get("from_state") or "new", error=None, attempts=0)
                    return self._send(200, {"job": p.db.get(jid), "was": (j or {}).get("state")})
                if action == "script":
                    p.stage_script(jid)
                    return self._send(200, {"payload": p.db.payload(jid).get("script")})
                if action == "render":
                    p.stage_assets(jid)
                    p.stage_voice(jid)
                    p.stage_captions(jid)
                    p.stage_render(jid)
                    return self._send(200, {"render": p.db.payload(jid).get("render")})
            if u.path == "/mock/publish":
                from .publishers import MockPublisher

                return self._send(200, MockPublisher().publish(body.get("meta", {}), body.get("video", "")))
            return self._send(404, {"error": "no route", "path": u.path})
        except Exception as e:  # noqa: BLE001
            detail = traceback.format_exc(limit=4).splitlines()[-3:]
            return self._send(500, {"error": f"{type(e).__name__}: {e}", "trace": detail})


def serve(host: str = "0.0.0.0", port: int | None = None) -> None:  # noqa: S104 - VPS service
    s = get_settings()
    port = port or s.control_port
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"acp control API on http://{host}:{port}  (auth: {'on' if s.control_token else 'OFF - set ACP_CONTROL_TOKEN'})")
    httpd.serve_forever()


def publish_media(job_dir: Path, filename: str) -> str:
    """Copy a render into the served dir so /media/<name> can be fetched by Meta/TikTok."""
    s = get_settings()
    dst = s.media_dir / filename
    src = job_dir / filename
    if src.exists():
        dst.write_bytes(src.read_bytes())
    if s.public_base_url:
        return s.public_base_url.rstrip("/") + "/" + filename
    return f"http://localhost:{s.control_port}/media/{filename}"
