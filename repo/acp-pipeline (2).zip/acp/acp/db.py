"""
SQLite job store = the state machine + durable queue + audit log + cost ledger.

Why SQLite instead of Redis/Celery for a solo creator: one file, zero infra, survives
reboots, queryable with `sqlite3`, and a crash mid-render just leaves the row in a
non-terminal state so `acp retry` can resume it.
"""
from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    state TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    run_date TEXT NOT NULL,          -- YYYY-MM-DD local, for daily budget/caps
    idea TEXT,
    source TEXT,
    source_url TEXT,
    score REAL DEFAULT 0,
    script TEXT,
    json TEXT,                        -- stage payloads (title/captions/paths/...)
    publish TEXT,                     -- per-platform results
    cost_usd REAL DEFAULT 0,
    attempts INTEGER DEFAULT 0,
    error TEXT,
    publish_after TEXT,               -- ISO ts; queue respects this (rate windows)
    approved INTEGER                  -- NULL = approval required, 1 = ok to publish
);
CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state);
CREATE INDEX IF NOT EXISTS idx_jobs_run ON jobs(run_date, state);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER,
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT
);

CREATE TABLE IF NOT EXISTS seen (
    key TEXT PRIMARY KEY,
    first_seen TEXT NOT NULL,
    hits INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS usage (
    day TEXT NOT NULL,
    platform TEXT NOT NULL,
    n INTEGER DEFAULT 0,
    PRIMARY KEY (day, platform)
);
"""

# Ordered lifecycle. `rendered` is the "ready to publish" checkpoint.
STATES = [
    "new",
    "scripted",
    "assets",
    "voiced",
    "captioned",
    "rendered",
    "awaiting_approval",
    "approved",
    "publishing",
    "published",
    "failed",
    "skipped",
]
TERMINAL = {"published", "failed", "skipped"}


class Store:
    def __init__(self, path: Path | str):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA journal_mode=WAL")
            yield con
            con.commit()
        finally:
            con.close()

    # ---------- jobs ----------
    def create_job(self, **fields: Any) -> int:
        now = _now()
        cols = ["state", "created_at", "updated_at", "run_date"]
        vals: list[Any] = ["new", now, now, time.strftime("%Y-%m-%d")]
        for k, v in fields.items():
            cols.append(k)
            vals.append(v)
        with self._conn() as c:
            cur = c.execute(
                f"INSERT INTO jobs ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals
            )
            jid = cur.lastrowid
            self.log(c, jid, "created", fields.get("idea"))
        return int(jid)

    def get(self, job_id: int) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(r) if r else None

    def payload(self, job_id: int) -> dict:
        j = self.get(job_id)
        return json.loads(j["json"]) if j and j["json"] else {}

    def update(self, job_id: int, state: str | None = None, **fields: Any) -> None:
        sets, vals = [], []
        if state:
            sets.append("state=?")
            vals.append(state)
        sets.append("updated_at=?")
        vals.append(_now())
        for k, v in fields.items():
            if isinstance(v, (dict, list)):
                v = json.dumps(v)
            sets.append(f"{k}=?")
            vals.append(v)
        vals.append(job_id)
        with self._conn() as c:
            c.execute(f"UPDATE jobs SET {','.join(sets)} WHERE id=?", vals)
            if state:
                self.log(c, job_id, "state", state)

    def patch_payload(self, job_id: int, **kw: Any) -> dict:
        data = self.payload(job_id)
        data.update(kw)
        with self._conn() as c:
            c.execute("UPDATE jobs SET json=?, updated_at=? WHERE id=?", (json.dumps(data), _now(), job_id))
        return data

    def next_job(self, state: str, limit: int = 1) -> list[dict]:
        """Queue with a deadline: rows whose publish_after is in the future are held back."""
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM jobs WHERE state=?
                   AND (publish_after IS NULL OR publish_after <= ?)
                   ORDER BY id LIMIT ?""",
                (state, _now(), limit),
            ).fetchall()
        return [dict(r) for r in rows]

    def claim(self, job_id: int, from_state: str, to_state: str) -> bool:
        """Optimistic lock so a second worker can't double-process / double-publish."""
        with self._conn() as c:
            cur = c.execute(
                "UPDATE jobs SET state=?, updated_at=? WHERE id=? AND state=?",
                (to_state, _now(), job_id, from_state),
            )
            if cur.rowcount:
                self.log(c, job_id, "claim", f"{from_state}->{to_state}")
            return bool(cur.rowcount)

    def list_jobs(self, state: str | None = None, limit: int = 50) -> list[dict]:
        q, args = "SELECT * FROM jobs", []
        if state:
            q += " WHERE state=?"
            args.append(state)
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with self._conn() as c:
            return [dict(r) for r in c.execute(q, args).fetchall()]

    def counts(self) -> dict[str, int]:
        with self._conn() as c:
            return {r["state"]: r["n"] for r in c.execute("SELECT state, COUNT(*) n FROM jobs GROUP BY state")}

    def fail(self, job_id: int, err: str) -> None:
        with self._conn() as c:
            j = c.execute("SELECT attempts FROM jobs WHERE id=?", (job_id,)).fetchone()
            attempts = (j["attempts"] or 0) + 1 if j else 1
            c.execute(
                "UPDATE jobs SET state='failed', error=?, attempts=?, updated_at=? WHERE id=?",
                (err[:1500], attempts, _now(), job_id),
            )
            self.log(c, job_id, "error", err[:1500])

    def add_cost(self, job_id: int, usd: float) -> None:
        with self._conn() as c:
            c.execute("UPDATE jobs SET cost_usd = COALESCE(cost_usd,0)+? WHERE id=?", (usd, job_id))

    # ---------- dedupe ----------
    def seen(self, key: str, window_days: int) -> bool:
        """True if we already turned this idea into a job in the last N days."""
        with self._conn() as c:
            r = c.execute("SELECT first_seen FROM seen WHERE key=?", (key,)).fetchone()
            if not r:
                return False
            try:
                age = datetime.now(timezone.utc) - datetime.fromisoformat(r["first_seen"])
            except ValueError:
                return False
            if age.days > window_days:
                return False
            c.execute("UPDATE seen SET hits=hits+1 WHERE key=?", (key,))
            return True

    def remember(self, key: str) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO seen(key, first_seen) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET hits=hits+1",
                (key, _now()),
            )

    # ---------- platform quota ledger ----------
    def quota_used(self, day: str, platform: str) -> int:
        with self._conn() as c:
            r = c.execute("SELECT n FROM usage WHERE day=? AND platform=?", (day, platform)).fetchone()
        return int(r["n"]) if r else 0

    def quota_spend(self, platform: str, day: str | None = None) -> int:
        day = day or time.strftime("%Y-%m-%d")
        with self._conn() as c:
            c.execute(
                "INSERT INTO usage(day, platform, n) VALUES(?,?,1) ON CONFLICT(day,platform) DO UPDATE SET n=n+1",
                (day, platform),
            )
            r = c.execute("SELECT n FROM usage WHERE day=? AND platform=?", (day, platform)).fetchone()
        return int(r["n"])

    def today_cost(self, day: str | None = None) -> float:
        day = day or time.strftime("%Y-%m-%d")
        with self._conn() as c:
            r = c.execute("SELECT COALESCE(SUM(cost_usd),0) s FROM jobs WHERE run_date=?", (day,)).fetchone()
        return float(r["s"] or 0.0)

    # ---------- misc ----------
    def log(self, con: sqlite3.Connection, job_id: int | None, kind: str, payload: Any = None) -> None:
        con.execute(
            "INSERT INTO events(job_id, ts, kind, payload) VALUES(?,?,?,?)",
            (job_id, _now(), kind, json.dumps(payload) if isinstance(payload, (dict, list)) else payload),
        )

    def recent_events(self, limit: int = 40) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
