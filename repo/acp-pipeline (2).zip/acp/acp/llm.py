"""
LLM access layer. One provider-agnostic `complete_json()` for every stage that
needs a model: OpenAI-compatible endpoints (OpenAI, Groq, OpenRouter, DeepSeek,
Ollama, LM Studio), plus native Anthropic. Also returns token counts so the cost
ledger in stage 2 can stay honest.

No SDKs required - plain urllib/requests. That keeps the render host free of
heavy dependencies (see ARCHITECTURE.md, bottleneck B1: memory on small VPS).
"""
from __future__ import annotations

import json
import re
from typing import Any

from .config import get_settings
from .util import log


class LLMError(RuntimeError):
    pass


def _post(url: str, headers: dict, payload: dict, timeout: int = 120) -> dict:
    import urllib.error
    import urllib.request

    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(), headers={**headers, "Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310
            return json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:800]
        raise LLMError(f"HTTP {e.code} from {url}: {body}") from e
    except Exception as e:  # noqa: BLE001
        raise LLMError(f"{type(e).__name__} calling {url}: {e}") from e


def _extract_json(text: str) -> dict:
    """Models wrap JSON in prose or ``` fences sometimes. Be forgiving, then strict."""
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    if fence:
        text = fence.group(1)
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end <= start:
        raise LLMError(f"no JSON object in model output: {text[:200]!r}")
    return json.loads(text[start : end + 1])


def complete_json(
    system: str,
    user: str,
    schema_hint: str,
    max_tokens: int | None = None,
    temperature: float | None = None,
) -> tuple[dict, dict]:
    """-> (parsed_json, usage). usage keys: in_tokens, out_tokens, usd_hint."""
    s = get_settings()
    if s.llm_provider == "echo":
        return _echo_payload(user), {"in_tokens": 0, "out_tokens": 0, "usd_hint": 0.0}

    prompt = f"{system}\n\nReturn ONLY a JSON object with this shape:\n{schema_hint}\n\n{s.brand_voice}\n\n{user}"
    mt = max_tokens or s.llm_max_output_tokens
    temp = s.llm_temperature if temperature is None else temperature

    if s.llm_provider == "anthropic":
        data = _post(
            "https://api.anthropic.com/v1/messages",
            {"x-api-key": s.llm_api_key, "anthropic-version": "2023-06-01"},
            {
                "model": s.llm_model,
                "max_tokens": mt,
                "temperature": temp,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        u = data.get("usage", {})
        usage = {"in_tokens": u.get("input_tokens", 0), "out_tokens": u.get("output_tokens", 0)}
    else:
        body: dict[str, Any] = {
            "model": s.llm_model,
            "max_tokens": mt,
            "temperature": temp,
            "messages": [
                {"role": "system", "content": "You output only valid JSON. No commentary."},
                {"role": "user", "content": prompt},
            ],
        }
        if s.llm_provider in ("openai", "deepseek", "groq", "openrouter"):
            body["response_format"] = {"type": "json_object"}
        data = _post(s.llm_base_url.rstrip("/") + "/chat/completions", {"Authorization": f"Bearer {s.llm_api_key}"}, body)
        choice = (data.get("choices") or [{}])[0]
        text = (choice.get("message") or {}).get("content") or ""
        u = data.get("usage") or {}
        usage = {"in_tokens": u.get("prompt_tokens", 0), "out_tokens": u.get("completion_tokens", 0)}

    # rough money: text models ~$0.15-0.60/1M in, $0.60-2.40/1M out; use midpoints
    usage["usd_hint"] = round(usage["in_tokens"] / 1e6 * 0.30 + usage["out_tokens"] / 1e6 * 1.20, 5)
    return _extract_json(text), usage


# --- echo provider: lets the whole pipeline run with zero API keys (CI / smoke test)
def _echo_payload(user: str) -> dict:
    m = re.search(r"TOPIC:\s*(.+)", user)
    topic = (m.group(1).strip() if m else "your topic").strip(".")
    sentences = [
        f"Stop scrolling, because {topic.lower()} just changed.",
        "Here is the part nobody puts in the headline.",
        "Most people are told the opposite of this.",
        f"The real reason {topic.lower()} matters to you is boring and expensive.",
        "Three things follow from that, and the third one is the problem.",
        "If you only remember one line today, make it this one.",
        "Follow for the next part, because it gets worse before it gets better.",
    ]
    return {
        "hook_variants": [s for s in sentences[:3]],
        "hook": sentences[0],
        "chosen_hook_reason": "echo provider (offline test)",
        "script_sentences": sentences,
        "keywords": [topic.lower(), topic.split()[0].lower(), "data chart", "city night", "talking"],
        "title": f"{topic} - the part nobody explains",
        "description": " ".join(sentences[:2]) + " #shorts",
        "hashtags": ["#shorts", "#explained", "#trends"],
        "cta": "Follow for part two.",
        "tts_direction": "confident, slightly fast, land the last word of every sentence",
        "on_screen_text": [
            {"start": 0.0, "text": topic[:28].upper()},
            {"start": 4.0, "text": "THE PART NOBODY SAYS"},
        ],
        "is_ai_generated": True,
        "claims_to_verify": [topic],
        "voiceover_script": " ".join(sentences),
        "estimated_seconds": round(len(" ".join(sentences)) / 13),
    }
