"""
STAGE 4a - media host + YouTube Shorts.

Two facts drive this file:
1. Instagram and TikTok PULL_FROM_URL want a *publicly fetchable* video URL, so we
   need an object store with short-lived signed URLs (Cloudflare R2 has a free
   10 GB egress tier; backblaze B2 / WASM also work). `media_host.py` below shells
   out to the aws cli so no SDK is required on the render box.
2. YouTube: since Dec 2025 `videos.insert` no longer costs 1,600 quota units; it
   bills ~1 unit against its own ~100 calls/day bucket (per *project*, not per
   channel). 20 Shorts/day for one creator is free and needs no quota audit.
   Shorts = <=3 min + 9:16 + #Shorts in title/description; the API has no "shorts"
   flag, it's classified from aspect ratio + duration.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from ..config import get_settings
from ..util import log, retry, run

YT_SCOPE = "https://www.googleapis.com/auth/youtube.upload"


# ---------------------------------------------------------------- media hosting
def public_url(job_dir: Path, video: str, expires: int = 3600) -> str | None:
    """Return a URL the platforms can fetch. None => caller must use file-upload mode."""
    s = get_settings()
    if s.public_base_url:
        return s.public_base_url.rstrip("/") + "/" + Path(video).name
    bucket = __import__("os").environ.get("R2_BUCKET", "")
    endpoint = __import__("os").environ.get("R2_ENDPOINT", "")
    if bucket and endpoint and Path(video).exists():
        key = f"acp/{Path(video).parent.name}/{Path(video).name}"
        run(["aws", "s3", "cp", video, f"s3://{bucket}/{key}", "--endpoint-url", endpoint, "--no-progress"], timeout=600)
        cp = run(
            ["aws", "s3", "presign", f"s3://{bucket}/{key}", "--expires-in", str(expires),
             "--endpoint-url", endpoint],
            timeout=120, check=False,
        )
        url = next((ln.strip() for ln in cp.stdout.splitlines() if ln.strip().startswith("https")), None)
        if url:
            log.info("uploaded %s -> signed url ok", key)
            return url
    return None


def serve_dir(port: int, directory: Path) -> None:  # pragma: no cover - helper for tunnels
    log.info("serving %s on :%s (use a tunnel/Frp/Cloudflare to expose it)", directory, port)


# ---------------------------------------------------------------------- youtube
class YouTube:
    name = "youtube"

    def __init__(self) -> None:
        s = get_settings()
        self.secrets = Path(s.youtube_credentials)
        self.token_path = Path(s.youtube_token)

    def _tokens(self) -> dict:
        d = json.loads(__import__("os").environ.get("YOUTUBE_TOKEN_JSON") or "null") if __import__("os").environ.get("YOUTUBE_TOKEN_JSON") else None
        if d:
            return d
        if not self.token_path.exists():
            raise RuntimeError(f"no YouTube token at {self.token_path} - run `acp auth youtube` first")
        return json.loads(self.token_path.read_text())

    def access_token(self) -> str:
        t = self._tokens()
        if t.get("expires_at", 0) - 60 > time.time():
            return t["access_token"]
        import urllib.parse
        import urllib.request

        sec = json.loads(self.secrets.read_text()) if self.secrets.exists() else {}
        inst = (sec.get("installed") or sec.get("web") or {})
        if not t.get("refresh_token") or not inst.get("client_id"):
            raise RuntimeError("missing refresh_token or client secrets")
        body = urllib.parse.urlencode(
            {
                "client_id": inst["client_id"],
                "client_secret": inst["client_secret"],
                "refresh_token": t["refresh_token"],
                "grant_type": "refresh_token",
            }
        ).encode()
        req = urllib.request.Request("https://oauth2.googleapis.com/token", data=body, method="POST")
        with urllib.request.urlopen(req, timeout=30) as r:  # noqa: S310
            data = json.loads(r.read().decode())
        data["expires_at"] = time.time() + int(data.get("expires_in", 3600))
        self.token_path.parent.mkdir(parents=True, exist_ok=True)
        self.token_path.write_text(json.dumps(data))
        return data["access_token"]

    @retry(times=2, base_delay=3)
    def upload(self, meta: dict, video: str, **kw: object) -> dict:
        video = str(kw.get("local_path") or video)
        title = (meta.get("title") or meta.get("hook") or "Untitled")[:95]
        if "#shorts" not in title.lower():
            title = (title + " #Shorts")[:100]
        desc = (meta.get("description") or "") + "\n\n" + " ".join(meta.get("hashtags") or [])
        body = json.dumps(
            {
                "snippet": {
                    "title": title,
                    "description": desc[:4900],
                    "tags": [h.lstrip("#") for h in (meta.get("hashtags") or [])][:10] + ["shorts", "shorts feed"],
                    "categoryId": "28",
                    "selfDeclaredMadeForKids": False,
                },
                "status": {
                    "privacyStatus": os_privacy(),
                    "selfDeclaredMadeForKids": False,
                    "embeddable": True,
                    "publishAt": meta.get("publish_at") or "",
                },
            }
        )
        if not meta.get("publish_at"):
            body_obj = json.loads(body)
            body_obj["status"].pop("publishAt")
            body = json.dumps(body_obj)
        else:
            body_obj = json.loads(body)
            body_obj["status"]["privacyStatus"] = "private"
            body = json.dumps(body_obj)

        tok = self.access_token()
        import urllib.error
        import urllib.request

        url = ("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
        req = urllib.request.Request(
            url,
            data=body.encode(),
            headers={
                "Authorization": f"Bearer {tok}",
                "Content-Type": "application/json; charset=UTF-8",
                "X-Upload-Content-Length": str(Path(video).stat().st_size),
                "X-Upload-Content-Type": "video/mp4",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as r:  # noqa: S310
                session = r.headers.get("Location") or ""
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"yt init HTTP {e.code}: {e.read().decode()[:300]}") from e
        if not session:
            raise RuntimeError("YouTube did not return a resumable session URI")

        data = Path(video).read_bytes()
        put = urllib.request.Request(
            session, data=data, headers={"Content-Length": str(len(data)), "Content-Range": f"bytes 0-{len(data)-1}/{len(data)}"}, method="PUT"
        )
        with urllib.request.urlopen(put, timeout=600) as r:  # noqa: S310
            res = json.loads(r.read().decode() or "{}")
        vid = res.get("id")
        log.info("youtube uploaded video id=%s", vid)
        return {"provider": "youtube", "id": vid, "url": f"https://youtube.com/shorts/{vid}", "scheduled": bool(meta.get("publish_at")), "caption_track_sent": False}


def os_privacy() -> str:
    import os

    return os.environ.get("YOUTUBE_PRIVACY", "public")
