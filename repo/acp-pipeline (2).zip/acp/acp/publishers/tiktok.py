"""
STAGE 4c - TikTok Content Posting API.

Why this is the fragile leg of the whole system (and what the code does about it):
  * `video.publish` needs a passed TikTok app audit; in dev mode every post is
    forced to SELF_ONLY and only 5 users may authorise per 24 h.
  * Two publish modes: PULL_FROM_URL (TikTok fetches your CDN) and FILE_UPLOAD
    (chunked PUT to a one-hour upload URL). FILE_UPLOAD is the robust one:
    no external fetch, no CDN, and the chunk protocol survives flaky uplinks.
  * `privacy_level` is mandatory and must be one of the creator's *current*
    options -> always call whoami/creator_info immediately before init, or the
    post fails with a privacy mismatch if the creator changed settings.
  * `reached_active_user_cap` / `spam_risk_too_many_posts` come back as HTTP 200
    "intentional errors" - a naive client reads 200 and thinks it worked. We treat
    them as terminal-for-today and park the queue.
  * No scheduling parameter exists. Scheduling is *our* job (queue + publish_after).
  * Rate limits per user token: creator info 20/min, video init 6/min -> a burst of
    10 posts in 60 s fails. We space posts with MIN_GAP_MINUTES.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from ..config import get_settings
from ..util import log, retry

API = "https://open.tiktokapis.com/v2"
TERMINAL_TODAY = {"reached_active_user_cap", "spam_risk_too_many_posts", "spam_risk_user_banned_from_posting", "banned_member"}


class TikTokError(RuntimeError):
    def __init__(self, msg: str, subcode: str | None = None, park: bool = False):
        super().__init__(msg)
        self.subcode, self.park = subcode, park


def _call(path: str, payload: dict | None = None, token: str = "", method: str = "POST") -> dict:
    import urllib.error
    import urllib.request

    url = path if path.startswith("http") else API + path
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json; charset=UTF-8"})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:  # noqa: S310
            raw = json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:600]
        sub = None
        try:
            sub = json.loads(body).get("error", {}).get("suberror_code")
        except json.JSONDecodeError:
            pass
        raise TikTokError(f"tt HTTP {e.code} {sub or ''}: {body}", sub, park=e.code in (403, 429)) from e
    err = raw.get("error") or {}
    if err.get("code") not in (None, "ok"):
        sub = err.get("suberror_code") or err.get("message") or ""
        raise TikTokError(f"tt error: {json.dumps(err)[:400]}", sub, park=str(sub) in TERMINAL_TODAY)
    return raw.get("data") or {}


class TikTok:
    name = "tiktok"

    def __init__(self) -> None:
        s = get_settings()
        self.token_file = Path(s.tiktok_token_path)
        if not self.token_file.exists():
            raise RuntimeError(f"no TikTok token at {self.token_file} (needs audit-approved app + user OAuth)")

    def _tok(self) -> str:
        data = json.loads(self.token_file.read_text())
        if data.get("expires_at", 0) - 120 < time.time():
            self.refresh(data)
            data = json.loads(self.token_file.read_text())
        return data["access_token"]

    def refresh(self, data: dict) -> None:  # pragma: no cover - network
        s = get_settings()
        import urllib.parse
        import urllib.request

        body = urllib.parse.urlencode(
            {
                "client_key": s.tiktok_client_key,
                "client_secret": s.tiktok_client_secret,
                "grant_type": "refresh_token",
                "refresh_token": data["refresh_token"],
            }
        ).encode()
        req = urllib.request.Request(
            "https://open.tiktokapis.com/v2/oauth/token/", data=body, headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        with urllib.request.urlopen(req, timeout=30) as r:  # noqa: S310
            d = json.loads(r.read().decode())
        if "access_token" not in d:
            raise TikTokError(f"refresh failed: {d}")
        d["expires_at"] = time.time() + int(d.get("expires_in", 86400))  # tokens are 24h - refresh before use
        self.token_file.write_text(json.dumps(d))

    @retry(times=2, base_delay=8)
    def publish(self, meta: dict, video: str, public_url: str | None = None, **_: object) -> dict:
        tok = self._tok()
        who = _call("/post/publish/creator_info/query/", {}, tok)
        privacy_opts = who.get("privacy_level_options") or ["SELF_ONLY"]
        wanted = (meta.get("privacy") or "PUBLIC_TO_EVERYONE").upper()
        privacy = wanted if wanted in privacy_opts else privacy_opts[-1]
        max_dur = int(who.get("max_video_post_duration_sec") or 600)
        duration = float(meta.get("duration") or 0)
        if duration and duration > max_dur:
            raise TikTokError(f"clip {duration:.0f}s exceeds creator cap {max_dur}s")
        if duration and duration < 3:
            raise TikTokError(f"clip {duration:.0f}s is under TikTok's 3s minimum")

        title = ((meta.get("hook") or meta.get("title") or "")[:70] + "\n" + " ".join(meta.get("hashtags") or []))[:2200]
        post_info = {
            "title": title,
            "privacy_level": privacy,
            "disable_duet": bool(meta.get("disable_duet", False)),
            "disable_comment": bool(meta.get("disable_comment", False)),
            "disable_stitch": bool(meta.get("disable_stitch", False)),
            "video_cover_timestamp_ms": int(meta.get("cover_ms", 1000)),
            "is_aigc": bool(meta.get("is_ai_generated", True)),  # label it: automated + unlabeled AI is an account risk
        }
        path = Path(video)
        if public_url:
            source = {"source": "PULL_FROM_URL", "video_url": public_url}
        else:
            size = path.stat().st_size
            if size > 4 * 1024**3:
                raise TikTokError(f"{size/1e9:.1f}GB over TikTok's 4GB API ceiling")
            chunk = 10 * 1024 * 1024
            source = {
                "source": "FILE_UPLOAD",
                "video_size": size,
                "chunk_size": min(chunk, size),
                "total_chunk_count": max(1, -(-size // chunk)),
            }
        data = _call("/post/publish/video/init/", {"post_info": post_info, "source_info": source}, tok)
        publish_id, upload_url = data.get("publish_id"), data.get("upload_url")
        if not publish_id:
            raise TikTokError(f"no publish_id: {data}")
        if upload_url:
            self._upload_chunks(upload_url, path, source.get("total_chunk_count", 1), source.get("chunk_size", 10 * 1024 * 1024))
        status = self.await_status(publish_id, tok)
        log.info("tiktok publish_id=%s status=%s", publish_id, status)
        return {"provider": "tiktok", "id": publish_id, "url": "", "status": status, "privacy": privacy}

    def _upload_chunks(self, url: str, path: Path, total_chunks: int, chunk_size: int) -> None:
        import urllib.request

        blob = path.read_bytes()
        for i in range(total_chunks):
            part = blob[i * chunk_size : (i + 1) * chunk_size]
            if not part:
                break
            req = urllib.request.Request(
                url,
                data=part,
                method="PUT",
                headers={
                    "Content-Type": "video/mp4",
                    "Content-Range": f"bytes {i*chunk_size}-{i*chunk_size+len(part)-1}/{len(blob)}",
                    "Content-Length": str(len(part)),
                    "Expect": "100-continue",
                },
            )
            with urllib.request.urlopen(req, timeout=300) as r:  # noqa: S310 - upload URL is pre-signed, no auth header allowed
                if r.status >= 300:
                    raise TikTokError(f"chunk {i} upload failed: HTTP {r.status}")
            log.debug("tiktok chunk %s/%s sent", i + 1, total_chunks)

    def await_status(self, publish_id: str, tok: str, timeout: int = 240) -> str:
        deadline = time.time() + timeout
        status = "PROCESSING_UPLOAD"
        while time.time() < deadline:
            d = _call("/post/publish/status/fetch/", {"publish_id": publish_id}, tok)
            status = d.get("status") or "UNKNOWN"
            if status in ("PUBLISH_COMPLETE", "FAILED", "SEND_FAILED"):
                return status
            time.sleep(5)
        return "TIMEOUT_" + status
