"""
STAGE 4b - Instagram Reels via the Instagram Platform (Graph API).

Hard constraints that break naive automations (all verified against Meta docs +
live API behaviour, 2026):
  * Reels-tab eligibility: 9:16, 5-90 s, H.264/HEVC, AAC <=48 kHz, <=100 MB,
    progressive scan, closed GOP, and the **moov atom must be at the front**
    (that's why render.py writes -movflags +faststart).
  * Publishing is 3 calls: create container -> poll status_code -> publish.
    Video fetching/processing is async: polling can take 30-120 s and containers
    expire, so a worker that sleeps 600 s mid-job will double-post on restart.
    We persist the container id in the job payload to make it resumable.
  * Rate ceiling: Meta's own docs state both "100 API-published posts / 24h" and
    "50 published posts / 24h" for different flows. Do NOT hardcode it: query
    `content_publishing_limit` and stop when remaining <= 1.
  * No file upload: `video_url` must be publicly reachable by Meta's fetchers.
  * Caption limit 2200 chars; `ig_media_fallback` lets you set the caption at
    publish time if the container creation ignored it.
"""
from __future__ import annotations

import json
import time

from ..config import get_settings
from ..util import log, retry

API = "https://graph.facebook.com/v23.0"


class InstagramError(RuntimeError):
    def __init__(self, msg: str, code: int | None = None, subcode: int | None = None, retryable: bool = False):
        super().__init__(msg)
        self.code, self.subcode, self.retryable = code, subcode, retryable


def _post(url: str, data: dict) -> dict:
    import urllib.error
    import urllib.parse
    import urllib.request

    req = urllib.request.Request(url, data=urllib.parse.urlencode(data).encode(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=90) as r:  # noqa: S310
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")[:600]
        code = sub = None
        try:
            err = json.loads(raw).get("error", {})
            code, sub = err.get("code"), err.get("error_subcode")
        except json.JSONDecodeError:
            pass
        # 4/17/613/9 = throttle-ish (retry); 2207042 = 24h publish cap (terminal today)
        retryable = code in (4, 9, 17, 32, 341, 613) and sub != 2207042
        raise InstagramError(f"ig HTTP {e.code} code={code} sub={sub}: {raw}", code, sub, retryable) from e


def _get(url: str) -> dict:
    import urllib.request

    with urllib.request.urlopen(url, timeout=60) as r:  # noqa: S310
        return json.loads(r.read().decode() or "{}")


class Instagram:
    name = "instagram"

    def __init__(self) -> None:
        s = get_settings()
        if not (s.ig_user_id and s.ig_token):
            raise RuntimeError("IG_USER_ID / IG_ACCESS_TOKEN not set")
        self.uid, self.tok = s.ig_user_id, s.ig_token

    def headroom(self) -> dict:
        d = _get(f"{API}/{self.uid}/content_publishing_limit?access_token={self.tok}")
        for row in d.get("data", []):
            lim = row.get("config", {}).get("limit")
            used = row.get("usage", {}).get("count")
            if lim:
                return {"limit": int(lim), "used": int(used or 0), "remaining": int(lim) - int(used or 0)}
        return {"limit": None, "used": None, "remaining": None}

    @retry(times=2, base_delay=6)
    def publish(self, meta: dict, video_url: str, container_id: str | None = None, **_: object) -> dict:
        caption = ((meta.get("title") or "") + "\n\n" + (meta.get("description") or "") + "\n" + " ".join(meta.get("hashtags") or []))[:2200]
        cid = container_id
        if not cid:
            r = _post(
                f"{API}/{self.uid}/media?access_token={self.tok}",
                {
                    "media_type": "REELS",
                    "video_url": video_url,
                    "caption": caption,
                    "share_to_feed": "true",
                    "ig_media_fallback": json.dumps({"caption": caption, "mentioned_users": []}),
                },
            )
            cid = r.get("id")
            if not cid:
                raise InstagramError(f"no container id: {r}")
            log.info("ig container %s created", cid)
        deadline = time.time() + 240
        status = "IN_PROGRESS"
        while time.time() < deadline:
            st = _get(f"{API}/{cid}?fields=status_code&access_token={self.tok}")
            status = st.get("status_code") or "UNKNOWN"
            if status in ("FINISHED", "ERROR", "EXPIRED"):
                break
            time.sleep(5)
        if status != "FINISHED":
            raise InstagramError(f"container {cid} ended in {status}", retryable=status == "IN_PROGRESS")
        pub = _post(f"{API}/{self.uid}/media_publish?access_token={self.tok}", {"creation_id": cid})
        media_id = pub.get("id")
        permalink = ""
        if media_id:
            try:
                permalink = _get(f"{API}/{media_id}?fields=permalink&access_token={self.tok}").get("permalink", "")
            except Exception:  # noqa: BLE001 - permalink is best-effort
                pass
        log.info("ig published media_id=%s", media_id)
        return {"provider": "instagram", "id": media_id, "url": permalink or f"https://instagram.com/reel/{media_id}", "container_id": cid}
