"""
STAGE 4d - one-call wrappers for the "skip app review" vendors, plus a mock
provider so the publish stage is testable end-to-end with zero credentials.

Why these exist: TikTok/IG/YT each want their own OAuth app, review process, token
refresh and chunk-upload protocol. For a solo creator the honest cost comparison is
usually *not* "free API vs paid tool" - it is "3 weekends of app review and token
plumbing vs $20-30/mo". Both paths are in this repo so you can start on the
direct APIs and switch providers by editing one env var.
"""
from __future__ import annotations

from ..config import get_settings
from ..util import log, retry


class Postiz:
    """Self-hostable open-source scheduler (AGPL, free to run yourself) - the
    cheapest 'everything but YouTube/TikTok is already handled' option."""

    name = "postiz"

    def __init__(self) -> None:
        s = get_settings()
        if not s.postiz_key:
            raise RuntimeError("POSTIZ_API_KEY not set")
        self.base = s.postiz_base_url.rstrip("/")
        self.key = s.postiz_key
        self.integrations = [i for i in s.platforms.split(",") if i not in ("youtube", "instagram", "tiktok", "mock")] or ["all"]

    @retry(times=2, base_delay=4)
    def publish(self, meta: dict, video: str, **kw: object) -> dict:
        video_url = str(kw.get('media_url') or video)
        import json
        import urllib.request

        ids = __import__("os").environ.get("POSTIZ_INTEGRATION_IDS", "")
        payload = {
            "type": "draft" if meta.get("publish_at") else "schedule",
            "date": meta.get("publish_at") or "now",
            "content": [
                {
                    "value": (meta.get("title") or "") + "\n\n" + " ".join(meta.get("hashtags") or []),
                    "links": [{"image": video_url, "name": "video"}],
                }
            ],
            "changeMarks": "false",
            "postTo": [{"id": i, "name": "auto"} for i in ([x for x in ids.split(",") if x] or self.integrations)],
            "settings": {"authorUpdate": "TRUE", "shortURL": False},
        }
        req = urllib.request.Request(
            f"{self.base}/public/v1/posts",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {self.key}", "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=60) as r:  # noqa: S310
            data = json.loads(r.read().decode() or "{}")
        pid = (data.get("data") or {}).get("id") or data.get("id")
        log.info("postiz post %s queued", pid)
        return {"provider": "postiz", "id": pid, "url": "", "queued": True}


class UploadPost:
    """API-first publisher (has an official n8n node). Video + 20+ platforms,
    handles the IG/TikTok upload plumbing and returns per-platform status."""

    name = "uploadpost"

    @retry(times=2, base_delay=4)
    def publish(self, meta: dict, video: str, **kw: object) -> dict:
        video_url = str(kw.get("media_url") or video)
        import json
        import os
        import urllib.request

        s = get_settings()
        payload = {
            "platforms": [p for p in s.platforms.split(",") if p in ("tiktok", "instagram", "youtube", "threads", "x")],
            "videoUrl": video_url,
            "tiktok_title": (meta.get("hook") or meta.get("title") or "")[:2200],
            "tiktok_privacy_level": meta.get("privacy", "PUBLIC_TO_EVERYONE"),
            "postNow": not bool(meta.get("publish_at")),
            "scheduleDate": meta.get("publish_at") or "",
            "state": os.environ.get("UPLOADPOST_STATE", "acp"),
        }
        headers = {"X-API-KEY": s.uploadpost_key, "Content-Type": "application/json"}
        if payload["state"]:
            headers["X-UPLOAD-POST-STATE"] = payload["state"]
        req = urllib.request.Request("https://api.upload-post.com/api/uploadpost", data=json.dumps(payload).encode(), headers=headers)
        with urllib.request.urlopen(req, timeout=90) as r:  # noqa: S310
            data = json.loads(r.read().decode() or "{}")
        if not data.get("success", True):
            raise RuntimeError(f"upload-post error: {json.dumps(data)[:300]}")
        return {"provider": "uploadpost", "id": data.get("jobid", ""), "url": "", "queued": True}


class MockPublisher:
    """Writes a receipt into the job record. Used by `acp publish --dry-run` and the
    test suite so the queue/limits/failure paths get exercised without any platform."""

    name = "mock"

    def __init__(self, endpoint: str = "") -> None:
        self.endpoint = endpoint or get_settings().public_base_url + "/mock/publish" if get_settings().public_base_url else ""

    def publish(self, meta: dict, video: str, **kw: object) -> dict:
        import hashlib
        import time

        src = str(kw.get("media_url") or video)
        rid = hashlib.sha1(f"{src}{time.time()}".encode()).hexdigest()[:12]
        size = __import__("os").path.getsize(video) if __import__("os").path.exists(video) else 0
        log.info("[mock] publish accepted: %s (%s bytes)", src[:70], size)
        return {"provider": "mock", "id": f"mock-{rid}", "url": f"https://example.com/mock/{rid}", "queued": True, "fake": True, "payload_bytes": size}


REGISTRY = {
    "youtube": "acp.publishers.youtube.YouTube",
    "instagram": "acp.publishers.instagram.Instagram",
    "tiktok": "acp.publishers.tiktok.TikTok",
    "postiz": "acp.publishers.postiz.Postiz",
    "uploadpost": "acp.publishers.uploadpost.UploadPost",
    "mock": "acp.publishers.MockPublisher",
}


def build(platform: str):
    """Instantiate a publisher by name. 'youtube:mock' style ids are ignored on purpose."""
    import importlib

    dotted = REGISTRY.get(platform)
    if not dotted:
        raise KeyError(f"unknown platform '{platform}'. options: {', '.join(REGISTRY)}")
    mod, cls = dotted.rsplit(".", 1)
    return getattr(importlib.import_module(mod), cls)()
