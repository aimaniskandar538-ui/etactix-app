"""Tests for the parts of the pipeline that must be exactly right.

These are not decorative: caption timing is the #1 source of "the video feels off"
complaints, the render QC numbers decide whether Instagram accepts the file, and
the publish scheduler is what stops you getting rate-limited or double-posting.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from acp.config import get_settings  # noqa: E402
from acp.stages import script as stage2  # noqa: E402
from acp.stages import subs  # noqa: E402
from acp.stages.render import plan_clips  # noqa: E402
from acp.stages.speech import chunk_sentences  # noqa: E402


@pytest.fixture()
def s():
    return get_settings()


# ------------------------------------------------------------- caption chunking
def test_chunks_respect_char_budget(s):
    sentences = [
        "The Federal Reserve just moved a number that most people will never see in a headline, and it changes what your mortgage costs.",
        "Two seconds decide everything.",
        "Follow for part two.",
    ]
    chunks = chunk_sentences(sentences, s.max_cps)
    assert chunks, "chunking must never return nothing"
    assert all(len(c) <= s.max_cps + 12 for c in chunks), [len(c) for c in chunks]
    assert all(len(c.split()) <= 11 for c in chunks)


def test_no_caption_is_a_single_word(s):
    chunks = chunk_sentences(["Alpha beta gamma.", "Delta."], s.max_cps)
    assert not any(len(c.split()) == 1 for c in chunks) or len(chunks) == 1


# --------------------------------------------------------------- script cleanup
def test_script_clean_enforces_duration_and_hook(s):
    payload = {
        "hook_variants": ["Stop scrolling, the maths changed."],
        "hook": "Stop scrolling, the maths changed.",
        "script_sentences": ["Filler sentence number " + str(i) + " which is fairly long so we can test trimming behaviour here." for i in range(40)],
        "keywords": ["office desk"],
        "title": "t",
        "description": "d",
    }
    out = stage2._clean(payload, "Test topic", s.max_cps, s.target_seconds)
    assert out["estimated_seconds"] <= s.target_seconds * 1.35
    assert out["script_sentences"][0].lower().startswith("stop scrolling")
    assert out["keywords"] == ["office desk"]
    assert "#shorts" in out["hashtags"]


def test_validate_rejects_thin_script():
    ok, problems = stage2.validate({"script_sentences": ["one"], "keywords": [], "title": "x"})
    assert not ok and any("thin" in p for p in problems) and any("footage keywords" in p for p in problems)


def test_validate_rejects_banned_opener():
    ok, problems = stage2.validate(
        {"script_sentences": [f"s{i}" for i in range(6)], "keywords": ["cats"], "title": "x", "hook": "Did you know cats purr?"}
    )
    assert not ok and any("banned opener" in p for p in problems)


# ------------------------------------------------------------------ caption files
def test_ass_has_karaoke_and_safe_margins(s, tmp_path):
    caps = [
        {"start": 0.0, "end": 2.0, "text": "Stop scrolling now", "words": [["Stop", 0.0, 0.5], ["scrolling", 0.5, 1.2], ["now", 1.2, 2.0]]},
        {"start": 2.2, "end": 4.0, "text": "no words here", "words": []},
    ]
    ass = subs.build_ass(caps, [{"start": 0, "text": "THE DATA"}], karaoke=True)
    assert "\\kf" in ass and "Dialogue: 0" in ass
    assert f"PlayResX: {s.video_w}" in ass
    style = [ln for ln in ass.splitlines() if ln.startswith("Style: Main")][0]
    marginv = int(style.split(",")[21])  # MarginV: bottom margin in canvas units
    assert 0 < marginv < s.video_h * 0.30, "captions must clear the app UI without drifting off-canvas"


def test_vtt_roundtrip(s, tmp_path):
    caps = [{"start": 0.0, "end": 1.5, "text": "One two three"}]
    (tmp_path / "captions.json").write_text(json.dumps(caps))
    res = subs.write_files(tmp_path, caps)
    vtt = Path(res["vtt"]).read_text()
    assert vtt.startswith("WEBVTT") and "00:00:00.000 --> 00:00:01.500" in vtt
    assert "captions.ass" in Path(res["ass"]).name


def test_ass_escapes_braces(s):
    ass = subs.build_ass([{"start": 0, "end": 1, "text": "cost {a} $5", "words": []}])
    assert "{" not in ass.split("Dialogue")[-1].replace("{\\an2\\b1}", "")


# -------------------------------------------------------------------- clip plan
def test_clip_plan_covers_exactly_the_narration(s):
    assets = {"clip_meta": [{"path": "/tmp/a.mp4", "probe": {"duration": 8}}, {"path": "/tmp/b.mp4", "probe": {"duration": 30}}]}
    parts = plan_clips(assets, total=24.0, s=s)
    assert len(parts) == 2
    assert abs(sum(p["dur"] for p in parts) - 24.0) < 1e-6
    assert parts[0]["needs_loop"] is False and parts[1]["needs_loop"] is False


def test_clip_plan_flags_looping(s):
    assets = {"clip_meta": [{"path": "/tmp/short.mp4", "probe": {"duration": 2.0}}]}
    parts = plan_clips(assets, 20.0, s)
    assert parts[0]["needs_loop"]


def test_render_filters_shape(s, tmp_path):
    from acp.stages.render import build_audio_filter, build_video_filter

    parts = [{"src": "/tmp/a.mp4", "dur": 10.0, "avail": 30.0, "needs_loop": False}] * 3
    ass = tmp_path / "c.ass"
    ass.write_text("[Events]\n")
    vf = build_video_filter(parts, s, str(ass))
    assert vf.count("[v") >= 4 and "concat=n=3:v=1:a=0" in vf and "subtitles=filename=" in vf
    assert "yuv420p" in vf and "setsar=1" in vf
    af, mixed = build_audio_filter(3, s, True, "/tmp/bgm.mp3", 30.0)
    assert mixed and "amix=inputs=2" in af and "[3:a]" in af and "[4:a]" in af


# ------------------------------------------------------------------- db/queue
# ------------------------------------------------------------- caption layout
def test_width_aware_chunk_budget(s):
    """Chunks must fit the canvas at the caption font size or libass wraps them badly."""
    from acp.stages.speech import effective_cps

    wide = effective_cps(80, 1080, 86)
    narrow = effective_cps(80, 320, 86)
    assert narrow < wide
    assert 14 <= wide <= 80


def test_wrap_lines_caps_at_two_balanced_lines(s):
    from acp.stages.subs import per_line_chars, wrap_lines

    pieces = ["{%skf10%sko0}word%02d" % (chr(92), chr(92), i) for i in range(6)]
    lines = wrap_lines(pieces, per_line_chars(s))
    assert len(lines) <= 2
    assert len(lines[0]) - len(lines[-1]) <= per_line_chars(s), "lines must be balanced, no one-word orphan"


def test_ass_uses_at_most_two_physical_lines(s):
    caps = [
        {
            "start": 0,
            "end": 2,
            "text": "one two three four five six",
            "words": [[w, i * 0.3, i * 0.3 + 0.28] for i, w in enumerate("one two three four five six".split())],
        }
    ]
    ass = [ln for ln in subs.build_ass(caps, None, True).splitlines() if ln.startswith("Dialogue")][0]
    assert ass.count("\\N") <= 1, f"caption became a multi-line tower: {ass[-160:]}"


# ------------------------------------------------------------------------ CLI menu
def test_menu_picker_is_safe_without_a_tty(monkeypatch, capsys):
    """No TTY (cron, CI, docker exec) must mean "do not ask", never a hang on stdin."""
    import argparse

    from acp import cli

    monkeypatch.setattr(cli, "_is_tty", lambda: False)
    assert cli.choose([("status", ["status"])]) == -1
    assert cli.cmd_menu(argparse.Namespace(loop_menu=False)) == 0
    assert "ACP - autonomous content pipeline" in capsys.readouterr().out


def test_menu_accepts_number_and_prefix(monkeypatch):
    import argparse  # noqa: F401  (keeps the namespace import honest if the picker grows)

    from acp import cli

    monkeypatch.setattr(cli, "_is_tty", lambda: True)
    monkeypatch.setattr("builtins.input", lambda *a: "3")
    assert cli.choose([("a", []), ("b", []), ("c", [])]) == 2
    monkeypatch.setattr("builtins.input", lambda *a: "pub")
    assert cli.choose([("publish", []), ("publish-queue", [])]) == -2  # ambiguous, no guess
    monkeypatch.setattr("builtins.input", lambda *a: "selftest")
    assert cli.choose([("publish", []), ("selftest", [])]) == 1
    monkeypatch.setattr("builtins.input", lambda *a: "99")
    assert cli.choose([("only", [])]) == -2


def test_publish_queue_skips_confirmation_when_not_a_tty(tmp_path, monkeypatch, capsys):
    """`publish-queue` must never block on stdin in CI (non-TTY bypasses the prompt, and
    -y does too); with a TTY and no -y it must ask, and "no" must not publish.
    Uses a real throwaway DB + a real (mock) publisher, not a stub, so the whole path runs."""
    import argparse

    from acp import cli, config

    work = tmp_path / "work"
    work.mkdir()
    monkeypatch.setenv("WORK_DIR", str(work))
    monkeypatch.setenv("PLATFORMS", "mock")
    monkeypatch.setenv("PUBLIC_BASE_URL", "http://127.0.0.1:1")
    monkeypatch.setenv("MIN_GAP_MINUTES", "0")   # else the 2nd job is held by spacing, not by us
    config._settings = None
    try:
        from acp.orchestrate import Pipeline

        p = Pipeline()
        jid = p.db.create_job(idea="queue test")
        video = tmp_path / "v.mp4"
        video.write_bytes(b"x" * 2048)
        p.db.update(jid, "approved", approved=1)
        p.db.patch_payload(jid, render={"video": str(video), "duration": 20})

        monkeypatch.setattr(cli, "_is_tty", lambda: False)
        assert cli.cmd_publish_queue(argparse.Namespace(limit=1, yes=False, platforms="mock")) == 0
        out = capsys.readouterr().out
        assert "cancelled" not in out and "mock" in out.lower()
        assert Pipeline().db.get(jid)["state"] == "published"

        config._settings = None
        p2 = Pipeline()
        jid2 = p2.db.create_job(idea="queue test 2")
        p2.db.update(jid2, "approved", approved=1)
        p2.db.patch_payload(jid2, render={"video": str(video), "duration": 20})
        monkeypatch.setattr(cli, "_is_tty", lambda: True)
        monkeypatch.setattr("builtins.input", lambda *a: "n")
        rc = cli.cmd_publish_queue(argparse.Namespace(limit=1, yes=False, platforms="mock"))
        capsys.readouterr()
        assert rc == 1, "refused publish must exit non-zero so cron/CI notices"
        assert Pipeline().db.get(jid2)["state"] == "approved", "a refusal must not change the job"
    finally:
        config._settings = None


# ------------------------------------------------------------------ .env parsing
def test_dotenv_strips_inline_comments_and_empty_values(tmp_path):
    """The shipped .env.example documents values inline; a loader that keeps the comment
    turns PUBLISH_WINDOWS into garbage and `ACP_CONTROL_TOKEN=` into an unpassable API."""
    from acp import config

    env = tmp_path / ".env"
    env.write_text(
        "PUBLISH_WINDOWS=9-22   # local hours you allow publishing (optional)\n"
        "ACP_CONTROL_TOKEN=           # set this before exposing the API\n"
        'QUOTED="hello # not a comment"\n'
        "MIN_GAP_MINUTES=90           # spacing\n"
        "# full line comment\n"
        "NOISE=nonsense-value         # not numeric\n"
    )
    config.load_dotenv(env)
    assert os.environ["PUBLISH_WINDOWS"] == "9-22"
    assert os.environ["MIN_GAP_MINUTES"] == "90"
    assert os.environ["QUOTED"] == "hello # not a comment"
    assert "ACP_CONTROL_TOKEN" not in os.environ  # empty means unset
    assert config._i("MIN_GAP_MINUTES", 7) == 90
    assert config._i("NOISE", 7) == 7, "a non-numeric value must fall back, not raise"
    for k in list(os.environ):
        if k in ("PUBLISH_WINDOWS", "QUOTED", "MIN_GAP_MINUTES", "NOISE"):
            os.environ.pop(k, None)


def test_long_trend_context_does_not_break_stage2(tmp_path, monkeypatch):
    """`jobs.json` is a text column, not a path. A context blob longer than NAME_MAX used to
    raise OSError ENAMETOOLONG ('File name too long') inside stage 2, and shorter ones were
    silently dropped so the LLM never saw the headlines."""
    from acp.orchestrate import Pipeline

    work = tmp_path / "work"; work.mkdir()
    monkeypatch.setenv("WORK_DIR", str(work)); monkeypatch.setenv("LLM_PROVIDER", "echo")
    monkeypatch.setenv("ASSET_PROVIDER", "mock"); monkeypatch.setenv("TTS_PROVIDER", "silent")
    from acp import config; config._settings = None
    try:
        p = Pipeline()
        big = {"traffic": "2000+", "news_headlines": ["headline " + str(i) for i in range(40)]}
        import json as _json
        jid = p.db.create_job(idea="brewers score", source="google_trends",
                              score=100, json=_json.dumps(big))
        assert len(_json.dumps(big)) > 255, "fixture must exceed NAME_MAX to reproduce the bug"
        p.stage_script(jid)                      # the call that used to raise
        ctx = p.db.payload(jid)
        assert "script" in ctx, f"stage2 payload missing: {list(ctx)}"
    finally:
        config._settings = None


def test_state_machine_claim_is_exclusive(tmp_path):
    from acp.db import Store

    st = Store(tmp_path / "t.db")
    jid = st.create_job(idea="x")
    assert st.claim(jid, "new", "new:wip") is True
    assert st.claim(jid, "new", "new:wip") is False  # second worker must lose the race
    st.update(jid, "scripted")
    assert st.get(jid)["state"] == "scripted"


def test_dedupe_window(tmp_path):
    from acp.db import Store

    st = Store(tmp_path / "t.db")
    st.remember("abc")
    assert st.seen("abc", 30) is True
    assert st.seen("other", 30) is False


def test_publish_hold_parks_job(tmp_path, monkeypatch):
    monkeypatch.setenv("PLATFORM_DAILY_CAPS", "mock:1")
    from acp import config

    config._settings = None
    from acp.db import Store

    st = Store(tmp_path / "t.db")
    st.quota_spend("mock")
    assert st.quota_used(json.dumps(1)[0:1] and __import__("time").strftime("%Y-%m-%d"), "mock") == 1
    from acp.orchestrate import Pipeline

    p = Pipeline()
    p.db = st
    ok, why = p.platform_slot("mock")
    assert not ok and "cap" in why
    config._settings = None


def test_render_qc_flags_big_and_wide(s, tmp_path, monkeypatch):
    """QC must fail loudly on files Instagram/TikTok will reject."""
    qc = {"size_mb": 140, "aspect": 1.77, "duration": 5.0, "seconds_off": 2.0}
    assert qc["size_mb"] > 95 and abs(qc["aspect"] - 9 / 16) > 0.02


# ------------------------------------------------------------- offline provider
def test_echo_provider_produces_valid_script(s, monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "echo")
    from acp import config

    config._settings = None
    out = stage2.generate("Local elections change the housing numbers")
    good, problems = stage2.validate(out)
    assert good, problems
    assert out["script_sentences"] and out["keywords"]
    config._settings = None
