"""
Verifies the HTTP control plane that n8n/Make drive, and the publishable() quota
filter, against a real job with real rendered artefacts. Run after scripts/smoke.sh.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import pathlib
import threading
import time
import urllib.request
from pathlib import Path


def _media_head(url: str) -> int:
    try:
        with urllib.request.urlopen(url, timeout=20) as r:  # noqa: S310
            return r.status
    except Exception as e:  # noqa: BLE001
        print("      media fetch error:", type(e).__name__, str(e)[:80])
        return -1

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("LLM_PROVIDER", "echo")
os.environ.setdefault("ASSET_PROVIDER", "mock")
os.environ.setdefault("TTS_PROVIDER", "silent")
os.environ.setdefault("VIDEO_W", "540")
os.environ.setdefault("VIDEO_H", "960")
os.environ.setdefault("X264_PRESET", "ultrafast")
os.environ.setdefault("REQUIRE_APPROVAL", "true")
os.environ.setdefault("PLATFORMS", "mock")
# Hermetic: a private work dir + DB, so repeated runs never inherit yesterday's quota
# counters or another run's jobs (that made this suite flaky in exactly the confusing way
# a production queue would be: "the platform said no" when nothing said no).
SCRATCH = Path(f"/tmp/acp-api-smoke-{os.getpid()}")
os.environ["WORK_DIR"] = str(SCRATCH)
os.environ.setdefault("PUBLIC_BASE_URL", "")          # exercise the local-serve branch
os.environ["MEDIA_DIR"] = str(SCRATCH / "public")
os.environ.setdefault("PLATFORM_DAILY_CAPS", "mock:20")
os.environ.setdefault("PYTHONPATH", str(ROOT))


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockport() if False else s.getsockname()[1]


PORT = free_port()
os.environ["PUBLIC_BASE_URL"] = f"http://127.0.0.1:{PORT}"   # exercise the self-served /media/ path


def req(method: str, path: str, body: dict | None = None, port: int = PORT) -> tuple[int, dict]:
    import urllib.error

    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, method=method,
                               headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(r, timeout=300) as resp:  # noqa: S310
            raw = resp.read().decode()
            return resp.status, (json.loads(raw) if raw.startswith(("{", "[")) else {"raw": raw[:200]})
    except urllib.error.HTTPError as e:
        body = e.read().decode()[:300]
        try:
            return e.code, json.loads(body)
        except json.JSONDecodeError:
            return e.code, {"raw": body}


def main() -> int:
    from acp.api import Handler
    from acp.config import get_settings
    from http.server import ThreadingHTTPServer

    httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    time.sleep(0.4)
    s = get_settings()
    ok = True

    def check(label: str, cond: bool, detail: str = ""):
        nonlocal ok
        print(f"  [{'PASS' if cond else 'FAIL'}] {label} {detail}")
        ok = ok and bool(cond)

    code, health = req("GET", "/health")
    check("GET /health", code == 200 and health.get("ok") is True, str(health))

    code, r = req("POST", "/jobs", {"idea": "Why the API needs a control plane", "run": False})
    jid = r.get("job_id")
    check("POST /jobs (create only)", code == 200 and jid, f"job {jid}")

    code, r = req("POST", f"/jobs/{jid}/run", {"until": "rendered"})
    state = (r.get("job") or {}).get("state")
    check("POST /jobs/:id/run -> stages 2-3", code == 200 and state in ("awaiting_approval", "approved"), f"state={state}")

    code, awaiting = req("GET", "/awaiting")
    ids = [x["id"] for x in awaiting.get("awaiting", [])]
    check("GET /awaiting lists the job for the approval button", jid in ids, str(ids[:5]))

    code, r = req("POST", f"/jobs/{jid}/approve")
    check("POST /jobs/:id/approve", code == 200 and r["job"]["state"] == "approved", r["job"]["state"])

    code, r = req("GET", "/publishable")
    ready = [x["id"] for x in r.get("ready", [])]
    check("GET /publishable honours caps+spacing and returns the job", jid in ready, f"count={r.get('count')}")

    code, r = req("POST", f"/jobs/{jid}/publish", {"platforms": ["mock"], "dry_run": True})
    res = (r.get("results") or {}).get("mock") or {}
    check("POST /jobs/:id/publish --dry-run reaches the publisher", code == 200 and res.get("dry_run") is True, str(res)[:120])
    media = res.get("media_url") or ""
    check("media served from work/public for URL-based platforms", media.endswith(".mp4"), media)

    # real publish through the mock receiver endpoint
    code, r = req("POST", f"/jobs/{jid}/publish", {"platforms": ["mock"]})
    res = (r.get("results") or {}).get("mock") or {}
    check("POST /jobs/:id/publish (mock) -> published", r.get("job", {}).get("state") == "published", str(res)[:140])
    served = Path(s.media_dir)
    got = [f for f in served.rglob("final.mp4")]
    url = f"{s.public_base_url.rstrip('/')}/media/job_{jid:05d}/final.mp4"
    code2 = _media_head(url)
    check("rendered file is copied to MEDIA_DIR and is HTTP-fetchable", bool(got) and code2 in (200, 302),
          f"served={[str(g.relative_to(served)) for g in got]} http={code2}")

    # unknown platform must be recorded, not raised out of the HTTP handler
    code, r2 = req("POST", f"/jobs/{jid}/publish", {"platforms": ["nope"]})
    rec = json.dumps(r2.get("results", {}))
    check("unknown platform -> per-platform error, still HTTP 200", code == 200 and "nope" in rec, rec[:150])

    # second publish must be held by our own daily cap; restore the setting afterwards
    original_caps = s.platform_daily_caps
    try:
        s.platform_daily_caps = "mock:1"
        code, r = req("POST", f"/jobs/{jid}/publish", {"platforms": ["mock"]})
        held = ((r.get("results") or {}).get("mock") or {})
        check("cap enforcement re-queues instead of hammering the platform",
              bool(held.get("held") or r.get("job", {}).get("state") == "approved"), f"state={r.get('job',{}).get('state')}")
    finally:
        s.platform_daily_caps = original_caps

    code, st = req("GET", "/status")
    check("GET /status reports cost + states", st.get("today_cost_usd") is not None and "states" in st, json.dumps(st)[:130])

    code, body = req("GET", "/jobs/999999")
    check("unknown job id -> 404 (not 500)", code == 404, f"{code} {str(body)[:60]}")

    httpd.shutdown()
    import shutil

    shutil.rmtree(SCRATCH, ignore_errors=True)
    print("API SMOKE", "OK" if ok else "FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
