# ACP — Autonomous Content Pipeline for short-form video

Trend discovery → LLM script + visual prompts → stock-footage render with TTS and burned
captions → rate-limit-aware publishing to **YouTube Shorts / Instagram Reels / TikTok**.

This is a working reference implementation, not pseudocode. Everything below was executed in a
2 vCPU / 2 GB sandbox:

| Verified | Result |
|---|---|
| `python -m pytest tests -q` | **19 passed** (chunking, caption timing, ASS layout, clip planning, state machine, quota holds, dedupe) |
| `bash scripts/smoke.sh` end-to-end render (no accounts, no spend) | **11/11 QC checks pass**, final state `published` |
| 3 videos, 1080×1920, 3 clips each, live TTS | **40 s total (~13 s/video)**, ~120-200 videos/day on 2 vCPU |
| Live stage-1 discovery (real network) | Google Trends RSS 10 trends w/ traffic + headlines · Google News 100 items · HN 20 · Reddit 403→degrades to a warning |
| Live narration | `edge-tts` (free) → 7 caption chunks, timing drift **0.00 s**, **−14.1 LUFS** integrated (target −14) |
| `python tests/api_smoke.py` (the HTTP control plane n8n calls) | **14/14 pass**, incl. publish-hold + `404`/error handling |
| Caption burn-in | visually inspected rendered frames (karaoke fill, 2-line layout, safe-zone margins) |

```
docs/ARCHITECTURE.md        ← 4-stage technical spec, data contracts, per-platform limits
docs/BOTTLENECKS.md         ← 12 bottlenecks with mechanisms + working mitigations
n8n/*.json                  ← 3 importable workflows (generate / approve+publish / watchdog)
deploy/                     ← Dockerfile + compose + systemd + GitHub Actions guide
.github/workflows/*.yml     ← nightly test suite + the daily scheduled pipeline run
```

## 1b. Running it interactively

Just type `acp` with no arguments (or `acp menu`) and you get a dispatcher over the same code
the cron job uses, with the live queue/spend on the banner:

```
ACP - autonomous content pipeline
----------------------------------------
queue: awaiting_approval=2, published=6 | today: 8 jobs, $0.043/$2.00 | ready to publish: 2
  1) selftest  - deps, keys, ffmpeg capabilities
  2) trends    - stage 1: show today's ranked ideas
 ...
 14) serve     - run the HTTP control API for n8n/Make
what would you like to do>
```
Keys: number, `0` to quit, or an unambiguous prefix (`selftest`). It only asks when stdin is a
terminal — under cron, CI or `docker exec` it never blocks on a prompt (that is unit-tested,
because "menu hangs the 3am job" is the worst possible failure for a convenience feature).
`publish-queue` likewise confirms before posting to live accounts, and `-y` / a non-TTY skips it.
In a container: `docker compose run --rm acp-api menu`.

---

## 1. Fastest path to a video (5 minutes, $0, no accounts)

```bash
git init . 2>/dev/null; cp .env.example .env        # nothing to fill in yet
export PATH="$PWD/.venv/bin:$PATH"
bash scripts/setup.sh                               # ffmpeg + venv + Anton font + noise-bed BGM
bash scripts/smoke.sh                               # stages 1-4 offline, prints QC verdicts
```
Then, still with zero keys, on your own machine (real footage needs a Pexels/Pixabay key):

```bash
make run  ENVD="LLM_PROVIDER=echo ASSET_PROVIDER=local TTS_PROVIDER=edge"   # your clips in assets/local_clips/
```

## 2. Real setup (one solo creator, ~$0-35/month)

```bash
nano .env       # LLM_API_KEY, PEXELS_API_KEY, PLATFORMS, NICHE …
make setup      # or: bash scripts/setup.sh (installs ffmpeg, venv, Anton font, placeholder BGM)
python -m acp.cli selftest            # prints exactly what's still missing
python -m acp.cli trends -n 8         # stage 1 only; --persist creates jobs
python -m acp.cli run --limit 2       # stages 2-3 → work/job_000NN/final.mp4
python -m acp.cli jobs --state awaiting_approval
python -m acp.cli approve 1 && python -m acp.cli publish 1 --dry-run   # then without --dry-run
python -m acp.cli status              # queue + today's cost + per-platform headroom
```

Recommended order of adoption (each step is independently useful):
1. **Render only, no publishing** — run it daily for a week, watch retention on 3-5 manually
   posted videos before automating anything.
2. **YouTube only.** No app review, free, 100 uploads/day, and `publishAt` gives you native
   scheduling for free.
3. **Instagram via `video_url` + Cloudflare Tunnel** (no app review needed if you own the account;
   you do need a Business account + a Meta app with `instagram_content`).
4. **TikTok last.** The Content Posting API wants a manual audit; if you would rather not wait,
   route it through an aggregator and keep everything else direct.
5. **Then n8n** (`n8n/*.json`) to add scheduling, approval buttons and the watchdog.

## 3. The stack (solo creator, reliability-per-dollar view)

| Stage | Pick | Why / cost |
|---|---|---|
| 1 Trends | Google Trends RSS + Google News RSS + Wikipedia Current Events | Free, no keys, no review. pytrends/Apify/DataForSEO only if you need multi-week curves (pytrends breaks every few months — never depend on it). |
| 1 Niche feed | Competitor YouTube channel Atom feeds | The best free "what's working right now" signal there is. |
| 2 LLM | `gpt-4o-mini` (or Groq/Llama-3.3-70B/OpenRouter) | ~$0.001-0.002/video. Quality is a prompt-discipline problem, not a model-size problem. |
| 3a Footage | **your own clips** first, then Pexels / Pixabay | Pexels 20k req/mo, Pixabay 100 req/60 s, both free. `CLIPS_PER_VIDEO=1` keeps it at 1 call + ~3 MB. |
| 3b TTS | `edge-tts` to start → **Azure F0** to scale | Edge is free but unofficial (breaks occasionally; grey for commercial). Azure F0 = **500k chars/mo free ≈ 500 videos**, returns real `WordBoundary` timings, $16/1M after. OpenAI `gpt-4o-mini-tts` ≈$15/1M. ElevenLabs $5/mo if you want cloning. |
| 3c Captions | own ASS writer (this repo) | Whisper not required — see ARCHITECTURE.md §3b. Saves a 3 GB model and GPU time per video. |
| 3d Render | **plain ffmpeg**, container image optional | ~250 MB RAM vs 1.5-3 GB for MoviePy. `render.py` probes encoders and takes `h264_nvenc`/`videotoolbox` when present, else `libx264`. |
| 4 Publish | YouTube direct + **Postiz (self-hosted, AGPL, $0)** or Upload-Post ($24)/Blotato ($29)/Post Bridge ($9) for IG+TikTok | Ayrshare is $149/mo — enterprise support, not solo economics. |
| Orchestration | n8n self-hosted Community Edition on a $5 VPS | Unlimited executions vs $24/mo for 2,500 on n8n Cloud. cron+systemd is genuinely enough at 3 videos/day. |
| Media host | Cloudflare R2 (10 GB free, **free egress**) or `acp serve` + cloudflared | IG/TikTok fetch by URL; R2 presign needs no tunnel. |
| State/queue | SQLite in WAL + this repo's `jobs` table | One file, survives reboot, `sqlite3` to debug. Redis/Celery is for >50 videos/day. |

**Monthly maths, 60 videos (2/day):** LLM $0.06 · TTS $0 (Azure F0) or $0.90 (OpenAI) · VPS $5-10 ·
Tunnel $0 · R2 ~$0.20 · Aggregator $0-29 → **$6-40/month**, of which the only non-optional paid line
is the VPS (and it is optional if you render on your own machine).

## 4. Repo map

```
acp/
  config.py            one dataclass, .env-parsed by hand — no pydantic needed to run this
  db.py                jobs / events / seen / usage  (state machine + queue + dedupe + quota)
  llm.py               OpenAI-compatible + Anthropic + `echo` (offline) with token costs
  orchestrate.py       Pipeline: stages, claim(), budget guard, publishable() quota filter
  api.py               stdlib HTTP control plane (what n8n calls) + /media/ file server
  cli.py               selftest trends new run status jobs log inspect approve publish retry auth serve clean
  stages/
    discovery.py       6 free sources, scoring, dedupe
    script.py          the JSON contract + duration budget + validate() gate
    assets.py          pexels|pixabay|coverr|local|mock, byte-capped, content-addressed cache
    speech.py          per-chunk TTS + ffprobe timing + readability re-split  (no ASR)
    subs.py            ASS (karaoke, 2-line, safe zones, emphasis words) + VTT
    render.py          ffmpeg filter_complex, 2-pass loudnorm, QC gate
  publishers/
    youtube.py         OAuth refresh + resumable upload  +  public_url()/R2 presign
  ci/
    summarise.py       the Actions step summary (never fails a run)
    healthcheck.py     container HEALTHCHECK, no-ops for roles that serve no HTTP
    instagram.py       container→poll→publish, headroom probe, terminal-vs-retryable errors
    tiktok.py          creator_info, FILE_UPLOAD chunks or PULL_FROM_URL, 200-error handling
    __init__.py        Postiz, Upload-Post, MockPublisher, build()
tests/test_pipeline.py 19 unit tests (the timing/layout/quota invariants)
tests/api_smoke.py     14 checks against a live HTTP server
scripts/setup.sh       boxes it in: ffmpeg, venv, font, placeholder BGM
scripts/smoke.sh       offline end-to-end + QC verdicts  ← run this first
docs/                  ARCHITECTURE.md, BOTTLENECKS.md
n8n/ deploy/           workflows, systemd units, Dockerfile, compose
```

## 5. What each stage guarantees (and what it deliberately refuses to do)

- **Discovery** refuses to fail because a source died; refuses to repeat an idea within 30 days; and
  does not pretend to predict virality — it ranks by recency × trust × niche overlap, which is
  auditable when a video flops.
- **Script** refuses to ship a >budget script, a banned opener, or a numeric claim that isn't in
  `claims_to_verify`. One LLM call per video; nothing else calls a model.
- **Render** refuses to trust a character-count timing estimate (it measures audio), refuses
  captions that can't be read in 3 s (re-splits and re-synthesises), refuses off-9:16 or >95 MB
  output *before* a platform does.
- **Publishing** refuses to exceed your own caps, refuses to retry a rolling-24 h cap (`2207042`,
  `reached_active_user_cap`), refuses to fire two posts inside `MIN_GAP_MINUTES`, and refuses to
  publish an unapproved video while `REQUIRE_APPROVAL=true`.

## 5b. Docker & GitHub Actions (both included)

```bash
cp .env.example .env && nano .env
make docker                      # = docker compose up --build -d acp-api acp-worker
docker compose run --rm acp-api smoke     # proves the image renders: no accounts, no spend
docker compose --profile n8n up -d n8n    # + the automation UI (import n8n/*.json)
docker compose --profile tunnel up -d     # + public URL so IG/TikTok can fetch the MP4
```
GPU host (5-10× faster encode per rendered second):
`make gpu-build && make docker-gpu`. Details, the healthcheck and the memory/cpus choices are in
`deploy/README.md`.

Daily, zero-server run on GitHub Actions: `gh secret set ACP_ENV_FILE --body "$(cat .env)"` then
push, and read **`deploy/github-actions.md`** first (cron is UTC, default-branch-only, state lives
on an orphan `state` branch, and public runners can't give Instagram a fetchable URL). Publish is
opt-in: the workflow posts nothing until you create a `PUBLISH` secret *and* check the box.

## 6. Operating it

```bash
# /etc/crontab — three lines and it runs itself
0  6,12,18,21 * * * creator cd /opt/acp && .venv/bin/python -m acp.cli run --limit 2      # stages 1-3
30 6,9,13,18,21 * * * creator cd /opt/acp && .venv/bin/python -m acp.cli publish-queue     # stage 4, quota-aware
12 3 * * 0        creator cd /opt/acp && .venv/bin/python -m acp.cli clean --keep-days 7   # disk hygiene
```
`deploy/acp-worker.timer` + `acp-api.service` do the same with `MemoryMax=1400M` and
`Nice=10`, so a runaway render dies in 2 s instead of freezing the box. `make test` / `make smoke`
/ `make publish` are the shortcuts.

**Watch these four numbers** (all in `/status`): `today_cost_usd` (retry storms), `states.failed`
(a key expired or an endpoint changed shape), `used_today` per platform (you are about to hit a
ceiling), and `seconds_off` in `qc.json` (a render drifting = your timing model broke).

## 7. Honest limits

- **Fully hands-off + factually wrong is how channels die.** That's why `awaiting_approval` is a
  state, `claims_to_verify` is surfaced, and `AUTO_PUBLISH` defaults to false. Automated *production*,
  human *judgement*, is the version that survives 6 months.
- **All three platforms demote mass-produced repetitive video** (YouTube's reused-content policy,
  TikTok's unoriginality rule). No amount of orchestration fixes a template everyone can copy.
  Own footage for the first 3 s, your own hook, specificity from a real source: that's the moat.
- **`edge-tts` is unofficial.** It works, it's free, and it can break or start requiring auth. Azure
  F0 is the drop-in escape hatch (`TTS_PROVIDER=azure`), and CI pings edge weekly.
- **TikTok app review is a calendar risk, not a code risk.** Ship YouTube+Reels first.
- **Stock licences are fine; stock music often is not.** Use the in-app sound picker on TikTok/IG or
  a paid library, or ship with no BGM (`BGM_FILE=`).
- Label AI content (`is_aigc` is wired into the TikTok publisher; add disclosure elsewhere) —
  it's increasingly required and it's cheap insurance.
