#!/usr/bin/env bash
# One-time setup for a solo creator on a fresh Linux box (Debian/Ubuntu/Fedora).
# Safe to re-run. Does NOT need sudo for the python/venv part.
set -uo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)

say() { printf "\n\033[1;36m== %s\033[0m\n" "$*"; }

say "1/6 system packages (needs sudo; skipped if unavailable)"
if command -v apt-get >/dev/null 2>&1; then
  (sudo -n apt-get update -qq && sudo -n apt-get install -y -qq ffmpeg fontconfig) \
    || echo "  ! could not apt-get install; if 'ffmpeg' is missing, install it manually"
elif command -v dnf >/dev/null 2>&1; then
  (sudo -n dnf install -y -q ffmpeg fontconfig) || echo "  ! install ffmpeg manually"
fi
command -v ffmpeg >/dev/null && echo "  ffmpeg: $(ffmpeg -version 2>/dev/null | head -1 | cut -c1-60)" || echo "  ffmpeg: MISSING -> render stage will fail"
command -v ffprobe >/dev/null && echo "  ffprobe: ok" || echo "  ffprobe: MISSING"

say "2/6 python venv"
if [ ! -d .venv ]; then
  python3 -m venv .venv && .venv/bin/pip -q install --upgrade pip
fi
.venv/bin/pip -q install -r requirements.txt && echo "  deps installed into $ROOT/.venv"

say "3/6 caption font (Anton is the genre standard for short-form)"
mkdir -p fonts
[ -f fonts/Anton-Regular.ttf ] || curl -sL --max-time 60 -o fonts/Anton-Regular.ttf \
  https://github.com/google/fonts/raw/main/ofl/anton/Anton-Regular.ttf
[ -f fonts/ArchivoBlack-Regular.ttf ] || curl -sL --max-time 60 -o fonts/ArchivoBlack-Regular.ttf \
  https://github.com/google/fonts/raw/main/ofl/archivoblack/ArchivoBlack-Regular.ttf
ls -la fonts/ | tail -3

say "4/6 free background music (CC0) - optional"
if [ ! -s assets/music/Silence.mp3 ] || [ "$(stat -c%s assets/music/Silence.mp3 2>/dev/null || echo 0)" -lt 40000 ]; then
  if command -v ffmpeg >/dev/null; then
    # A neutral 30s pad keeps the mix legal out of the box. Replace with real music you
    # have rights to (YouTube Audio Library is free for commercial use inside YT; for
    # TikTok/IG use their in-app sounds and let the platform match the audio).
    ffmpeg -v error -y -f lavfi -i "anoisesrc=colour=pink:amplitude=0.06:duration=30" -af "lowpass=f=900,volume=-14dB,afade=t=in:d=1.5,afade=t=out:st=28:d=2" -c:a libmp3lame -b:a 128k assets/music/Silence.mp3 && echo "  generated placeholder bed -> assets/music/Silence.mp3"
  fi
fi

say "5/6 env file"
[ -f .env ] || { cp .env.example .env && echo "  created .env (edit your keys in)"; } || echo "  .env already exists, left alone"

say "6/6 smoke test (no accounts, no money)"
.venv/bin/python -m acp.cli selftest
.venv/bin/python -m pytest tests -q 2>&1 | tail -3
echo
echo "Next:  nano .env   then   .venv/bin/python -m acp.cli trends -n 8"
