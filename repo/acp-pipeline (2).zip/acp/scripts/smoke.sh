#!/usr/bin/env bash
# Full end-to-end test with zero external accounts: echo "LLM", synthetic footage,
# real TTS if reachable, real render, mock publisher. This is what CI runs.
#
#   bash scripts/smoke.sh            # uses edge-tts if the network allows, else silent
#   TTS=silent bash scripts/smoke.sh # fully offline narration
set -uo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-python3}
export LLM_PROVIDER=echo ASSET_PROVIDER=mock TTS_PROVIDER=${TTS:-edge}
export VIDEO_W=${W:-540} VIDEO_H=${H:-960} FPS=${FPS:-30} X264_PRESET=ultrafast
export REQUIRE_APPROVAL=true AUTO_PUBLISH=false PLATFORMS=mock
export TARGET_SECONDS=${SECS:-18} DAILY_BUDGET_USD=99 PUBLIC_BASE_URL=http://localhost:8787
export PYTHONPATH=$(pwd)

echo "== config: ${VIDEO_W}x${VIDEO_H}@${FPS} tts=${TTS_PROVIDER} target=${TARGET_SECONDS}s =="
$PY -m acp.cli selftest | tail -4

rm -rf work && mkdir -p work
ID=$($PY -m acp.cli new --idea "Why the 3-second rule beats the 30-second rule" | grep -oE '^job [0-9]+' | head -1 | tr -dc '0-9')
[ -n "$ID" ] || { echo "could not create a job"; exit 1; }
JOBDIR=work/job_$(printf '%05d' "$ID")
echo "== job $ID: stages 2-3 =="
$PY -m acp.cli run --job "$ID" || { echo "FAILED"; exit 1; }

echo "== QC =="
$PY - "$ID" <<'EOF'
import json, sys, pathlib
from acp.config import get_settings
s = get_settings(); d = pathlib.Path(s.work_dir) / f"job_{int(sys.argv[1]):05d}"
qc = json.loads((d / "qc.json").read_text())
tim = json.loads((d / "timings.json").read_text())
caps = json.loads((d / "captions.json").read_text())
ok = True
def chk(name, cond, detail=""):
    global ok
    print(f"  [{'PASS' if cond else 'FAIL'}] {name} {detail}")
    ok = ok and bool(cond)
chk("resolution is 9:16", abs(qc["aspect"] - 9/16) < 0.02, f"{qc['width']}x{qc['height']}")
chk("duration matches narration within 0.75s", qc["seconds_off"] <= 0.75, f"{qc['duration']}s vs {qc['expected']}s")
chk("file size sane (0.5MB..95MB)", 0.5 < qc["size_mb"] < 95, f"{qc['size_mb']}MB")
chk("caption count matches narration chunks", len(caps) == tim["chunks"], f"{len(caps)} vs {tim['chunks']}")
chk("captions never overlap", all(b["start"] >= a["end"] - 0.05 for a, b in zip(caps, caps[1:])))
mx = max((c["end"]-c["start"]) for c in caps)
chk("no caption over 3.1s (would stall)", mx <= 3.1, f"max {mx:.2f}s")
chk("timings report the measured rate", tim.get("words_per_second_measured", 0) > 0, f"{tim.get('words_per_second_measured')} w/s")
chk("rendered video >= narration length", qc["duration"] + 0.2 >= tim["duration"], f"{qc['duration']}s vs {tim['duration']}s")
chk("word timings sum to caption span", all(abs(sum(w[2]-w[1] for w in c["words"]) - (c["end"]-c["start"])) < 0.35 for c in caps if c["words"]))
chk("ass file references the font dir", "fontsdir" in (d / "render_meta.json").read_text())
chk("qc raised no warnings", not qc["warnings"], str(qc["warnings"]))
sys.exit(0 if ok else 1)
EOF
QC=$?

echo "== stage 4 (mock publisher) =="
$PY -m acp.cli approve "$ID" >/dev/null
$PY -m acp.cli publish "$ID" --platforms mock | head -12
STATE=$($PY - "$ID" <<'EOF'
import sys; sys.path.insert(0,".")
from acp.config import get_settings; from acp.db import Store
print(Store(get_settings().db_path).get(int(sys.argv[1]))["state"])
EOF
)
echo "  final state: $STATE"
[ "$STATE" = "published" ] || { echo "FAIL: expected published"; exit 1; }
[ $QC -eq 0 ] || { echo "FAIL: QC"; exit 1; }
echo "SMOKE OK - one video produced with zero accounts and zero spend"
echo "== artefacts in $JOBDIR =="; ls -la "$JOBDIR" | awk 'NR>1{printf "  %-22s %8s\n", $9, $5}'; du -sh assets/cache 2>/dev/null
