# Running the pipeline from GitHub Actions

`.github/workflows/scheduled_run.yml` runs the whole pipeline daily: **restore state → install
ffmpeg → selftest → render smoke test → stages 1-3 → publish (opt-in) → push state → artifact
the MP4s**. It is deliberately conservative; read these five facts before you turn it on.

1. **Secrets.** One secret holds everything:
   `gh secret set ACP_ENV_FILE --body "$(cat .env)"`. The workflow refuses to run without it.
   Add `gh secret set PUBLISH --body 1` when you want it to post (manual runs also have a
   `publish` checkbox that defaults to *off*).
2. **Scheduling lives on the default branch only.** `schedule` uses the copy of the file on
   your default branch. Editing it on a feature branch changes nothing until you merge. The
   workflow also self-skips if `github.ref` is not the default branch, so a stray branch push
   cannot double-render.
3. **Cron is UTC and late.** `40 7 * * *` means roughly 07:40 UTC, sometimes 10-60 min later.
   It is not a precise timer; if timing matters (a live event), use your own server or n8n.
4. **State carries across runs via the orphan `state` branch** (`work/pipeline.db` + a capped
   footage cache; no MP4s, no `.env`). Without it, `DEDUP_DAYS`, the cost ledger and the
   per-platform counters reset to zero every run — which is how you end up re-posting
   yesterday's idea and blowing a daily cap you thought you still had.
5. **Public runners are datacenter IPs.** Reddit's JSON API 403s from them (the code degrades to
   a warning), Google Trends RSS and Google News work fine, and **Instagram/TikTok cannot fetch
   your MP4** unless you give them a public URL — which a CI box cannot offer. So on Actions,
   publish to YouTube only, or set `PUBLIC_BASE_URL`/R2 and expect R2 to be the one doing it.

### The runner choice is a real cost decision

| Runner | vCPU | Effect on this pipeline |
|---|---|---|
| `ubuntu-24.04` (x86) | 4 | ~10-15 s per 1080×1920 render, `-preset veryfast` |
| `ubuntu-24.04-arm` | 8 | ~30% cheaper minutes on public repos, same ffmpeg path |
| `macos-14` | 3 (M1) | `h264_videotoolbox` hardware encode: 5-10× faster, private repos cost 10× the multiplier |

`render.py` probes encoders at render time and picks `h264_nvenc → videotoolbox → amf/qsv/vaapi →
libx264`, so you get the hardware path where it exists without config. Set `FFMPEG_ENCODER` in
`.env` to pin one, and `acp selftest` prints `encoders_h264` so you can see what it found.

### Private-repo minute math (the trap)

2,000 free minutes/month on private repos, and macOS minutes count **10×**. Two pipeline runs a
day at ~2 min each on Linux ≈ 120 min/month — fine. Add `test_runners: true` and a macOS matrix
"for fun" and you will burn the quota in a weekend. Keep `tests` on Linux, run the matrix manually.

### Watch it, don't trust it

```bash
gh run list --workflow="scheduled run" --limit 5
gh api repos/$GITHUB_REPOSITORY/actions/workflows --jq '.workflows[]|select(.name=="scheduled run")|{name,state,path}'
# state must be "active". "paused" = 60 days of silence on a private repo (the keepalive job
# fixes this by touching a file every ~50 days, if Actions has contents:write).
```
Turn on **Settings → Secrets → "Alerts for workflow failures"** (or a Discord/Telegram webhook in
the `tests` job) — a silent pipeline and a dead pipeline look identical from the outside.

### Two steps to add on top (optional)

* **Sync finals to R2** so the platforms can pull them: add an `aws s3 sync work s3://acp-media/work
  --exclude '*' --include 'final.mp4' --endpoint-url $R2_ENDPOINT` step, then the `publish` run
  can use `PUBLIC_BASE_URL`-free presigned URLs (`publishers/youtube.public_url` already does this).
* **Post the summary to chat**: the workflow already writes a rich `$GITHUB_STEP_SUMMARY`; a
  one-line `curl -X POST ${{ secrets.SLACK_WEBHOOK }}` with the summary text is the cheapest way
  to keep seeing what it made without opening the Actions tab.

## State between runs: cache mode is the default, git is not required

`MODE` (set from the workflow's `state` input) decides how `work/pipeline.db` and a bounded
footage cache survive to the next run:

| MODE | transport | needs | when to use |
|---|---|---|---|
| `cache` (default) | `actions/cache` + one tarball in `$RUNNER_TEMP` | nothing | the normal choice: no branch, no `contents: write`, nothing to create |
| `artifact` | `actions/upload-artifact` (`acp-state`, 90d) | nothing | when the cache gets evicted (runs are sparse) or you want to download state in the UI |
| `git` | orphan `state` branch via `ci/git_state.sh` | `contents: write` | when you want state reviewable/diffable in the repo |
| `none` | - | nothing | debugging, or you genuinely want a fresh queue every run |
| `<a path>` | tarball in that directory | shared volume | self-hosted runners with a mounted disk, air-gapped CI |

Cold-start is a **normal, logged outcome**, never a failure: `ci/state.sh load` prints
`no cache hit yet (first run on this key) - starting cold` and exits 0. That is the whole point of
this design - the previous version asked git for a branch that did not exist yet and inherited
git's exit code 128 as a red run.

What you lose with `none` (or an evicted cache): the `seen` dedupe table, the `usage` cost ledger
and the per-platform post counters reset, so a daily run can re-pick an idea from 3 days ago and
forget it already posted today. The videos themselves are never lost - they go to the run's
artifacts regardless.

One thing worth knowing about dedupe: `seen` is written only by **discovery**
(`select_ideas -> remember`), so ideas you queue by hand with `acp new --idea` are never
deduped - that is deliberate (you asked for it, you get it), but it means a manual `new` is not
proof that dedupe is working. Check `SELECT count(*) FROM seen;` after a `trends`-driven run instead.

Cache keys are branch-scoped (`acp-state-v1-<branch>`), and `restore-keys` lets a renamed branch
still find the last state. If you change `MODE`, the old copy is simply ignored - nothing to clean up.

## `The process '/usr/bin/git' failed with exit code 128`
| old line | fatal | now |
|---|---|---|
| `git fetch --depth=1 origin state` | branch does not exist on a fresh repo → `128` | `ci/git_state.sh restore` probes with `git ls-remote` first, exits 0 with a log |
| `git archive FETCH_HEAD work` | path absent on that branch → `128` | filtered `git clone` of the branch, files copied with `cp`/`tar` |
| `git add -A work assets` | **our own `.gitignore` lists `work/`** → exit 1, nothing staged, then `commit`/`push` fail | state branch writes its own `.gitignore` allowlist and uses `git add -A -f` |
| keepalive `git push origin HEAD:branch` | with `fetch-depth: 1` there is no `refs/remotes/origin/*`, so the push has no base | fetch that branch explicitly, `|| exit 0` with a `::warning::` |

Design rule now enforced by the script: **state sync can never fail a run that produced a
video.** Anything it cannot do it logs and skips, because a lost dedupe table is a shrug while
a red X at 03:00 is an outage. It also compares trees (`git write-tree`) so an unchanged state
pushes nothing — without that, every run created a fresh state commit and the branch grew
forever.

Diagnose a git step in one line — `::error::` puts it in the Annotations tab:

```bash
- name: git preflight (delete after diagnosing)
  run: |
    set +e
    git rev-parse --is-inside-work-tree; echo "exit=$?"
    git remote -v
    git symbolic-ref -q HEAD || echo "::error::detached HEAD (workflow_dispatch on a tag/SHA?) not a branch"
    git ls-remote --heads origin | sed 's/^/remote head: /'
    echo "token write ok? $(gh api repos/$GITHUB_REPOSITORY/collaborators/$GITHUB_ACTOR/permission --jq .role 2>&1)"
```

If `git remote -v` is empty you are in a fork/no-token context; if `symbolic-ref` fails you
triggered the run on a tag or a SHA. Both make every push fatal, and neither is reproducible
locally — which is exactly why the git work moved out of YAML into a script that is testable
against a fake origin.
