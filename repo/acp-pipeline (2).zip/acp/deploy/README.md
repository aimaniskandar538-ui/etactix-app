# Deploy

## Option 0 — Docker Compose (default recommendation)

```bash
cp .env.example .env && nano .env            # keys + NICHE + PLATFORMS
make docker                                  # builds, starts acp-api + acp-worker
docker compose ps                            # acp-api should be (healthy)
docker compose run --rm acp-api smoke         # offline end-to-end proof, ~15s, no spend
docker compose run --rm acp-api menu          # interactive dispatcher, same code as cron
docker compose logs -f --tail=50 acp-worker
```
Why the image looks like this:
* **one image, four roles** (`api`, `worker`, `once`, `render-only`) via `docker-entrypoint.sh`, so
  the same artefact runs your dev box, the VPS and the GPU box;
* **fonts are baked to `/usr/share/acp-fonts`** because a bind mount over `/app` hides `./fonts`,
  and a missing font is the quietest possible caption bug (libass silently substitutes or drops);
* **`FONTS_DIR`/`WORK_DIR` env + `PYTHONPATH=/app`** so you can bind-mount the source for live
  iteration without the editable install pointing anywhere weird;
* **`memswap_limit` == `mem_limit`** for the worker: an OOM in 30 s beats swapping for 20 minutes
  and freezing the API that n8n is polling;
* **root-only-to-chown-then-drop**: `./work` is owned by whoever made it on the host, so the
  entrypoint chowns once and drops to `APP_UID` (matches your uid via `APP_UID=$(id -u)`).

GPU: `make gpu-build && make docker-gpu`. `FFMPEG_ENCODER=h264_nvenc` is only a *request* —
`render.pick_encoder()` reads `ffmpeg -encoders` and falls back to `libx264` if the build or the
driver is missing, so a wrong image is slow, not broken. Distro `ffmpeg` has **no NVENC**; that is
what the `FFMPEG_STATIC_URL` build arg is for.

Then, once it renders cleanly, decide where the schedule lives — this repo offers three:
```bash
# a) inside the container (simplest, no cron daemon needed)
ACP_LOOP_INTERVAL=21600 docker compose up -d acp-worker
# b) host systemd timers (deploy/acp-worker.timer) - see Option 1
# c) GitHub Actions daily (deploy/github-actions.md) - no server at all, but no public URL
```

## Option 1 — systemd on a $5 VPS (what I'd run)
```bash
git clone <you> /opt/acp && cd /opt/acp && sudo bash scripts/setup.sh
sudo useradd -r -m creator 2>/dev/null; sudo chown -R creator /opt/acp
sudo cp deploy/*.service deploy/acp-worker.timer /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now acp-api.service acp-worker.timer
systemctl list-timers | grep acp ; journalctl -u acp-worker.service -n 50
```
`MemoryMax=1400M` + `Nice=10` + `IOSchedulingClass=idle` on the worker are the load-bearing lines:
a runaway render dies and retries instead of taking the box (and the publisher) with it.
`ProtectSystem=full` on the API keeps the token-bearing process from writing anywhere but
`work/` and `assets/`.

## Option 2 — docker compose (adds n8n)
```bash
docker compose up --build -d          # acp (API), acp-cron, n8n
open http://localhost:5678            # import ../n8n/*.json
```
Notes: the image is `python:3.12-slim` + ffmpeg + DejaVu — no torch, no MoviePy, no whisper, which is
why it is ~350 MB instead of 4 GB. `cpus: "1.5"` is the portable version of "don't let rendering
starve the queue". `acp-work` is a named volume so renders survive rebuilds; bind-mount it
(`./work:/app/work`) if you want the files on the host.

## Making the MP4 publicly fetchable (Instagram + TikTok need this)
```bash
# a) Cloudflare Tunnel to the built-in file server — $0, no router changes
cloudflared tunnel --url http://localhost:8787        # gives https://<slug>.trycloudflare.com
echo "PUBLIC_BASE_URL=https://<slug>.trycloudflare.com" >> .env   # ephemeral URL: fine for testing only

# b) Cloudflare R2 — $0 at this volume, permanent, and what to use in production
aws configure set aws_access_key_id $R2_KEY && aws configure set aws_secret_access_key $R2_SECRET
echo "R2_BUCKET=acp-media" >> .env; echo "R2_ENDPOINT=https://<acct>.r2.cloudflarestorage.com" >> .env
```
`acp` presigns a 1-hour URL per publish (`publishers/youtube.public_url`) — long enough for Meta's
fetcher, short enough that you are not publishing a permanent public index of your output.

## Secrets
`secrets/` holds `yt.token`, `tiktok.token`, `client_secret.json` and is in `.gitignore`.
`.env` too. Both are chmod 600 on the box. If you ever commit one, the rotation cost is minutes —
the recovery cost of a leaked IG token is a banned app, so treat it as a real incident.
